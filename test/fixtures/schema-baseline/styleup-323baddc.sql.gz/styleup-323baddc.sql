--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-1.pgdg26.04+2)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-1.pgdg26.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: absurd; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA absurd;


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: item_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.item_kind AS ENUM (
    'UserMessage',
    'SteeringMessage',
    'AgentMessage',
    'Reasoning',
    'ToolCall',
    'ToolResult',
    'Elicitation',
    'ElicitationResponse',
    'Wake',
    'Error',
    'ContextCompaction',
    'Retraction',
    'Stop',
    'RuntimeChange'
);


--
-- Name: wake_cause; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.wake_cause AS ENUM (
    'cron',
    'webhook',
    'child_done',
    'system'
);


--
-- Name: await_event(text, uuid, uuid, text, text, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.await_event(p_queue_name text, p_task_id uuid, p_run_id uuid, p_step_name text, p_event_name text, p_timeout integer DEFAULT NULL::integer) RETURNS TABLE(should_suspend boolean, payload jsonb)
    LANGUAGE plpgsql
    AS $_$
declare
  v_run_state text;
  v_existing_payload jsonb;
  v_event_payload jsonb;
  v_checkpoint_payload jsonb;
  v_resolved_payload jsonb;
  v_timeout_at timestamptz;
  v_available_at timestamptz;
  v_now timestamptz := absurd.current_time();
  v_task_state text;
  v_wake_event text;
begin
  if p_event_name is null or length(trim(p_event_name)) = 0 then
    raise exception 'event_name must be provided';
  end if;

  if p_timeout is not null then
    if p_timeout < 0 then
      raise exception 'timeout must be non-negative';
    end if;
    v_timeout_at := v_now + (p_timeout::double precision * interval '1 second');
  end if;

  v_available_at := coalesce(v_timeout_at, 'infinity'::timestamptz);

  execute format(
    'select state
       from absurd.%I
      where task_id = $1
        and checkpoint_name = $2',
    'c_' || p_queue_name
  )
  into v_checkpoint_payload
  using p_task_id, p_step_name;

  if v_checkpoint_payload is not null then
    return query select false, v_checkpoint_payload;
    return;
  end if;

  -- Ensure a row exists for this event so we can take a row-level lock.
  --
  -- We use payload IS NULL as the sentinel for "not emitted yet".  emit_event
  -- always writes a non-NULL payload (at minimum JSON null).
  --
  -- Lock ordering is important to avoid deadlocks: await_event locks the event
  -- row first (FOR SHARE) and then the run row (FOR UPDATE).  emit_event
  -- naturally locks the event row via its UPSERT before touching waits/runs.
  execute format(
    'insert into absurd.%I (event_name, payload, emitted_at)
     values ($1, null, ''epoch''::timestamptz)
     on conflict (event_name) do nothing',
    'e_' || p_queue_name
  ) using p_event_name;

  execute format(
    'select 1
       from absurd.%I
      where event_name = $1
      for share',
    'e_' || p_queue_name
  ) using p_event_name;

  execute format(
    'select r.state, r.event_payload, r.wake_event, t.state
       from absurd.%I r
       join absurd.%I t on t.task_id = r.task_id
      where r.run_id = $1
      for update',
    'r_' || p_queue_name,
    't_' || p_queue_name
  )
  into v_run_state, v_existing_payload, v_wake_event, v_task_state
  using p_run_id;

  if v_run_state is null then
    raise exception 'Run "%" not found while awaiting event', p_run_id;
  end if;

  if v_task_state = 'cancelled' then
    raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
  end if;

  execute format(
    'select payload
       from absurd.%I
      where event_name = $1',
    'e_' || p_queue_name
  )
  into v_event_payload
  using p_event_name;

  if v_existing_payload is not null then
    execute format(
      'update absurd.%I
          set event_payload = null
        where run_id = $1',
      'r_' || p_queue_name
    ) using p_run_id;

    if v_event_payload is not null and v_event_payload = v_existing_payload then
      v_resolved_payload := v_existing_payload;
    end if;
  end if;

  if v_run_state <> 'running' then
    raise exception 'Run "%" must be running to await events', p_run_id;
  end if;

  if v_resolved_payload is null and v_event_payload is not null then
    v_resolved_payload := v_event_payload;
  end if;

  if v_resolved_payload is not null then
    execute format(
      'insert into absurd.%I (task_id, checkpoint_name, state, status, owner_run_id, updated_at)
       values ($1, $2, $3, ''committed'', $4, $5)
       on conflict (task_id, checkpoint_name)
       do update set state = excluded.state,
                     status = excluded.status,
                     owner_run_id = excluded.owner_run_id,
                     updated_at = excluded.updated_at',
      'c_' || p_queue_name
    ) using p_task_id, p_step_name, v_resolved_payload, p_run_id, v_now;
    return query select false, v_resolved_payload;
    return;
  end if;

  -- Detect if we resumed due to timeout: wake_event matches and payload is null
  if v_resolved_payload is null and v_wake_event = p_event_name and v_existing_payload is null then
    -- Resumed due to timeout; don't re-sleep and don't create a new wait
    execute format(
      'update absurd.%I set wake_event = null where run_id = $1',
      'r_' || p_queue_name
    ) using p_run_id;
    return query select false, null::jsonb;
    return;
  end if;

  execute format(
    'insert into absurd.%I (task_id, run_id, step_name, event_name, timeout_at, created_at)
     values ($1, $2, $3, $4, $5, $6)
     on conflict (run_id, step_name)
     do update set event_name = excluded.event_name,
                   timeout_at = excluded.timeout_at,
                   created_at = excluded.created_at',
    'w_' || p_queue_name
  ) using p_task_id, p_run_id, p_step_name, p_event_name, v_timeout_at, v_now;

  execute format(
    'update absurd.%I
        set state = ''sleeping'',
            claimed_by = null,
            claim_expires_at = null,
            available_at = $3,
            wake_event = $2,
            event_payload = null
      where run_id = $1',
    'r_' || p_queue_name
  ) using p_run_id, p_event_name, v_available_at;

  execute format(
    'update absurd.%I
        set state = ''sleeping''
      where task_id = $1',
    't_' || p_queue_name
  ) using p_task_id;

  return query select true, null::jsonb;
  return;
end;
$_$;


--
-- Name: cancel_task(text, uuid); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.cancel_task(p_queue_name text, p_task_id uuid) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_task_state text;
begin
  -- Lock active runs before the task row so cancel_task() uses the same
  -- lock acquisition order as complete_run()/fail_run().
  execute format(
    'select run_id
       from absurd.%I
      where task_id = $1
        and state not in (''completed'', ''failed'', ''cancelled'')
      order by run_id
      for update',
    'r_' || p_queue_name
  ) using p_task_id;

  execute format(
    'select state
       from absurd.%I
      where task_id = $1
      for update',
    't_' || p_queue_name
  )
  into v_task_state
  using p_task_id;

  if v_task_state is null then
    raise exception 'Task "%" not found in queue "%"', p_task_id, p_queue_name;
  end if;

  if v_task_state in ('completed', 'failed', 'cancelled') then
    return;
  end if;

  execute format(
    'update absurd.%I
        set state = ''cancelled'',
            cancelled_at = coalesce(cancelled_at, $2)
      where task_id = $1',
    't_' || p_queue_name
  ) using p_task_id, v_now;

  execute format(
    'update absurd.%I
        set state = ''cancelled'',
            claimed_by = null,
            claim_expires_at = null
      where task_id = $1
        and state not in (''completed'', ''failed'', ''cancelled'')',
    'r_' || p_queue_name
  ) using p_task_id;

  execute format(
    'delete from absurd.%I where task_id = $1',
    'w_' || p_queue_name
  ) using p_task_id;
end;
$_$;


--
-- Name: claim_task(text, text, integer, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.claim_task(p_queue_name text, p_worker_id text, p_claim_timeout integer DEFAULT 30, p_qty integer DEFAULT 1) RETURNS TABLE(run_id uuid, task_id uuid, attempt integer, task_name text, params jsonb, retry_strategy jsonb, max_attempts integer, headers jsonb, wake_event text, event_payload jsonb)
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_claim_timeout integer := greatest(coalesce(p_claim_timeout, 30), 0);
  v_worker_id text := coalesce(nullif(p_worker_id, ''), 'worker');
  v_qty integer := greatest(coalesce(p_qty, 1), 1);
  v_claim_until timestamptz := null;
  v_sql text;
  v_expired_run record;
  v_cancel_candidate record;
  v_expired_sweep_limit integer;
begin
  if v_claim_timeout > 0 then
    v_claim_until := v_now + make_interval(secs => v_claim_timeout);
  end if;

  -- Keep claim polling work bounded: process at most v_qty expired leases
  -- per claim call.
  v_expired_sweep_limit := greatest(v_qty, 1);

  -- Apply cancellation rules before claiming.
  --
  -- Use cancel_task() so lock order stays consistent (runs first, task second)
  -- with complete_run()/fail_run().
  for v_cancel_candidate in
    execute format(
      'select task_id
         from absurd.%I
        where state in (''pending'', ''sleeping'', ''running'')
          and cancellation is not null
          and (
            (
              (cancellation->>''max_delay'')::bigint is not null
              and first_started_at is null
              and extract(epoch from ($1 - enqueue_at)) >= (cancellation->>''max_delay'')::bigint
            )
            or
            (
              (cancellation->>''max_duration'')::bigint is not null
              and first_started_at is not null
              and extract(epoch from ($1 - first_started_at)) >= (cancellation->>''max_duration'')::bigint
            )
          )
        order by task_id',
      't_' || p_queue_name
    )
  using v_now
  loop
    perform absurd.cancel_task(p_queue_name, v_cancel_candidate.task_id);
  end loop;

  for v_expired_run in
    execute format(
      'select run_id,
              claimed_by,
              claim_expires_at,
              attempt
         from absurd.%I
        where state = ''running''
          and claim_expires_at is not null
          and claim_expires_at <= $1
        order by claim_expires_at, run_id
        limit $2
        for update skip locked',
      'r_' || p_queue_name
    )
  using v_now, v_expired_sweep_limit
  loop
    perform absurd.fail_run(
      p_queue_name,
      v_expired_run.run_id,
      jsonb_strip_nulls(jsonb_build_object(
        'name', '$ClaimTimeout',
        'message', 'worker did not finish task within claim interval',
        'workerId', v_expired_run.claimed_by,
        'claimExpiredAt', v_expired_run.claim_expires_at,
        'attempt', v_expired_run.attempt
      )),
      null
    );
  end loop;

  v_sql := format(
    'with candidate as (
        select r.run_id
          from absurd.%1$I r
          join absurd.%2$I t on t.task_id = r.task_id
         where r.state in (''pending'', ''sleeping'')
           and t.state in (''pending'', ''sleeping'', ''running'')
           and r.available_at <= $1
         order by r.available_at, r.run_id
         limit $2
         for update skip locked
     ),
     updated as (
        update absurd.%1$I r
           set state = ''running'',
               claimed_by = $3,
               claim_expires_at = $4,
               started_at = $1,
               available_at = $1
         where run_id in (select run_id from candidate)
         returning r.run_id, r.task_id, r.attempt
     ),
     task_upd as (
        update absurd.%2$I t
           set state = ''running'',
               attempts = greatest(t.attempts, u.attempt),
               first_started_at = coalesce(t.first_started_at, $1),
               last_attempt_run = u.run_id
          from updated u
         where t.task_id = u.task_id
         returning t.task_id
     ),
     wait_cleanup as (
        delete from absurd.%3$I w
         using updated u
        where w.run_id = u.run_id
          and w.timeout_at is not null
          and w.timeout_at <= $1
        returning w.run_id
     )
     select
       u.run_id,
       u.task_id,
       u.attempt,
       t.task_name,
       t.params,
       t.retry_strategy,
       t.max_attempts,
      t.headers,
      r.wake_event,
      r.event_payload
     from updated u
     join absurd.%1$I r on r.run_id = u.run_id
     join absurd.%2$I t on t.task_id = u.task_id
     order by r.available_at, u.run_id',
    'r_' || p_queue_name,
    't_' || p_queue_name,
    'w_' || p_queue_name
  );

  return query execute v_sql using v_now, v_qty, v_worker_id, v_claim_until;
end;
$_$;


--
-- Name: cleanup_all_queues(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.cleanup_all_queues(p_queue_name text DEFAULT NULL::text) RETURNS TABLE(queue_name text, tasks_deleted integer, events_deleted integer)
    LANGUAGE plpgsql
    AS $$
declare
  v_queue record;
  v_cleanup_ttl_seconds integer;
begin
  if p_queue_name is not null then
    p_queue_name := absurd.validate_queue_name(p_queue_name);

    if not exists (
      select 1
      from absurd.queues q
      where q.queue_name = p_queue_name
    ) then
      raise exception 'Queue "%" does not exist', p_queue_name;
    end if;
  end if;

  for v_queue in
    select
      q.queue_name,
      q.cleanup_ttl,
      q.cleanup_limit
    from absurd.queues q
    where p_queue_name is null or q.queue_name = p_queue_name
    order by q.queue_name
  loop
    v_cleanup_ttl_seconds := greatest(
      floor(extract(epoch from v_queue.cleanup_ttl))::integer,
      0
    );

    queue_name := v_queue.queue_name;
    tasks_deleted := absurd.cleanup_tasks(
      v_queue.queue_name,
      v_cleanup_ttl_seconds,
      v_queue.cleanup_limit
    );
    events_deleted := absurd.cleanup_events(
      v_queue.queue_name,
      v_cleanup_ttl_seconds,
      v_queue.cleanup_limit
    );
    return next;
  end loop;
end;
$$;


--
-- Name: cleanup_events(text, integer, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.cleanup_events(p_queue_name text, p_ttl_seconds integer, p_limit integer DEFAULT 1000) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_cutoff timestamptz;
  v_deleted_count integer;
begin
  if p_ttl_seconds is null or p_ttl_seconds < 0 then
    raise exception 'TTL must be a non-negative number of seconds';
  end if;

  v_cutoff := v_now - (p_ttl_seconds * interval '1 second');

  execute format(
    'with to_delete as (
        select event_name
          from absurd.%I
         where emitted_at < $1
         order by emitted_at
         limit $2
     ),
     del_events as (
        delete from absurd.%I e
         where e.event_name in (select event_name from to_delete)
         returning 1
     )
     select count(*) from del_events',
    'e_' || p_queue_name,
    'e_' || p_queue_name
  )
  into v_deleted_count
  using v_cutoff, p_limit;

  return v_deleted_count;
end;
$_$;


--
-- Name: cleanup_tasks(text, integer, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.cleanup_tasks(p_queue_name text, p_ttl_seconds integer, p_limit integer DEFAULT 1000) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_cutoff timestamptz;
  v_deleted_count integer;
  v_storage_mode text := 'unpartitioned';
begin
  if p_ttl_seconds is null or p_ttl_seconds < 0 then
    raise exception 'TTL must be a non-negative number of seconds';
  end if;

  v_cutoff := v_now - (p_ttl_seconds * interval '1 second');

  select storage_mode into v_storage_mode
  from absurd.queues
  where queue_name = p_queue_name;

  v_storage_mode := coalesce(v_storage_mode, 'unpartitioned');

  if v_storage_mode = 'partitioned' then
    -- Delete in order: wait registrations, checkpoints, runs, idempotency keys,
    -- then tasks.
    execute format(
      'with eligible_tasks as (
          select t.task_id,
                 case
                   when t.state = ''completed'' then r.completed_at
                   when t.state = ''failed'' then r.failed_at
                   when t.state = ''cancelled'' then t.cancelled_at
                   else null
                 end as terminal_at
            from absurd.%1$I t
            left join absurd.%2$I r on r.run_id = t.last_attempt_run
           where t.state in (''completed'', ''failed'', ''cancelled'')
       ),
       to_delete as (
          select task_id
            from eligible_tasks
           where terminal_at is not null
             and terminal_at < $1
           order by terminal_at
           limit $2
       ),
       del_waits as (
          delete from absurd.%3$I w
           where w.task_id in (select task_id from to_delete)
       ),
       del_checkpoints as (
          delete from absurd.%4$I c
           where c.task_id in (select task_id from to_delete)
       ),
       del_runs as (
          delete from absurd.%2$I r
           where r.task_id in (select task_id from to_delete)
       ),
       del_idempotency as (
          delete from absurd.%5$I i
           where i.task_id in (select task_id from to_delete)
       ),
       del_tasks as (
          delete from absurd.%1$I t
           where t.task_id in (select task_id from to_delete)
           returning 1
       )
       select count(*) from del_tasks',
      't_' || p_queue_name,
      'r_' || p_queue_name,
      'w_' || p_queue_name,
      'c_' || p_queue_name,
      'i_' || p_queue_name
    )
    into v_deleted_count
    using v_cutoff, p_limit;
  else
    -- Unpartitioned queues keep idempotency key ownership on the task row,
    -- so no side-table cleanup is needed.
    execute format(
      'with eligible_tasks as (
          select t.task_id,
                 case
                   when t.state = ''completed'' then r.completed_at
                   when t.state = ''failed'' then r.failed_at
                   when t.state = ''cancelled'' then t.cancelled_at
                   else null
                 end as terminal_at
            from absurd.%1$I t
            left join absurd.%2$I r on r.run_id = t.last_attempt_run
           where t.state in (''completed'', ''failed'', ''cancelled'')
       ),
       to_delete as (
          select task_id
            from eligible_tasks
           where terminal_at is not null
             and terminal_at < $1
           order by terminal_at
           limit $2
       ),
       del_waits as (
          delete from absurd.%3$I w
           where w.task_id in (select task_id from to_delete)
       ),
       del_checkpoints as (
          delete from absurd.%4$I c
           where c.task_id in (select task_id from to_delete)
       ),
       del_runs as (
          delete from absurd.%2$I r
           where r.task_id in (select task_id from to_delete)
       ),
       del_tasks as (
          delete from absurd.%1$I t
           where t.task_id in (select task_id from to_delete)
           returning 1
       )
       select count(*) from del_tasks',
      't_' || p_queue_name,
      'r_' || p_queue_name,
      'w_' || p_queue_name,
      'c_' || p_queue_name
    )
    into v_deleted_count
    using v_cutoff, p_limit;
  end if;

  return v_deleted_count;
end;
$_$;


--
-- Name: complete_run(text, uuid, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.complete_run(p_queue_name text, p_run_id uuid, p_state jsonb DEFAULT NULL::jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_task_id uuid;
  v_state text;
  v_now timestamptz := absurd.current_time();
begin
  execute format(
    'select task_id, state
       from absurd.%I
      where run_id = $1
      for update',
    'r_' || p_queue_name
  )
  into v_task_id, v_state
  using p_run_id;

  if v_task_id is null then
    raise exception 'Run "%" not found in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_state <> 'running' then
    if v_state = 'cancelled' then
      raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
    end if;
    if v_state = 'failed' then
      raise exception sqlstate 'AB002' using message = format('Run "%s" has already failed in queue "%s"', p_run_id, p_queue_name);
    end if;
    raise exception 'Run "%" is not currently running in queue "%"', p_run_id, p_queue_name;
  end if;

  execute format(
    'update absurd.%I
        set state = ''completed'',
            completed_at = $2,
            result = $3
      where run_id = $1',
    'r_' || p_queue_name
  ) using p_run_id, v_now, p_state;

  execute format(
    'update absurd.%I
        set state = ''completed'',
            completed_payload = $2,
            last_attempt_run = $3
      where task_id = $1',
    't_' || p_queue_name
  ) using v_task_id, p_state, p_run_id;

  execute format(
    'delete from absurd.%I where run_id = $1',
    'w_' || p_queue_name
  ) using p_run_id;
end;
$_$;


--
-- Name: create_queue(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.create_queue(p_queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform absurd.create_queue(p_queue_name, 'unpartitioned');
end;
$$;


--
-- Name: create_queue(text, text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.create_queue(p_queue_name text, p_storage_mode text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_storage_mode text;
  v_existing_mode text;
begin
  p_queue_name := absurd.validate_queue_name(p_queue_name);

  v_storage_mode := lower(trim(coalesce(p_storage_mode, '')));
  if v_storage_mode not in ('unpartitioned', 'partitioned') then
    raise exception 'Unsupported queue storage mode "%"', p_storage_mode;
  end if;

  insert into absurd.queues (queue_name, storage_mode)
  values (p_queue_name, v_storage_mode)
  on conflict (queue_name) do nothing;

  select storage_mode into v_existing_mode
  from absurd.queues
  where queue_name = p_queue_name;

  if v_existing_mode is null then
    raise exception 'Queue "%" was not found after create attempt', p_queue_name;
  end if;

  if v_existing_mode <> v_storage_mode then
    raise exception 'Queue "%" already exists with storage mode "%"', p_queue_name, v_existing_mode;
  end if;

  perform absurd.ensure_queue_tables(p_queue_name);
end;
$$;


--
-- Name: current_time(); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd."current_time"() RETURNS timestamp with time zone
    LANGUAGE plpgsql
    AS $$
declare
  v_fake text;
begin
  v_fake := current_setting('absurd.fake_now', true);
  if v_fake is not null and length(trim(v_fake)) > 0 then
    return v_fake::timestamptz;
  end if;

  return clock_timestamp();
end;
$$;


--
-- Name: disable_cron(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.disable_cron(p_queue_name text DEFAULT NULL::text) RETURNS TABLE(job_name text, job_id bigint)
    LANGUAGE plpgsql
    AS $_$
declare
  v_job_suffix text;
  v_partition_job_name text;
  v_cleanup_job_name text;
  v_detach_plan_job_name text;
  v_detach_run_pattern text;
  v_drop_run_pattern text;
  v_existing_job record;
begin
  if p_queue_name is not null then
    p_queue_name := absurd.validate_queue_name(p_queue_name);
  end if;

  if to_regclass('cron.job') is null then
    raise exception 'pg_cron is not available (missing cron.job)';
  end if;

  if not exists (
    select 1
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'cron'
      and p.proname = 'unschedule'
  ) then
    raise exception 'pg_cron is not available (missing cron.unschedule)';
  end if;

  v_job_suffix := case
    when p_queue_name is null then 'all'
    else substr(md5(p_queue_name), 1, 12)
  end;

  v_partition_job_name := 'absurd_partitions_' || v_job_suffix;
  v_cleanup_job_name := 'absurd_cleanup_' || v_job_suffix;
  v_detach_plan_job_name := 'absurd_detach_plan_' || v_job_suffix;
  v_detach_run_pattern := 'absurd_detach_run_' || v_job_suffix || '_%';
  v_drop_run_pattern := 'absurd_drop_run_' || v_job_suffix || '_%';

  for v_existing_job in
    execute 'select jobid, jobname
               from cron.job
              where jobname = $1
                 or jobname = $2
                 or jobname = $3
                 or jobname like $4
                 or jobname like $5
              order by jobname, jobid'
    using v_partition_job_name,
          v_cleanup_job_name,
          v_detach_plan_job_name,
          v_detach_run_pattern,
          v_drop_run_pattern
  loop
    execute 'select cron.unschedule($1)' using v_existing_job.jobid;

    job_name := v_existing_job.jobname;
    job_id := v_existing_job.jobid;
    return next;
  end loop;
end;
$_$;


--
-- Name: drop_detached_partition(text, text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.drop_detached_partition(p_partition_table text, p_unschedule_job_name text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
  v_partition_table text := nullif(trim(coalesce(p_partition_table, '')), '');
  v_partition_oid oid;
  v_is_attached boolean := false;
  v_detach_job_name text;
begin
  if p_unschedule_job_name like 'absurd_drop_run_%' then
    v_detach_job_name :=
      'absurd_detach_run_' || substr(p_unschedule_job_name, length('absurd_drop_run_') + 1);
  end if;

  if v_partition_table is null then
    raise exception 'partition table must be provided';
  end if;

  select c.oid
    into v_partition_oid
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
   where n.nspname = 'absurd'
     and c.relname = v_partition_table;

  if v_partition_oid is null then
    if p_unschedule_job_name is not null and to_regclass('cron.job') is not null then
      perform cron.unschedule(jobid)
        from cron.job
       where jobname in (p_unschedule_job_name, coalesce(v_detach_job_name, ''));
    end if;
    return false;
  end if;

  select exists (
    select 1
    from pg_inherits
    where inhrelid = v_partition_oid
  )
  into v_is_attached;

  if v_is_attached then
    return false;
  end if;

  -- Once detached, stop retrying detach runs immediately. Keep drop
  -- scheduled until the table is actually dropped.
  if v_detach_job_name is not null and to_regclass('cron.job') is not null then
    perform cron.unschedule(jobid)
      from cron.job
     where jobname = v_detach_job_name;
  end if;

  execute format('drop table if exists absurd.%I', v_partition_table);

  if p_unschedule_job_name is not null and to_regclass('cron.job') is not null then
    perform cron.unschedule(jobid)
      from cron.job
     where jobname = p_unschedule_job_name;
  end if;

  return true;
end;
$$;


--
-- Name: drop_queue(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.drop_queue(p_queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_existing_queue text;
begin
  select queue_name into v_existing_queue
  from absurd.queues
  where queue_name = p_queue_name;

  if v_existing_queue is null then
    return;
  end if;

  -- Remove queue-scoped maintenance jobs only when pg_cron is available.
  if to_regclass('cron.job') is not null and exists (
    select 1
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'cron'
      and p.proname = 'unschedule'
  ) then
    perform absurd.disable_cron(p_queue_name);
  end if;

  execute format('drop table if exists absurd.%I cascade', 'i_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 'w_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 'e_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 'c_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 'r_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 't_' || p_queue_name);

  delete from absurd.queues where queue_name = p_queue_name;
end;
$$;


--
-- Name: emit_event(text, text, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.emit_event(p_queue_name text, p_event_name text, p_payload jsonb DEFAULT NULL::jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_payload jsonb := coalesce(p_payload, 'null'::jsonb);
  v_emit_applied integer;
begin
  if p_event_name is null or length(trim(p_event_name)) = 0 then
    raise exception 'event_name must be provided';
  end if;

  -- Events are immutable once emitted: first write wins.
  --
  -- await_event() may pre-create a row with payload=NULL as a "not emitted"
  -- sentinel. We allow exactly one transition NULL -> JSON payload.
  execute format(
    'insert into absurd.%1$I as e (event_name, payload, emitted_at)
     values ($1, $2, $3)
     on conflict (event_name)
     do update set payload = excluded.payload,
                   emitted_at = excluded.emitted_at
      where e.payload is null',
    'e_' || p_queue_name
  ) using p_event_name, v_payload, v_now;

  get diagnostics v_emit_applied = row_count;

  -- Event was already emitted earlier; do not overwrite cached payload or
  -- re-run wakeup side effects.
  if v_emit_applied = 0 then
    return;
  end if;

  execute format(
    'with expired_waits as (
        delete from absurd.%1$I w
         where w.event_name = $1
           and w.timeout_at is not null
           and w.timeout_at <= $2
         returning w.run_id
     ),
     affected as (
        select run_id, task_id, step_name
          from absurd.%1$I
         where event_name = $1
           and (timeout_at is null or timeout_at > $2)
     ),
     updated_runs as (
        update absurd.%2$I r
           set state = ''pending'',
               available_at = $2,
               wake_event = null,
               event_payload = $3,
               claimed_by = null,
               claim_expires_at = null
         where r.run_id in (select run_id from affected)
           and r.state = ''sleeping''
         returning r.run_id, r.task_id
     ),
     checkpoint_upd as (
        insert into absurd.%3$I (task_id, checkpoint_name, state, status, owner_run_id, updated_at)
        select a.task_id, a.step_name, $3, ''committed'', a.run_id, $2
          from affected a
          join updated_runs ur on ur.run_id = a.run_id
        on conflict (task_id, checkpoint_name)
        do update set state = excluded.state,
                      status = excluded.status,
                      owner_run_id = excluded.owner_run_id,
                      updated_at = excluded.updated_at
     ),
     updated_tasks as (
        update absurd.%4$I t
           set state = ''pending''
         where t.task_id in (select task_id from updated_runs)
         returning task_id
     )
     delete from absurd.%5$I w
      where w.event_name = $1
        and w.run_id in (select run_id from updated_runs)',
    'w_' || p_queue_name,
    'r_' || p_queue_name,
    'c_' || p_queue_name,
    't_' || p_queue_name,
    'w_' || p_queue_name
  ) using p_event_name, v_now, v_payload;
end;
$_$;


--
-- Name: enable_cron(text, text, text, text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.enable_cron(p_queue_name text DEFAULT NULL::text, p_partition_schedule text DEFAULT '5 * * * *'::text, p_cleanup_schedule text DEFAULT '17 * * * *'::text, p_detach_schedule text DEFAULT '29 * * * *'::text) RETURNS TABLE(job_name text, job_id bigint)
    LANGUAGE plpgsql
    AS $_$
declare
  v_queue_exists boolean := false;
  v_queue_literal text;
  v_partition_job_name text;
  v_cleanup_job_name text;
  v_detach_plan_job_name text;
  v_partition_command text;
  v_cleanup_command text;
  v_detach_plan_command text;
  v_partitions_job_id bigint;
  v_cleanup_job_id bigint;
  v_detach_plan_job_id bigint;
  v_existing_job_id bigint;
  v_job_suffix text;
begin
  if p_queue_name is not null then
    p_queue_name := absurd.validate_queue_name(p_queue_name);

    select exists (
      select 1
      from absurd.queues
      where queue_name = p_queue_name
    )
    into v_queue_exists;

    if not v_queue_exists then
      raise exception 'Queue "%" does not exist', p_queue_name;
    end if;
  end if;

  if p_partition_schedule is null or length(trim(p_partition_schedule)) = 0 then
    raise exception 'Partition schedule must be provided';
  end if;

  if p_cleanup_schedule is null or length(trim(p_cleanup_schedule)) = 0 then
    raise exception 'Cleanup schedule must be provided';
  end if;

  if p_detach_schedule is null or length(trim(p_detach_schedule)) = 0 then
    raise exception 'Detach schedule must be provided';
  end if;

  if to_regclass('cron.job') is null then
    raise exception 'pg_cron is not available (missing cron.job)';
  end if;

  if not exists (
    select 1
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'cron'
      and p.proname = 'schedule'
  ) then
    raise exception 'pg_cron is not available (missing cron.schedule)';
  end if;

  if not exists (
    select 1
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'cron'
      and p.proname = 'unschedule'
  ) then
    raise exception 'pg_cron is not available (missing cron.unschedule)';
  end if;

  v_queue_literal := case
    when p_queue_name is null then 'null::text'
    else quote_literal(p_queue_name)
  end;

  v_partition_command := format(
    'select absurd.ensure_partitions(%s);',
    v_queue_literal
  );

  v_cleanup_command := format(
    'select * from absurd.cleanup_all_queues(%s);',
    v_queue_literal
  );

  v_job_suffix := case
    when p_queue_name is null then 'all'
    else substr(md5(p_queue_name), 1, 12)
  end;

  v_partition_job_name := 'absurd_partitions_' || v_job_suffix;
  v_cleanup_job_name := 'absurd_cleanup_' || v_job_suffix;
  v_detach_plan_job_name := 'absurd_detach_plan_' || v_job_suffix;

  v_detach_plan_command := format(
    'select * from absurd.schedule_detach_jobs(%s);',
    v_queue_literal
  );

  for v_existing_job_id in
    execute 'select jobid from cron.job where jobname = $1'
    using v_partition_job_name
  loop
    execute 'select cron.unschedule($1)' using v_existing_job_id;
  end loop;

  for v_existing_job_id in
    execute 'select jobid from cron.job where jobname = $1'
    using v_cleanup_job_name
  loop
    execute 'select cron.unschedule($1)' using v_existing_job_id;
  end loop;

  for v_existing_job_id in
    execute 'select jobid from cron.job where jobname = $1'
    using v_detach_plan_job_name
  loop
    execute 'select cron.unschedule($1)' using v_existing_job_id;
  end loop;

  execute 'select cron.schedule($1, $2, $3)'
    into v_partitions_job_id
    using v_partition_job_name, p_partition_schedule, v_partition_command;

  execute 'select cron.schedule($1, $2, $3)'
    into v_cleanup_job_id
    using v_cleanup_job_name, p_cleanup_schedule, v_cleanup_command;

  execute 'select cron.schedule($1, $2, $3)'
    into v_detach_plan_job_id
    using v_detach_plan_job_name, p_detach_schedule, v_detach_plan_command;

  job_name := v_partition_job_name;
  job_id := v_partitions_job_id;
  return next;

  job_name := v_cleanup_job_name;
  job_id := v_cleanup_job_id;
  return next;

  job_name := v_detach_plan_job_name;
  job_id := v_detach_plan_job_id;
  return next;
end;
$_$;


--
-- Name: ensure_partitions(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.ensure_partitions(p_queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_now timestamptz := absurd.current_time();
  v_window_start timestamptz;
  v_window_end timestamptz;
  v_week_start timestamptz;
  v_week_end timestamptz;
  v_partition_tag text;
  v_uuid_from uuid;
  v_uuid_to uuid;
  v_queue record;
begin
  if p_queue_name is not null then
    p_queue_name := absurd.validate_queue_name(p_queue_name);

    if not exists (
      select 1
      from absurd.queues q
      where q.queue_name = p_queue_name
    ) then
      raise exception 'Queue "%" does not exist', p_queue_name;
    end if;
  end if;

  for v_queue in
    select
      queue_name,
      default_partition,
      partition_lookahead,
      partition_lookback
    from absurd.queues
    where storage_mode = 'partitioned'
      and (p_queue_name is null or queue_name = p_queue_name)
    order by queue_name
  loop
    v_window_start := absurd.week_bucket_utc(v_now - v_queue.partition_lookback);
    v_window_end := absurd.week_bucket_utc(v_now + v_queue.partition_lookahead);

    if v_queue.default_partition = 'enabled' then
      execute format(
        'create table if not exists absurd.%I partition of absurd.%I default',
        't_' || v_queue.queue_name || '_d',
        't_' || v_queue.queue_name
      );
      execute format(
        'create table if not exists absurd.%I partition of absurd.%I default',
        'r_' || v_queue.queue_name || '_d',
        'r_' || v_queue.queue_name
      );
      execute format(
        'create table if not exists absurd.%I partition of absurd.%I default',
        'c_' || v_queue.queue_name || '_d',
        'c_' || v_queue.queue_name
      );
      execute format(
        'create table if not exists absurd.%I partition of absurd.%I default',
        'w_' || v_queue.queue_name || '_d',
        'w_' || v_queue.queue_name
      );
    end if;

    v_week_start := v_window_start;
    while v_week_start <= v_window_end loop
      v_week_end := v_week_start + interval '7 days';
      v_partition_tag := absurd.partition_week_tag(v_week_start);
      v_uuid_from := absurd.uuidv7_floor(v_week_start);
      v_uuid_to := absurd.uuidv7_floor(v_week_end);

      execute format(
        'create table if not exists absurd.%I partition of absurd.%I
         for values from (%L::uuid) to (%L::uuid)',
        't_' || v_queue.queue_name || '_' || v_partition_tag,
        't_' || v_queue.queue_name,
        v_uuid_from,
        v_uuid_to
      );
      execute format(
        'create table if not exists absurd.%I partition of absurd.%I
         for values from (%L::uuid) to (%L::uuid)',
        'r_' || v_queue.queue_name || '_' || v_partition_tag,
        'r_' || v_queue.queue_name,
        v_uuid_from,
        v_uuid_to
      );
      execute format(
        'create table if not exists absurd.%I partition of absurd.%I
         for values from (%L::uuid) to (%L::uuid)',
        'c_' || v_queue.queue_name || '_' || v_partition_tag,
        'c_' || v_queue.queue_name,
        v_uuid_from,
        v_uuid_to
      );
      execute format(
        'create table if not exists absurd.%I partition of absurd.%I
         for values from (%L::uuid) to (%L::uuid)',
        'w_' || v_queue.queue_name || '_' || v_partition_tag,
        'w_' || v_queue.queue_name,
        v_uuid_from,
        v_uuid_to
      );

      v_week_start := v_week_end;
    end loop;
  end loop;
end;
$$;


--
-- Name: ensure_queue_tables(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.ensure_queue_tables(p_queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_storage_mode text := 'unpartitioned';
  v_t_suffix text;
  v_r_suffix text;
  v_c_suffix text;
  v_w_suffix text;
  v_t_idempotency_def text;
begin
  perform absurd.validate_queue_name(p_queue_name);

  select storage_mode into v_storage_mode
  from absurd.queues
  where queue_name = p_queue_name;

  v_storage_mode := coalesce(v_storage_mode, 'unpartitioned');

  if v_storage_mode not in ('unpartitioned', 'partitioned') then
    raise exception 'Unsupported queue storage mode "%"', v_storage_mode;
  end if;

  if v_storage_mode = 'partitioned' then
    v_t_suffix := 'partition by range (task_id)';
    v_r_suffix := 'partition by range (run_id)';
    v_c_suffix := 'partition by range (task_id)';
    v_w_suffix := 'partition by range (run_id)';
    v_t_idempotency_def := 'idempotency_key text';
  else
    v_t_suffix := 'with (fillfactor=70)';
    v_r_suffix := 'with (fillfactor=70)';
    v_c_suffix := 'with (fillfactor=70)';
    v_w_suffix := '';
    v_t_idempotency_def := 'idempotency_key text unique';
  end if;

  execute format(
    'create table if not exists absurd.%I (
        task_id uuid primary key,
        task_name text not null,
        params jsonb not null,
        headers jsonb,
        retry_strategy jsonb,
        max_attempts integer,
        cancellation jsonb,
        enqueue_at timestamptz not null default absurd.current_time(),
        first_started_at timestamptz,
        state text not null check (state in (''pending'', ''running'', ''sleeping'', ''completed'', ''failed'', ''cancelled'')),
        attempts integer not null default 0,
        last_attempt_run uuid,
        completed_payload jsonb,
        cancelled_at timestamptz,
        %s
     ) %s',
    't_' || p_queue_name,
    v_t_idempotency_def,
    v_t_suffix
  );

  execute format(
    'create table if not exists absurd.%I (
        run_id uuid primary key,
        task_id uuid not null,
        attempt integer not null,
        state text not null check (state in (''pending'', ''running'', ''sleeping'', ''completed'', ''failed'', ''cancelled'')),
        claimed_by text,
        claim_expires_at timestamptz,
        available_at timestamptz not null,
        wake_event text,
        event_payload jsonb,
        started_at timestamptz,
        completed_at timestamptz,
        failed_at timestamptz,
        result jsonb,
        failure_reason jsonb,
        created_at timestamptz not null default absurd.current_time()
     ) %s',
    'r_' || p_queue_name,
    v_r_suffix
  );

  execute format(
    'create table if not exists absurd.%I (
        task_id uuid not null,
        checkpoint_name text not null,
        state jsonb,
        status text not null default ''committed'',
        owner_run_id uuid,
        updated_at timestamptz not null default absurd.current_time(),
        primary key (task_id, checkpoint_name)
     ) %s',
    'c_' || p_queue_name,
    v_c_suffix
  );

  execute format(
    'create table if not exists absurd.%I (
        event_name text primary key,
        payload jsonb,
        emitted_at timestamptz not null default absurd.current_time()
     )',
    'e_' || p_queue_name
  );

  execute format(
    'create table if not exists absurd.%I (
        task_id uuid not null,
        run_id uuid not null,
        step_name text not null,
        event_name text not null,
        timeout_at timestamptz,
        created_at timestamptz not null default absurd.current_time(),
        primary key (run_id, step_name)
     ) %s',
    'w_' || p_queue_name,
    v_w_suffix
  );

  if v_storage_mode = 'partitioned' then
    execute format(
      'create table if not exists absurd.%I (
          idempotency_key text primary key,
          task_id uuid not null
       )',
      'i_' || p_queue_name
    );
  end if;

  execute format(
    'create index if not exists %I on absurd.%I (state, available_at)',
    ('r_' || p_queue_name) || '_sai',
    'r_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (task_id)',
    ('r_' || p_queue_name) || '_ti',
    'r_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (claim_expires_at)
      where state = ''running''
        and claim_expires_at is not null',
    ('r_' || p_queue_name) || '_cei',
    'r_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (task_id)
      where cancellation is not null',
    ('t_' || p_queue_name) || '_ci',
    't_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (event_name)',
    ('w_' || p_queue_name) || '_eni',
    'w_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (task_id)',
    ('w_' || p_queue_name) || '_ti',
    'w_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (emitted_at)',
    ('e_' || p_queue_name) || '_eai',
    'e_' || p_queue_name
  );

  if v_storage_mode = 'partitioned' then
    execute format(
      'create index if not exists %I on absurd.%I (task_id)',
      ('i_' || p_queue_name) || '_ti',
      'i_' || p_queue_name
    );

    perform absurd.ensure_partitions(p_queue_name);
  end if;
end;
$$;


--
-- Name: extend_claim(text, uuid, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.extend_claim(p_queue_name text, p_run_id uuid, p_extend_by integer) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_task_state text;
  v_run_state text;
  v_claim_expires_at timestamptz;
begin
  if p_extend_by is null or p_extend_by <= 0 then
    raise exception 'extend_by must be > 0';
  end if;

  execute format(
    'select r.state,
            r.claim_expires_at,
            t.state
       from absurd.%I r
       join absurd.%I t on t.task_id = r.task_id
      where r.run_id = $1
      for update',
    'r_' || p_queue_name,
    't_' || p_queue_name
  )
  into v_run_state, v_claim_expires_at, v_task_state
  using p_run_id;

  if v_run_state is null then
    raise exception 'Run "%" not found in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_task_state = 'cancelled' then
    raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
  end if;

  if v_run_state <> 'running' then
    if v_run_state = 'failed' then
      raise exception sqlstate 'AB002' using message = format('Run "%s" has already failed in queue "%s"', p_run_id, p_queue_name);
    end if;
    raise exception 'Run "%" is not currently running in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_claim_expires_at is null then
    raise exception 'Run "%" does not have an active claim in queue "%"', p_run_id, p_queue_name;
  end if;

  execute format(
    'update absurd.%I
        set claim_expires_at = $2 + make_interval(secs => $3)
      where run_id = $1',
    'r_' || p_queue_name
  )
  using p_run_id, v_now, p_extend_by;
end;
$_$;


--
-- Name: fail_run(text, uuid, jsonb, timestamp with time zone); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.fail_run(p_queue_name text, p_run_id uuid, p_reason jsonb, p_retry_at timestamp with time zone DEFAULT NULL::timestamp with time zone) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_task_id uuid;
  v_attempt integer;
  v_run_state text;
  v_retry_strategy jsonb;
  v_max_attempts integer;
  v_now timestamptz := absurd.current_time();
  v_next_attempt integer;
  v_delay_seconds double precision := 0;
  v_next_available timestamptz;
  v_first_started timestamptz;
  v_cancellation jsonb;
  v_max_duration bigint;
  v_task_cancel boolean := false;
  v_new_run_id uuid;
  v_task_state_after text;
  v_recorded_attempt integer;
  v_last_attempt_run uuid := p_run_id;
  v_cancelled_at timestamptz := null;
begin
  execute format(
    'select r.task_id, r.attempt, r.state
       from absurd.%I r
      where r.run_id = $1
      for update',
    'r_' || p_queue_name
  )
  into v_task_id, v_attempt, v_run_state
  using p_run_id;

  if v_task_id is null then
    raise exception 'Run "%" cannot be failed in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_run_state = 'cancelled' then
    raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
  end if;

  if v_run_state = 'failed' then
    raise exception sqlstate 'AB002' using message = format('Run "%s" has already failed in queue "%s"', p_run_id, p_queue_name);
  end if;

  if v_run_state not in ('running', 'sleeping') then
    raise exception 'Run "%" cannot be failed in queue "%"', p_run_id, p_queue_name;
  end if;

  execute format(
    'select retry_strategy, max_attempts, first_started_at, cancellation
       from absurd.%I
      where task_id = $1
      for update',
    't_' || p_queue_name
  )
  into v_retry_strategy, v_max_attempts, v_first_started, v_cancellation
  using v_task_id;

  execute format(
    'update absurd.%I
        set state = ''failed'',
            wake_event = null,
            failed_at = $2,
            failure_reason = $3
      where run_id = $1',
    'r_' || p_queue_name
  ) using p_run_id, v_now, p_reason;

  v_next_attempt := v_attempt + 1;
  v_task_state_after := 'failed';
  v_recorded_attempt := v_attempt;

  if v_max_attempts is null or v_next_attempt <= v_max_attempts then
    if p_retry_at is not null then
      v_next_available := p_retry_at;
    else
      -- Legacy tasks may contain retry strategies that predate validation. If
      -- one is invalid, fail the task permanently rather than wedging the queue.
      begin
        v_delay_seconds := absurd.retry_delay_seconds(v_retry_strategy, v_attempt);
        v_next_available := v_now + (v_delay_seconds * interval '1 second');
      exception
        when sqlstate 'AB003' then
          v_next_available := null;
      end;
    end if;

    if v_next_available < v_now then
      v_next_available := v_now;
    end if;

    if v_cancellation is not null then
      v_max_duration := (v_cancellation->>'max_duration')::bigint;
      if v_max_duration is not null and v_first_started is not null then
        if extract(epoch from (v_next_available - v_first_started)) >= v_max_duration then
          v_task_cancel := true;
        end if;
      end if;
    end if;

    if not v_task_cancel and v_next_available is not null then
      v_task_state_after := case when v_next_available > v_now then 'sleeping' else 'pending' end;
      v_new_run_id := absurd.portable_uuidv7();
      v_recorded_attempt := v_next_attempt;
      v_last_attempt_run := v_new_run_id;
      execute format(
        'insert into absurd.%I (run_id, task_id, attempt, state, available_at, wake_event, event_payload, result, failure_reason)
         values ($1, $2, $3, $4, $5, null, null, null, null)',
        'r_' || p_queue_name
      )
      using v_new_run_id, v_task_id, v_next_attempt, v_task_state_after, v_next_available;
    end if;
  end if;

  if v_task_cancel then
    v_task_state_after := 'cancelled';
    v_cancelled_at := v_now;
    v_recorded_attempt := greatest(v_recorded_attempt, v_attempt);
    v_last_attempt_run := p_run_id;
  end if;

  execute format(
    'update absurd.%I
        set state = $2,
            attempts = greatest(attempts, $3),
            last_attempt_run = $4,
            cancelled_at = coalesce(cancelled_at, $5)
      where task_id = $1',
    't_' || p_queue_name
  ) using v_task_id, v_task_state_after, v_recorded_attempt, v_last_attempt_run, v_cancelled_at;

  execute format(
    'delete from absurd.%I where run_id = $1',
    'w_' || p_queue_name
  ) using p_run_id;
end;
$_$;


--
-- Name: get_queue_policy(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_queue_policy(p_queue_name text) RETURNS TABLE(queue_name text, storage_mode text, default_partition text, partition_lookahead interval, partition_lookback interval, cleanup_ttl interval, cleanup_limit integer, detach_mode text, detach_min_age interval)
    LANGUAGE sql
    AS $$
  select
    q.queue_name,
    q.storage_mode,
    q.default_partition,
    q.partition_lookahead,
    q.partition_lookback,
    q.cleanup_ttl,
    q.cleanup_limit,
    q.detach_mode,
    q.detach_min_age
  from absurd.queues q
  where q.queue_name = p_queue_name;
$$;


--
-- Name: get_schema_version(); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_schema_version() RETURNS text
    LANGUAGE sql
    AS $$
  select '0.5.1'::text;
$$;


--
-- Name: get_task_checkpoint_state(text, uuid, text, boolean); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_task_checkpoint_state(p_queue_name text, p_task_id uuid, p_step_name text, p_include_pending boolean DEFAULT false) RETURNS TABLE(checkpoint_name text, state jsonb, status text, owner_run_id uuid, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
begin
  return query execute format(
    'select checkpoint_name, state, status, owner_run_id, updated_at
       from absurd.%I
      where task_id = $1
        and checkpoint_name = $2
        and ($3 or status = ''committed'')',
    'c_' || p_queue_name
  ) using p_task_id, p_step_name, coalesce(p_include_pending, false);
end;
$_$;


--
-- Name: get_task_checkpoint_states(text, uuid, uuid); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_task_checkpoint_states(p_queue_name text, p_task_id uuid, p_run_id uuid) RETURNS TABLE(checkpoint_name text, state jsonb, status text, owner_run_id uuid, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
declare
  v_run_task_id uuid;
  v_run_attempt integer;
begin
  execute format(
    'select task_id, attempt
       from absurd.%I
      where run_id = $1',
    'r_' || p_queue_name
  )
  into v_run_task_id, v_run_attempt
  using p_run_id;

  if v_run_task_id is null then
    raise exception 'Run "%" not found in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_run_task_id <> p_task_id then
    raise exception 'Run "%" does not belong to task "%" in queue "%"', p_run_id, p_task_id, p_queue_name;
  end if;

  return query execute format(
    'select c.checkpoint_name,
            c.state,
            c.status,
            c.owner_run_id,
            c.updated_at
       from absurd.%1$I c
       left join absurd.%2$I owner_run on owner_run.run_id = c.owner_run_id
      where c.task_id = $1
        and c.status = ''committed''
        and (owner_run.attempt is null or owner_run.attempt <= $2)
      order by c.updated_at asc',
    'c_' || p_queue_name,
    'r_' || p_queue_name
  ) using p_task_id, v_run_attempt;
end;
$_$;


--
-- Name: get_task_result(text, uuid); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_task_result(p_queue_name text, p_task_id uuid) RETURNS TABLE(task_id uuid, state text, result jsonb, failure_reason jsonb)
    LANGUAGE plpgsql
    AS $_$
begin
  p_queue_name := absurd.validate_queue_name(p_queue_name);

  return query execute format(
    'select t.task_id,
            t.state,
            case when t.state = ''completed'' then t.completed_payload else null end as result,
            case when t.state = ''failed'' then r.failure_reason else null end as failure_reason
       from absurd.%I t
       left join absurd.%I r on r.run_id = t.last_attempt_run
      where t.task_id = $1',
    't_' || p_queue_name,
    'r_' || p_queue_name
  ) using p_task_id;
end;
$_$;


--
-- Name: list_detach_candidates(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.list_detach_candidates(p_queue_name text DEFAULT NULL::text) RETURNS TABLE(queue_name text, parent_table text, partition_table text)
    LANGUAGE plpgsql
    AS $$
declare
  v_now timestamptz := absurd.current_time();
  v_queue record;
  v_parent_prefix text;
  v_parent_table text;
  v_parent_oid oid;
  v_part record;
  v_upper_uuid uuid;
  v_upper_ts timestamptz;
  v_has_rows boolean;
begin
  if p_queue_name is not null then
    p_queue_name := absurd.validate_queue_name(p_queue_name);

    if not exists (
      select 1
      from absurd.queues q
      where q.queue_name = p_queue_name
    ) then
      raise exception 'Queue "%" does not exist', p_queue_name;
    end if;
  end if;

  for v_queue in
    select
      q.queue_name,
      q.detach_mode,
      q.detach_min_age
    from absurd.queues q
    where q.storage_mode = 'partitioned'
      and q.detach_mode = 'empty'
      and (p_queue_name is null or q.queue_name = p_queue_name)
    order by q.queue_name
  loop
    foreach v_parent_prefix in array array['t', 'r', 'c', 'w'] loop
      v_parent_table := v_parent_prefix || '_' || v_queue.queue_name;

      select c.oid
        into v_parent_oid
        from pg_class c
        join pg_namespace n on n.oid = c.relnamespace
       where n.nspname = 'absurd'
         and c.relname = v_parent_table;

      if v_parent_oid is null then
        continue;
      end if;

      for v_part in
        select
          child.relname as partition_name,
          pg_get_expr(child.relpartbound, child.oid) as part_bound
        from pg_inherits inh
        join pg_class child on child.oid = inh.inhrelid
        where inh.inhparent = v_parent_oid
      loop
        if v_part.part_bound = 'DEFAULT' then
          continue;
        end if;

        select
          (regexp_match(v_part.part_bound, 'TO \(''([^'']+)''(::uuid)?\)'))[1]::uuid
          into v_upper_uuid;

        if v_upper_uuid is null then
          continue;
        end if;

        v_upper_ts := absurd.uuidv7_timestamp(v_upper_uuid);

        if v_upper_ts is null then
          continue;
        end if;

        if v_upper_ts >= (v_now - v_queue.detach_min_age) then
          continue;
        end if;

        execute format(
          'select exists (select 1 from absurd.%I limit 1)',
          v_part.partition_name
        )
        into v_has_rows;

        if coalesce(v_has_rows, false) then
          continue;
        end if;

        queue_name := v_queue.queue_name;
        parent_table := v_parent_table;
        partition_table := v_part.partition_name;
        return next;
      end loop;
    end loop;
  end loop;
end;
$$;


--
-- Name: list_queues(); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.list_queues() RETURNS TABLE(queue_name text)
    LANGUAGE sql
    AS $$
  select queue_name from absurd.queues order by queue_name;
$$;


--
-- Name: partition_week_tag(timestamp with time zone); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.partition_week_tag(p_ts timestamp with time zone) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  with bucket as (
    select absurd.week_bucket_utc(p_ts) at time zone 'UTC' as ts
  )
  select
    ((extract(isoyear from ts)::int % 10)::text) ||
    lpad((extract(week from ts)::int)::text, 2, '0')
  from bucket;
$$;


--
-- Name: portable_uuidv7(); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.portable_uuidv7() RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare
  ts_ms bigint;
  b bytea;
  rnd bytea;
  i int;
begin
  if to_regprocedure('pg_catalog.uuidv7()') is not null then
    return pg_catalog.uuidv7 ();
  end if;
  ts_ms := floor(extract(epoch from absurd.current_time()) * 1000)::bigint;
  rnd := uuid_send(pg_catalog.gen_random_uuid ());
  b := repeat(E'\\000', 16)::bytea;
  for i in 0..5 loop
    b := set_byte(b, i, ((ts_ms >> ((5 - i) * 8)) & 255)::int);
  end loop;
  for i in 6..15 loop
    b := set_byte(b, i, get_byte(rnd, i));
  end loop;
  b := set_byte(b, 6, ((get_byte(b, 6) & 15) | (7 << 4)));
  b := set_byte(b, 8, ((get_byte(b, 8) & 63) | 128));
  return encode(b, 'hex')::uuid;
end;
$$;


--
-- Name: retry_delay_seconds(jsonb, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.retry_delay_seconds(p_strategy jsonb, p_attempt integer) RETURNS double precision
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  v_limit constant double precision := 86400;
  v_kind text;
  v_base double precision;
  v_factor double precision;
  v_max_seconds double precision;
  v_exponent integer := greatest(coalesce(p_attempt, 1) - 1, 0);
begin
  if p_strategy is null then
    return 0;
  end if;
  if jsonb_typeof(p_strategy) <> 'object' then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy must be a JSON object';
  end if;

  v_kind := coalesce(p_strategy->>'kind', 'none');
  if v_kind not in ('none', 'fixed', 'exponential') then
    raise exception sqlstate 'AB003'
      using message = format('Unsupported retry strategy kind "%s"', v_kind);
  end if;
  if v_kind = 'none' then
    return 0;
  end if;

  v_base := coalesce(
    (p_strategy->>'base_seconds')::double precision,
    case when v_kind = 'fixed' then 60 else 30 end
  );
  if v_base not between 0 and v_limit then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy.base_seconds must be between 0 and 86400';
  end if;
  if v_kind = 'fixed' then
    return v_base;
  end if;

  v_factor := coalesce((p_strategy->>'factor')::double precision, 2);
  v_max_seconds := coalesce(
    (p_strategy->>'max_seconds')::double precision,
    v_limit
  );
  if v_factor < 0 or v_factor::text in ('NaN', 'Infinity', '-Infinity') then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy.factor must be a finite non-negative number';
  end if;
  if v_max_seconds not between 0 and v_limit then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy.max_seconds must be between 0 and 86400';
  end if;
  if v_base = 0 then
    return 0;
  end if;

  begin
    return least(v_base * power(v_factor, v_exponent), v_max_seconds);
  exception
    when numeric_value_out_of_range then
      return case when v_factor < 1 then 0 else v_max_seconds end;
  end;
exception
  when invalid_text_representation or numeric_value_out_of_range then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy contains an invalid number';
end;
$$;


--
-- Name: retry_task(text, uuid, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.retry_task(p_queue_name text, p_task_id uuid, p_options jsonb DEFAULT '{}'::jsonb) RETURNS TABLE(task_id uuid, run_id uuid, attempt integer, created boolean)
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_spawn_new boolean := false;
  v_requested_max_attempts integer;

  v_task_name text;
  v_params jsonb;
  v_headers jsonb;
  v_retry_strategy jsonb;
  v_task_max_attempts integer;
  v_cancellation jsonb;
  v_task_attempts integer;
  v_task_state text;

  v_new_run_id uuid;
  v_new_attempt integer;
  v_spawn_options jsonb;
begin
  if p_options is not null then
    if p_options ? 'spawn_new' then
      v_spawn_new := coalesce((p_options->>'spawn_new')::boolean, false);
    end if;
    if p_options ? 'max_attempts' then
      v_requested_max_attempts := (p_options->>'max_attempts')::int;
      if v_requested_max_attempts is not null and v_requested_max_attempts < 1 then
        raise exception 'max_attempts must be >= 1';
      end if;
    end if;
  end if;

  execute format(
    'select task_name,
            params,
            headers,
            retry_strategy,
            max_attempts,
            cancellation,
            attempts,
            state
       from absurd.%I
      where task_id = $1
      for update',
    't_' || p_queue_name
  )
  into v_task_name,
       v_params,
       v_headers,
       v_retry_strategy,
       v_task_max_attempts,
       v_cancellation,
       v_task_attempts,
       v_task_state
  using p_task_id;

  if v_task_state is null then
    raise exception 'Task "%" not found in queue "%"', p_task_id, p_queue_name;
  end if;

  if v_task_state <> 'failed' then
    raise exception 'Task "%" is not currently failed in queue "%"', p_task_id, p_queue_name;
  end if;

  if v_spawn_new then
    v_spawn_options := jsonb_strip_nulls(jsonb_build_object(
      'headers', v_headers,
      'retry_strategy', v_retry_strategy,
      'max_attempts', coalesce(v_requested_max_attempts, v_task_max_attempts),
      'cancellation', v_cancellation
    ));

    return query
      select s.task_id, s.run_id, s.attempt, s.created
        from absurd.spawn_task(p_queue_name, v_task_name, v_params, v_spawn_options) s;
    return;
  end if;

  if v_requested_max_attempts is null then
    v_requested_max_attempts := coalesce(v_task_max_attempts, v_task_attempts) + 1;
  end if;

  if v_requested_max_attempts <= v_task_attempts then
    raise exception 'max_attempts (%) must be greater than current attempts (%)',
      v_requested_max_attempts,
      v_task_attempts;
  end if;

  v_new_run_id := absurd.portable_uuidv7();
  v_new_attempt := v_task_attempts + 1;

  execute format(
    'insert into absurd.%I (run_id, task_id, attempt, state, available_at, wake_event, event_payload, result, failure_reason)
     values ($1, $2, $3, ''pending'', $4, null, null, null, null)',
    'r_' || p_queue_name
  )
  using v_new_run_id, p_task_id, v_new_attempt, v_now;

  execute format(
    'update absurd.%I
        set state = ''pending'',
            attempts = greatest(attempts, $2),
            max_attempts = $3,
            last_attempt_run = $4,
            cancelled_at = null
      where task_id = $1',
    't_' || p_queue_name
  )
  using p_task_id, v_new_attempt, v_requested_max_attempts, v_new_run_id;

  return query select p_task_id, v_new_run_id, v_new_attempt, false;
end;
$_$;


--
-- Name: schedule_detach_jobs(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.schedule_detach_jobs(p_queue_name text DEFAULT NULL::text) RETURNS TABLE(job_name text, job_id bigint, queue_name text, partition_table text, job_kind text)
    LANGUAGE plpgsql
    AS $_$
declare
  v_scope text;
  v_candidate record;
  v_parent_key text;
  v_candidate_key text;
  v_detach_job_name text;
  v_drop_job_name text;
  v_detach_command text;
  v_drop_command text;
  v_parent_has_default_partition boolean;
  v_job_id bigint;
begin
  if p_queue_name is not null then
    p_queue_name := absurd.validate_queue_name(p_queue_name);
  end if;

  if to_regclass('cron.job') is null then
    raise exception 'pg_cron is not available (missing cron.job)';
  end if;

  if not exists (
    select 1
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'cron'
      and p.proname = 'schedule'
  ) then
    raise exception 'pg_cron is not available (missing cron.schedule)';
  end if;

  if not exists (
    select 1
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'cron'
      and p.proname = 'unschedule'
  ) then
    raise exception 'pg_cron is not available (missing cron.unschedule)';
  end if;

  v_scope := case
    when p_queue_name is null then 'all'
    else substr(md5(p_queue_name), 1, 12)
  end;

  for v_candidate in
    with candidates as (
      select
        c.*,
        absurd.uuidv7_timestamp(
          (regexp_match(
            pg_get_expr(child.relpartbound, child.oid),
            'TO \(''([^'']+)''(::uuid)?\)'
          ))[1]::uuid
        ) as upper_ts
      from absurd.list_detach_candidates(p_queue_name) c
      join pg_class child on child.relname = c.partition_table
      join pg_namespace n on n.oid = child.relnamespace
      where n.nspname = 'absurd'
    ),
    ranked as (
      select
        candidates.*,
        row_number() over (
          partition by candidates.parent_table
          order by candidates.upper_ts asc nulls last, candidates.partition_table asc
        ) as rn
      from candidates
    )
    select
      ranked.queue_name,
      ranked.parent_table,
      ranked.partition_table
    from ranked
    where ranked.rn = 1
    order by ranked.queue_name, ranked.parent_table, ranked.partition_table
  loop
    v_parent_key := substr(md5(v_candidate.parent_table), 1, 8);

    -- Only one active detach pipeline per parent table.
    if exists (
      select 1
      from cron.job
      where jobname like ('absurd_detach_run_%_' || v_parent_key || '_%')
         or jobname like ('absurd_drop_run_%_' || v_parent_key || '_%')
    ) then
      continue;
    end if;

    v_candidate_key := substr(
      md5(v_candidate.parent_table || ':' || v_candidate.partition_table),
      1,
      12
    );

    v_detach_job_name := format(
      'absurd_detach_run_%s_%s_%s',
      v_scope,
      v_parent_key,
      v_candidate_key
    );
    v_drop_job_name := format(
      'absurd_drop_run_%s_%s_%s',
      v_scope,
      v_parent_key,
      v_candidate_key
    );

    if not exists (
      select 1
      from cron.job
      where jobname = v_detach_job_name
         or jobname like ('absurd_detach_run_%_' || v_candidate_key)
    ) then
      select exists (
        select 1
        from pg_class parent
        join pg_namespace pn on pn.oid = parent.relnamespace
        join pg_inherits inh on inh.inhparent = parent.oid
        join pg_class child on child.oid = inh.inhrelid
        where pn.nspname = 'absurd'
          and parent.relname = v_candidate.parent_table
          and pg_get_expr(child.relpartbound, child.oid) = 'DEFAULT'
      )
      into v_parent_has_default_partition;

      v_detach_command := format(
        'alter table absurd.%I detach partition absurd.%I',
        v_candidate.parent_table,
        v_candidate.partition_table
      );

      if not coalesce(v_parent_has_default_partition, false) then
        v_detach_command := v_detach_command || ' concurrently';
      end if;

      execute 'select cron.schedule($1, $2, $3)'
        into v_job_id
        using v_detach_job_name, '* * * * *', v_detach_command;

      job_name := v_detach_job_name;
      job_id := v_job_id;
      queue_name := v_candidate.queue_name;
      partition_table := v_candidate.partition_table;
      job_kind := 'detach';
      return next;
    end if;

    if not exists (
      select 1
      from cron.job
      where jobname = v_drop_job_name
         or jobname like ('absurd_drop_run_%_' || v_candidate_key)
    ) then
      v_drop_command := format(
        'select absurd.drop_detached_partition(%L, %L);',
        v_candidate.partition_table,
        v_drop_job_name
      );

      execute 'select cron.schedule($1, $2, $3)'
        into v_job_id
        using v_drop_job_name, '* * * * *', v_drop_command;

      job_name := v_drop_job_name;
      job_id := v_job_id;
      queue_name := v_candidate.queue_name;
      partition_table := v_candidate.partition_table;
      job_kind := 'drop';
      return next;
    end if;
  end loop;
end;
$_$;


--
-- Name: schedule_run(text, uuid, timestamp with time zone); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.schedule_run(p_queue_name text, p_run_id uuid, p_wake_at timestamp with time zone) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_task_id uuid;
begin
  execute format(
    'select task_id
       from absurd.%I
      where run_id = $1
        and state = ''running''
      for update',
    'r_' || p_queue_name
  )
  into v_task_id
  using p_run_id;

  if v_task_id is null then
    raise exception 'Run "%" is not currently running in queue "%"', p_run_id, p_queue_name;
  end if;

  execute format(
    'update absurd.%I
        set state = ''sleeping'',
            claimed_by = null,
            claim_expires_at = null,
            available_at = $2,
            wake_event = null
      where run_id = $1',
    'r_' || p_queue_name
  ) using p_run_id, p_wake_at;

  execute format(
    'update absurd.%I
        set state = ''sleeping''
      where task_id = $1',
    't_' || p_queue_name
  ) using v_task_id;
end;
$_$;


--
-- Name: set_queue_policy(text, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.set_queue_policy(p_queue_name text, p_policy jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_policy jsonb := coalesce(p_policy, '{}'::jsonb);
  v_unknown_key text;
  v_exists boolean := false;
  v_storage_mode text;
  v_default_partition text;
  v_previous_default_partition text;
  v_parent_prefix text;
  v_parent_table text;
  v_default_table text;
  v_default_attached boolean;
  v_default_has_rows boolean;

  v_partition_lookahead interval;
  v_partition_lookback interval;
  v_cleanup_ttl interval;
  v_cleanup_limit integer;
  v_detach_mode text;
  v_detach_min_age interval;
begin
  p_queue_name := absurd.validate_queue_name(p_queue_name);

  if jsonb_typeof(v_policy) <> 'object' then
    raise exception 'Queue policy must be a JSON object';
  end if;

  select k.key
    into v_unknown_key
    from jsonb_object_keys(v_policy) as k(key)
   where k.key not in (
      'partition_lookahead',
      'partition_lookback',
      'cleanup_ttl',
      'cleanup_limit',
      'detach_mode',
      'detach_min_age',
      'default_partition'
   )
   limit 1;

  if v_unknown_key is not null then
    raise exception 'Unsupported queue policy key "%"', v_unknown_key;
  end if;

  select exists (
    select 1
    from absurd.queues
    where queue_name = p_queue_name
  )
  into v_exists;

  if not v_exists then
    raise exception 'Queue "%" does not exist', p_queue_name;
  end if;

  select
    storage_mode,
    default_partition,
    partition_lookahead,
    partition_lookback,
    cleanup_ttl,
    cleanup_limit,
    detach_mode,
    detach_min_age
  into
    v_storage_mode,
    v_default_partition,
    v_partition_lookahead,
    v_partition_lookback,
    v_cleanup_ttl,
    v_cleanup_limit,
    v_detach_mode,
    v_detach_min_age
  from absurd.queues
  where queue_name = p_queue_name
  for update;

  if v_policy ? 'partition_lookahead' then
    v_partition_lookahead := (v_policy->>'partition_lookahead')::interval;
  end if;

  if v_policy ? 'partition_lookback' then
    v_partition_lookback := (v_policy->>'partition_lookback')::interval;
  end if;

  if v_policy ? 'cleanup_ttl' then
    v_cleanup_ttl := (v_policy->>'cleanup_ttl')::interval;
  end if;

  if v_policy ? 'cleanup_limit' then
    v_cleanup_limit := (v_policy->>'cleanup_limit')::integer;
  end if;

  if v_policy ? 'detach_mode' then
    v_detach_mode := lower(trim(coalesce(v_policy->>'detach_mode', '')));
  end if;

  if v_policy ? 'detach_min_age' then
    v_detach_min_age := (v_policy->>'detach_min_age')::interval;
  end if;

  v_previous_default_partition := v_default_partition;

  if v_policy ? 'default_partition' then
    v_default_partition := lower(trim(coalesce(v_policy->>'default_partition', '')));
  end if;

  if v_partition_lookahead < interval '0 seconds' then
    raise exception 'partition_lookahead must be non-negative';
  end if;

  if v_partition_lookback < interval '0 seconds' then
    raise exception 'partition_lookback must be non-negative';
  end if;

  if v_cleanup_ttl < interval '0 seconds' then
    raise exception 'cleanup_ttl must be non-negative';
  end if;

  if v_cleanup_limit < 1 then
    raise exception 'cleanup_limit must be at least 1';
  end if;

  if v_detach_mode not in ('none', 'empty') then
    raise exception 'Unsupported detach mode "%"', v_detach_mode;
  end if;

  if v_detach_min_age < interval '0 seconds' then
    raise exception 'detach_min_age must be non-negative';
  end if;

  if v_default_partition not in ('enabled', 'disabled') then
    raise exception 'Unsupported default_partition mode "%"', v_default_partition;
  end if;

  if v_storage_mode <> 'partitioned' and v_policy ? 'default_partition' then
    raise exception 'default_partition policy is only supported for partitioned queues';
  end if;

  update absurd.queues
     set default_partition = v_default_partition,
         partition_lookahead = v_partition_lookahead,
         partition_lookback = v_partition_lookback,
         cleanup_ttl = v_cleanup_ttl,
         cleanup_limit = v_cleanup_limit,
         detach_mode = v_detach_mode,
         detach_min_age = v_detach_min_age
   where queue_name = p_queue_name;

  if v_storage_mode = 'partitioned'
     and v_previous_default_partition <> v_default_partition then
    if v_default_partition = 'enabled' then
      perform absurd.ensure_partitions(p_queue_name);
    else
      foreach v_parent_prefix in array array['t', 'r', 'c', 'w'] loop
        v_parent_table := v_parent_prefix || '_' || p_queue_name;
        v_default_table := v_parent_table || '_d';

        select exists (
          select 1
          from pg_inherits inh
          join pg_class parent on parent.oid = inh.inhparent
          join pg_class child on child.oid = inh.inhrelid
          join pg_namespace n on n.oid = parent.relnamespace
          where n.nspname = 'absurd'
            and parent.relname = v_parent_table
            and child.relname = v_default_table
        )
        into v_default_attached;

        if not coalesce(v_default_attached, false) then
          continue;
        end if;

        -- Block out-of-window writes into the default partition while we
        -- validate emptiness and detach/drop it.
        execute format(
          'lock table absurd.%I in access exclusive mode',
          v_default_table
        );

        execute format(
          'select exists (select 1 from absurd.%I limit 1)',
          v_default_table
        )
        into v_default_has_rows;

        if coalesce(v_default_has_rows, false) then
          raise exception
            'Cannot disable default_partition for queue "%": default partition "%" is not empty',
            p_queue_name,
            v_default_table;
        end if;

        execute format(
          'alter table absurd.%I detach partition absurd.%I',
          v_parent_table,
          v_default_table
        );
        execute format('drop table if exists absurd.%I', v_default_table);
      end loop;
    end if;
  end if;
end;
$$;


--
-- Name: set_task_checkpoint_state(text, uuid, text, jsonb, uuid, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.set_task_checkpoint_state(p_queue_name text, p_task_id uuid, p_step_name text, p_state jsonb, p_owner_run uuid, p_extend_claim_by integer DEFAULT NULL::integer) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_new_attempt integer;
  v_existing_attempt integer;
  v_existing_owner uuid;
  v_task_state text;
  v_run_state text;
begin
  if p_step_name is null or length(trim(p_step_name)) = 0 then
    raise exception 'step_name must be provided';
  end if;

  execute format(
    'select r.attempt, r.state, t.state
       from absurd.%I r
       join absurd.%I t on t.task_id = r.task_id
      where r.run_id = $1',
    'r_' || p_queue_name,
    't_' || p_queue_name
  )
  into v_new_attempt, v_run_state, v_task_state
  using p_owner_run;

  if v_new_attempt is null then
    raise exception 'Run "%" not found for checkpoint', p_owner_run;
  end if;

  if v_task_state = 'cancelled' then
    raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
  end if;

  if v_run_state = 'failed' then
    raise exception sqlstate 'AB002' using message = format('Run "%s" has already failed in queue "%s"', p_owner_run, p_queue_name);
  end if;

  -- Extend the claim if requested
  if p_extend_claim_by is not null and p_extend_claim_by > 0 then
    execute format(
      'update absurd.%I
          set claim_expires_at = $2 + make_interval(secs => $3)
        where run_id = $1
          and state = ''running''
          and claim_expires_at is not null',
      'r_' || p_queue_name
    )
    using p_owner_run, v_now, p_extend_claim_by;
  end if;

  execute format(
    'select c.owner_run_id,
            r.attempt
       from absurd.%I c
       left join absurd.%I r on r.run_id = c.owner_run_id
      where c.task_id = $1
        and c.checkpoint_name = $2',
    'c_' || p_queue_name,
    'r_' || p_queue_name
  )
  into v_existing_owner, v_existing_attempt
  using p_task_id, p_step_name;

  if v_existing_owner is null or v_existing_attempt is null or v_new_attempt >= v_existing_attempt then
    execute format(
      'insert into absurd.%I (task_id, checkpoint_name, state, status, owner_run_id, updated_at)
       values ($1, $2, $3, ''committed'', $4, $5)
       on conflict (task_id, checkpoint_name)
       do update set state = excluded.state,
                     status = excluded.status,
                     owner_run_id = excluded.owner_run_id,
                     updated_at = excluded.updated_at',
      'c_' || p_queue_name
    ) using p_task_id, p_step_name, p_state, p_owner_run, v_now;
  end if;
end;
$_$;


--
-- Name: spawn_task(text, text, jsonb, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.spawn_task(p_queue_name text, p_task_name text, p_params jsonb, p_options jsonb DEFAULT '{}'::jsonb) RETURNS TABLE(task_id uuid, run_id uuid, attempt integer, created boolean)
    LANGUAGE plpgsql
    AS $_$
declare
  v_task_id uuid := absurd.portable_uuidv7();
  v_run_id uuid := absurd.portable_uuidv7();
  v_attempt integer := 1;
  v_headers jsonb;
  v_retry_strategy jsonb;
  v_max_attempts integer;
  v_cancellation jsonb;
  v_idempotency_key text;
  v_existing_task_id uuid;
  v_existing_run_id uuid;
  v_existing_attempt integer;
  v_row_count integer;
  v_storage_mode text := 'unpartitioned';
  v_task_inserted boolean := false;
  v_now timestamptz := absurd.current_time();
  v_params jsonb := coalesce(p_params, 'null'::jsonb);
begin
  if p_task_name is null or length(trim(p_task_name)) = 0 then
    raise exception 'task_name must be provided';
  end if;

  if p_options is not null then
    v_headers := p_options->'headers';
    v_retry_strategy := p_options->'retry_strategy';
    perform absurd.retry_delay_seconds(v_retry_strategy, 1);
    if p_options ? 'max_attempts' then
      v_max_attempts := (p_options->>'max_attempts')::int;
      if v_max_attempts is not null and v_max_attempts < 1 then
        raise exception 'max_attempts must be >= 1';
      end if;
    end if;
    v_cancellation := p_options->'cancellation';
    v_idempotency_key := p_options->>'idempotency_key';
  end if;

  if v_idempotency_key is not null then
    select storage_mode into v_storage_mode
    from absurd.queues
    where queue_name = p_queue_name;

    v_storage_mode := coalesce(v_storage_mode, 'unpartitioned');
    if v_storage_mode not in ('unpartitioned', 'partitioned') then
      raise exception 'Unsupported queue storage mode "%"', v_storage_mode;
    end if;

    if v_storage_mode = 'partitioned' then
      -- Reserve idempotency key via dedicated side table.
      execute format(
        'insert into absurd.%I (idempotency_key, task_id)
         values ($1, $2)
         on conflict (idempotency_key) do nothing',
        'i_' || p_queue_name
      )
      using v_idempotency_key, v_task_id;

      get diagnostics v_row_count = row_count;

      if v_row_count = 0 then
        execute format(
          'select i.task_id, t.last_attempt_run, t.attempts
             from absurd.%I i
             join absurd.%I t on t.task_id = i.task_id
            where i.idempotency_key = $1
              for key share of i',
          'i_' || p_queue_name,
          't_' || p_queue_name
        )
        into v_existing_task_id, v_existing_run_id, v_existing_attempt
        using v_idempotency_key;

        if v_existing_task_id is null then
          raise exception 'Idempotency key "%" in queue "%" was concurrently cleaned up', v_idempotency_key, p_queue_name
            using errcode = '40001',
                  hint = 'Retry spawn_task with the same idempotency key.';
        end if;

        if v_existing_run_id is null then
          raise exception 'Idempotency key "%" in queue "%" resolved to task "%" without a run', v_idempotency_key, p_queue_name, v_existing_task_id;
        end if;

        return query select v_existing_task_id, v_existing_run_id, v_existing_attempt, false;
        return;
      end if;
    else
      -- Unpartitioned queues keep the original unique(idempotency_key)
      -- behavior directly on t_<queue>.
      execute format(
        'insert into absurd.%I (task_id, task_name, params, headers, retry_strategy, max_attempts, cancellation, enqueue_at, first_started_at, state, attempts, last_attempt_run, completed_payload, cancelled_at, idempotency_key)
         values ($1, $2, $3, $4, $5, $6, $7, $8, null, ''pending'', $9, $10, null, null, $11)
         on conflict (idempotency_key) do nothing',
        't_' || p_queue_name
      )
      using v_task_id, p_task_name, v_params, v_headers, v_retry_strategy, v_max_attempts, v_cancellation, v_now, v_attempt, v_run_id, v_idempotency_key;

      get diagnostics v_row_count = row_count;

      if v_row_count = 0 then
        execute format(
          'select task_id, last_attempt_run, attempts
             from absurd.%I
            where idempotency_key = $1',
          't_' || p_queue_name
        )
        into v_existing_task_id, v_existing_run_id, v_existing_attempt
        using v_idempotency_key;

        return query select v_existing_task_id, v_existing_run_id, v_existing_attempt, false;
        return;
      end if;

      v_task_inserted := true;
    end if;
  end if;

  if not v_task_inserted then
    execute format(
      'insert into absurd.%I (task_id, task_name, params, headers, retry_strategy, max_attempts, cancellation, enqueue_at, first_started_at, state, attempts, last_attempt_run, completed_payload, cancelled_at, idempotency_key)
       values ($1, $2, $3, $4, $5, $6, $7, $8, null, ''pending'', $9, $10, null, null, $11)',
      't_' || p_queue_name
    )
    using v_task_id, p_task_name, v_params, v_headers, v_retry_strategy, v_max_attempts, v_cancellation, v_now, v_attempt, v_run_id, v_idempotency_key;
  end if;

  execute format(
    'insert into absurd.%I (run_id, task_id, attempt, state, available_at, wake_event, event_payload, result, failure_reason)
     values ($1, $2, $3, ''pending'', $4, null, null, null, null)',
    'r_' || p_queue_name
  )
  using v_run_id, v_task_id, v_attempt, v_now;

  return query select v_task_id, v_run_id, v_attempt, true;
end;
$_$;


--
-- Name: uuidv7_floor(timestamp with time zone); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.uuidv7_floor(p_ts timestamp with time zone) RETURNS uuid
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
declare
  ts_ms bigint := floor(extract(epoch from p_ts) * 1000)::bigint;
  b bytea;
  i int;
begin
  if ts_ms < 0 or ts_ms > 281474976710655 then
    raise exception 'Timestamp "%" is outside UUIDv7 supported range', p_ts;
  end if;

  b := repeat(E'\\000', 16)::bytea;
  for i in 0..5 loop
    b := set_byte(b, i, ((ts_ms >> ((5 - i) * 8)) & 255)::int);
  end loop;

  -- Set UUIDv7 version and RFC4122 variant; keep all randomness bits at 0.
  b := set_byte(b, 6, (7 << 4));
  b := set_byte(b, 8, 128);

  return encode(b, 'hex')::uuid;
end;
$$;


--
-- Name: uuidv7_timestamp(uuid); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.uuidv7_timestamp(p_id uuid) RETURNS timestamp with time zone
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  with bytes as (
    select uuid_send(p_id) as b
  ),
  decoded as (
    select
      (get_byte(b, 6) >> 4) as version,
      ((get_byte(b, 0)::bigint << 40) |
       (get_byte(b, 1)::bigint << 32) |
       (get_byte(b, 2)::bigint << 24) |
       (get_byte(b, 3)::bigint << 16) |
       (get_byte(b, 4)::bigint << 8)  |
        get_byte(b, 5)::bigint) as ts_ms
    from bytes
  )
  select case
           when version = 7 then 'epoch'::timestamptz + (ts_ms * interval '1 millisecond')
           else null
         end
  from decoded;
$$;


--
-- Name: validate_queue_name(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.validate_queue_name(p_queue_name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
  if p_queue_name is null or p_queue_name = '' then
    raise exception 'Queue name must be provided';
  end if;

  if octet_length(p_queue_name) > 57 then
    raise exception 'Queue name "%" is too long (max 57 bytes).', p_queue_name;
  end if;

  return p_queue_name;
end;
$$;


--
-- Name: week_bucket_utc(timestamp with time zone); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.week_bucket_utc(p_ts timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  select date_trunc('week', p_ts at time zone 'UTC') at time zone 'UTC';
$$;


--
-- Name: acl_grants_bump_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.acl_grants_bump_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        INSERT INTO acl_grants_version(only_row, v) VALUES (TRUE, 1)
        ON CONFLICT (tenant_id, only_row) DO UPDATE SET v = acl_grants_version.v + 1;
        RETURN NULL;
      END
      $$;


--
-- Name: forbid_direct_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_direct_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     IF pg_trigger_depth() > 1 THEN RETURN OLD; END IF;
     RAISE EXCEPTION 'DELETE on % is only allowed through its session', TG_TABLE_NAME
       USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: forbid_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     RAISE EXCEPTION '% on % is forbidden', TG_OP, TG_TABLE_NAME USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: invalidate_request_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_request_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             INSERT INTO session_spend_dirty(day)
             SELECT DISTINCT floor(at::numeric / 86400000)::bigint
               FROM (VALUES
                 (CASE WHEN TG_OP <> 'INSERT' AND OLD.usage_json IS NOT NULL THEN OLD.created_at END),
                 (CASE WHEN TG_OP <> 'DELETE' AND NEW.usage_json IS NOT NULL THEN NEW.created_at END)
               ) changed(at) WHERE at IS NOT NULL
             ON CONFLICT DO NOTHING;
             RETURN NULL;
           END $$;


--
-- Name: invalidate_session_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_session_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             IF TG_OP = 'UPDATE' AND ROW(OLD.id, OLD.scope_id, OLD.origin, OLD.thread_ref, OLD.parent_session_id)
                  IS NOT DISTINCT FROM ROW(NEW.id, NEW.scope_id, NEW.origin, NEW.thread_ref, NEW.parent_session_id) THEN
               RETURN NULL;
             END IF;
             INSERT INTO session_spend_dirty(session_id)
             SELECT DISTINCT id FROM (VALUES (OLD.id), (NEW.id)) changed(id) WHERE id IS NOT NULL;
             RETURN NULL;
           END $$;


--
-- Name: qm_sync_legacy_cron_fire(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_sync_legacy_cron_fire() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        INSERT INTO cron_fires (cron_id, fire_key, thread_ref, session_id, fired_at, scheduled_at, ended_at, status, note, reply)
        SELECT source.cron_id, source.fire_key, COALESCE(source.json->>'threadRef', 'cron:' || source.cron_id), source.json->>'sessionId', source.fired_at, (source.json->>'scheduledAt')::bigint, COALESCE((source.json->>'endedAt')::bigint, CASE WHEN source.json->>'status' IS DISTINCT FROM 'running' THEN source.fired_at END), source.json->>'status', source.json->>'note', source.json->>'reply' FROM (SELECT NEW.*) source
        ON CONFLICT (tenant_id, cron_id, fire_key) DO UPDATE SET thread_ref = EXCLUDED.thread_ref, session_id = EXCLUDED.session_id, fired_at = EXCLUDED.fired_at, scheduled_at = EXCLUDED.scheduled_at, ended_at = EXCLUDED.ended_at, status = EXCLUDED.status, note = EXCLUDED.note, reply = EXCLUDED.reply
  WHERE EXCLUDED.fired_at >= cron_fires.fired_at
    AND (cron_fires.ended_at IS NULL OR EXCLUDED.ended_at IS NOT NULL)
    AND (cron_fires.thread_ref, cron_fires.session_id, cron_fires.fired_at, cron_fires.scheduled_at, cron_fires.ended_at, cron_fires.status, cron_fires.note, cron_fires.reply) IS DISTINCT FROM (EXCLUDED.thread_ref, EXCLUDED.session_id, EXCLUDED.fired_at, EXCLUDED.scheduled_at, EXCLUDED.ended_at, EXCLUDED.status, EXCLUDED.note, EXCLUDED.reply);
        RETURN NEW;
      END
    $$;


--
-- Name: qm_tenant_bypass(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_bypass() RETURNS boolean
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$ SELECT COALESCE(current_setting('qm.tenant_bypass', true), '') = 'on' $$;


--
-- Name: qm_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
     SELECT COALESCE(NULLIF(current_setting('qm.tenant_id', true), '')::uuid, (SELECT id FROM qm_tenant))
   $$;


--
-- Name: qm_tenantize(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenantize() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  t record;
  ix record;
  fk record;
  fn record;
  fks text[] := '{}';
  fk_tables text[] := '{}';
  def text;
  tmp text;
  changed integer := 0;
  tenant_att smallint;
BEGIN
  -- 1. tenant_id column on every table.
  FOR t IN
    SELECT c.oid, c.relname FROM pg_class c
    WHERE c.relnamespace = current_schema()::regnamespace AND c.relkind = 'r'
      AND c.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations', 'qm_schema_maintenance') AND c.relname NOT LIKE 'pg\_%'
      AND NOT EXISTS (SELECT 1 FROM pg_attribute a WHERE a.attrelid = c.oid AND a.attname = 'tenant_id' AND NOT a.attisdropped)
  LOOP
    EXECUTE format('ALTER TABLE %I ADD COLUMN tenant_id uuid NOT NULL DEFAULT qm_tenant_id()', t.relname);
    changed := changed + 1;
  END LOOP;

  -- 2. Drop foreign keys between tenant tables that do not lead with tenant_id; they are recreated below.
  FOR fk IN
    SELECT con.conname, con.conrelid::regclass::text AS tbl, con.conrelid, con.conkey,
           pg_get_constraintdef(con.oid) AS def
    FROM pg_constraint con
    JOIN pg_class src ON src.oid = con.conrelid
    JOIN pg_class dst ON dst.oid = con.confrelid
    WHERE con.contype = 'f'
      AND src.relnamespace = current_schema()::regnamespace AND dst.relnamespace = current_schema()::regnamespace
      AND src.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations', 'qm_schema_maintenance') AND dst.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations', 'qm_schema_maintenance')
      AND (SELECT attname FROM pg_attribute WHERE attrelid = con.conrelid AND attnum = con.conkey[1]) <> 'tenant_id'
  LOOP
    def := regexp_replace(fk.def, '^FOREIGN KEY \(', 'FOREIGN KEY (tenant_id, ');
    def := regexp_replace(def, ' REFERENCES ([^(]+)\(', ' REFERENCES \1(tenant_id, ');
    IF def ~ 'ON DELETE SET NULL' AND def !~ 'ON DELETE SET NULL \(' THEN
      def := replace(def, 'ON DELETE SET NULL', 'ON DELETE SET NULL (' ||
        (SELECT string_agg(quote_ident(attname), ', ' ORDER BY array_position(fk.conkey, attnum))
           FROM pg_attribute WHERE attrelid = fk.conrelid AND attnum = ANY(fk.conkey)) || ')');
    END IF;
    fks := fks || format('ALTER TABLE %s ADD CONSTRAINT %I %s', fk.tbl, fk.conname, def);
    EXECUTE format('ALTER TABLE %s DROP CONSTRAINT %I', fk.tbl, fk.conname);
    changed := changed + 1;
  END LOOP;

  -- 3. Primary keys, unique constraints and unique indexes lead with tenant_id.
  FOR ix IN
    SELECT i.indexrelid, i.indrelid, ic.relname AS index_name, tc.relname AS table_name,
           con.conname, con.contype, pg_get_indexdef(i.indexrelid) AS def
    FROM pg_index i
    JOIN pg_class ic ON ic.oid = i.indexrelid
    JOIN pg_class tc ON tc.oid = i.indrelid
    LEFT JOIN pg_constraint con ON con.conindid = i.indexrelid AND con.contype IN ('p', 'u')
    WHERE i.indisunique AND tc.relnamespace = current_schema()::regnamespace AND tc.relkind = 'r'
      AND tc.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations', 'qm_schema_maintenance')
      AND COALESCE((SELECT attname FROM pg_attribute WHERE attrelid = i.indrelid AND attnum = i.indkey[0]), '') <> 'tenant_id'
  LOOP
    def := regexp_replace(ix.def, ' USING (\w+) \(', ' USING \1 (tenant_id, ');
    IF ix.conname IS NULL THEN
      EXECUTE format('DROP INDEX %I', ix.index_name);
      EXECUTE def;
    ELSE
      tmp := left('qm_tnt_' || md5(ix.index_name), 60);
      def := regexp_replace(def, '^CREATE UNIQUE INDEX \S+ ON ', 'CREATE UNIQUE INDEX ' || quote_ident(tmp) || ' ON ');
      EXECUTE def;
      EXECUTE format('ALTER TABLE %I DROP CONSTRAINT %I', ix.table_name, ix.conname);
      EXECUTE format('ALTER TABLE %I ADD CONSTRAINT %I %s USING INDEX %I', ix.table_name, ix.conname,
        CASE ix.contype WHEN 'p' THEN 'PRIMARY KEY' ELSE 'UNIQUE' END, tmp);
    END IF;
    changed := changed + 1;
  END LOOP;

  -- 4. Recreate the foreign keys with tenant_id leading.
  FOREACH def IN ARRAY fks LOOP
    EXECUTE def;
  END LOOP;

  -- 5. Row-level security on every tenant table.
  FOR t IN
    SELECT c.oid, c.relname, c.relrowsecurity, c.relforcerowsecurity FROM pg_class c
    WHERE c.relnamespace = current_schema()::regnamespace AND c.relkind = 'r'
      AND c.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations', 'qm_schema_maintenance') AND c.relname NOT LIKE 'pg\_%'
      AND (NOT c.relrowsecurity OR NOT c.relforcerowsecurity
           OR NOT EXISTS (SELECT 1 FROM pg_policy p WHERE p.polrelid = c.oid AND p.polname = 'qm_tenant_isolation'))
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t.relname);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t.relname);
    IF NOT EXISTS (SELECT 1 FROM pg_policy p WHERE p.polrelid = t.oid AND p.polname = 'qm_tenant_isolation') THEN
      EXECUTE format('CREATE POLICY qm_tenant_isolation ON %I USING (tenant_id = qm_tenant_id() OR qm_tenant_bypass()) '
        'WITH CHECK (tenant_id = qm_tenant_id() OR qm_tenant_bypass())', t.relname);
    END IF;
    changed := changed + 1;
  END LOOP;

  -- 6. Stored functions and triggers that upsert name tenant_id in their conflict target.
  FOR fn IN
    SELECT p.oid FROM pg_proc p
    WHERE p.pronamespace = current_schema()::regnamespace AND p.prokind = 'f'
      AND p.proname NOT IN ('qm_tenantize', 'qm_tenant_id', 'qm_tenant_bypass')
      AND p.prosrc ~* 'ON CONFLICT\s*\((?!\s*tenant_id)'
  LOOP
    EXECUTE regexp_replace(pg_get_functiondef(fn.oid), 'ON CONFLICT(\s*)\((?!\s*tenant_id)', 'ON CONFLICT\1(tenant_id, ', 'gi');
    changed := changed + 1;
  END LOOP;
  RETURN changed;
END
$$;


--
-- Name: qm_turn_fence(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_turn_fence(p_turn text, p_token text) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
     DECLARE
       v_queue text;
       v_run uuid;
       v_ok boolean;
     BEGIN
       SELECT absurd_queue, absurd_run_id INTO v_queue, v_run FROM runs
        WHERE id = p_turn AND engine = 'absurd' AND status = 'running' AND lease_token = p_token
        FOR SHARE;
       IF v_queue IS NULL OR v_run IS NULL THEN
         RETURN false;
       END IF;
       EXECUTE format(
         'SELECT true FROM absurd.%I WHERE run_id = $1 AND ((state = ''running'' AND claimed_by = $2) OR state = ''cancelled'') FOR SHARE',
         'r_' || v_queue || COALESCE('_t' || left(replace(NULLIF(current_setting('qm.tenant_id', true), ''), '-', ''), 12), ''))
         INTO v_ok USING v_run, p_token;
       RETURN COALESCE(v_ok, false);
     END $_$;


--
-- Name: safe_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.safe_json(t text) RETURNS json
    LANGUAGE plpgsql IMMUTABLE
    AS $$
        BEGIN RETURN t::json; EXCEPTION WHEN others THEN RETURN NULL; END $$;


--
-- Name: spend_usage_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.spend_usage_json(t text) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE
    AS $$
             DECLARE j jsonb;
             BEGIN
               IF t IS NULL OR octet_length(t) > 2000 OR NOT pg_input_is_valid(t, 'jsonb') THEN
                 RETURN NULL;
               END IF;
               j := t::jsonb;
               IF pg_input_is_valid(j ->> 'costUsd', 'double precision') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'input', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'output', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheRead', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheWrite', 'bigint') IS NOT FALSE THEN
                 RETURN j;
               END IF;
               RETURN NULL;
             END
             $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: c_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_background (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_background_t111111110000 (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_delegated (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_delegated_t111111110000 (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_people (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_people_t111111110000 (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: e_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_background (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_background_t111111110000 (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_delegated (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_delegated_t111111110000 (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_people (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_people_t111111110000 (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: queues; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.queues (
    queue_name text NOT NULL,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    storage_mode text DEFAULT 'unpartitioned'::text NOT NULL,
    default_partition text DEFAULT 'enabled'::text NOT NULL,
    partition_lookahead interval DEFAULT '28 days'::interval NOT NULL,
    partition_lookback interval DEFAULT '1 day'::interval NOT NULL,
    cleanup_ttl interval DEFAULT '30 days'::interval NOT NULL,
    cleanup_limit integer DEFAULT 1000 NOT NULL,
    detach_mode text DEFAULT 'none'::text NOT NULL,
    detach_min_age interval DEFAULT '30 days'::interval NOT NULL,
    CONSTRAINT queues_cleanup_limit_check CHECK ((cleanup_limit >= 1)),
    CONSTRAINT queues_cleanup_ttl_check CHECK ((cleanup_ttl >= '00:00:00'::interval)),
    CONSTRAINT queues_default_partition_check CHECK ((default_partition = ANY (ARRAY['enabled'::text, 'disabled'::text]))),
    CONSTRAINT queues_detach_min_age_check CHECK ((detach_min_age >= '00:00:00'::interval)),
    CONSTRAINT queues_detach_mode_check CHECK ((detach_mode = ANY (ARRAY['none'::text, 'empty'::text]))),
    CONSTRAINT queues_partition_lookahead_check CHECK ((partition_lookahead >= '00:00:00'::interval)),
    CONSTRAINT queues_partition_lookback_check CHECK ((partition_lookback >= '00:00:00'::interval)),
    CONSTRAINT queues_storage_mode_check CHECK ((storage_mode = ANY (ARRAY['unpartitioned'::text, 'partitioned'::text])))
);


--
-- Name: r_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_background (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_background_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_background_t111111110000 (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_background_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_delegated (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_delegated_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_delegated_t111111110000 (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_delegated_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_people (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_people_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_people_t111111110000 (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_people_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_background (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_background_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_background_t111111110000 (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_background_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_delegated (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_delegated_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_delegated_t111111110000 (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_delegated_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_people (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_people_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_people_t111111110000 (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_people_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: w_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_background (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_background_t111111110000 (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_delegated (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_delegated_t111111110000 (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_people (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_people_t111111110000 (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: ack_emoji; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.ack_emoji FORCE ROW LEVEL SECURITY;


--
-- Name: ack_emoji_picks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji_picks (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    channel text NOT NULL,
    ts text NOT NULL,
    outcome text NOT NULL,
    picked text,
    icon text,
    message text,
    candidates text,
    model text,
    latency_ms integer,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.ack_emoji_picks FORCE ROW LEVEL SECURITY;


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ack_emoji_picks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ack_emoji_picks_id_seq OWNED BY public.ack_emoji_picks.id;


--
-- Name: acl_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants (
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    grantee_scope_id text NOT NULL,
    permission text NOT NULL,
    granted_by text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.acl_grants FORCE ROW LEVEL SECURITY;


--
-- Name: acl_grants_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants_version (
    only_row boolean DEFAULT true NOT NULL,
    v bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT acl_grants_version_only_row_check CHECK (only_row)
);

ALTER TABLE ONLY public.acl_grants_version FORCE ROW LEVEL SECURITY;


--
-- Name: admin_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_grants (
    principal_id text NOT NULL,
    scope_id text NOT NULL,
    role text NOT NULL,
    granted_by text,
    created_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.admin_grants FORCE ROW LEVEL SECURITY;


--
-- Name: ambient_cursors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_cursors (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.ambient_cursors FORCE ROW LEVEL SECURITY;


--
-- Name: ambient_judgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_judgments (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    container text NOT NULL,
    decision text NOT NULL,
    reason text,
    asked_by text,
    prompt text,
    model text,
    latency_ms integer,
    ts_from text,
    ts_to text,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.ambient_judgments FORCE ROW LEVEL SECURITY;


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ambient_judgments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ambient_judgments_id_seq OWNED BY public.ambient_judgments.id;


--
-- Name: approval_grant_modes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grant_modes (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.approval_grant_modes FORCE ROW LEVEL SECURITY;


--
-- Name: approval_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grants (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.approval_grants FORCE ROW LEVEL SECURITY;


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approvals (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.approvals FORCE ROW LEVEL SECURITY;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    at bigint NOT NULL,
    principal_id text NOT NULL,
    action text NOT NULL,
    resource text NOT NULL,
    scope_label text NOT NULL,
    status text,
    detail text,
    idempotency_key text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.audit_log FORCE ROW LEVEL SECURITY;


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auth_broker_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_broker_sessions (
    token_hash text NOT NULL,
    email text NOT NULL,
    authenticated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    absolute_expires_at timestamp with time zone NOT NULL,
    idle_seconds integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.auth_broker_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: auto_flagger_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_flagger_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.auto_flagger_configs FORCE ROW LEVEL SECURITY;


--
-- Name: aws_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aws_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.aws_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: base_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.base_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.base_model_configs FORCE ROW LEVEL SECURITY;


--
-- Name: blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blobs (
    tenant_id uuid NOT NULL,
    sha256 bytea NOT NULL,
    size bigint NOT NULL,
    mime text,
    storage_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT blobs_sha256_check CHECK ((length(sha256) = 32)),
    CONSTRAINT blobs_size_check CHECK ((size >= 0)),
    CONSTRAINT blobs_storage_key_check CHECK ((storage_key <> ''::text))
);

ALTER TABLE ONLY public.blobs FORCE ROW LEVEL SECURITY;


--
-- Name: branding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.branding_configs FORCE ROW LEVEL SECURITY;


--
-- Name: browse_max_steps_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_max_steps_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.browse_max_steps_configs FORCE ROW LEVEL SECURITY;


--
-- Name: browse_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.browse_model_configs FORCE ROW LEVEL SECURITY;


--
-- Name: browser_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browser_sessions (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.browser_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: channel_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_files (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    file_id text NOT NULL,
    name text,
    mimetype text,
    created_at bigint NOT NULL,
    title text,
    size bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_files FORCE ROW LEVEL SECURITY;


--
-- Name: channel_header_pin_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_header_pin_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_header_pin_flag FORCE ROW LEVEL SECURITY;


--
-- Name: channel_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_messages (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    sub text,
    author_id text,
    author_name text,
    text text DEFAULT ''::text NOT NULL,
    mentions jsonb,
    self boolean DEFAULT false NOT NULL,
    bot boolean DEFAULT false NOT NULL,
    mentions_self boolean DEFAULT false NOT NULL,
    edited_at bigint,
    deleted boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    handled boolean DEFAULT false NOT NULL,
    tsv tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(text, ''::text))) STORED,
    deleted_at bigint,
    broadcast boolean DEFAULT false NOT NULL,
    subtype text,
    bot_id text,
    surface text DEFAULT 'slack'::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_messages FORCE ROW LEVEL SECURITY;


--
-- Name: channel_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy (
    org_id text NOT NULL,
    container text NOT NULL,
    orders text DEFAULT ''::text NOT NULL,
    bots jsonb DEFAULT '{}'::jsonb NOT NULL,
    set_by text,
    updated_at bigint NOT NULL,
    ambient_enabled boolean,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_policy FORCE ROW LEVEL SECURITY;


--
-- Name: channel_policy_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy_history (
    id bigint NOT NULL,
    org_id text NOT NULL,
    container text NOT NULL,
    orders text NOT NULL,
    set_by text,
    session_id text,
    created_at bigint NOT NULL,
    bots jsonb,
    ambient_enabled boolean,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_policy_history FORCE ROW LEVEL SECURITY;


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.channel_policy_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.channel_policy_history_id_seq OWNED BY public.channel_policy_history.id;


--
-- Name: channel_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_state (
    org_id text NOT NULL,
    container text NOT NULL,
    last_ts text,
    oldest_ts text,
    name text,
    kind text,
    members jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at bigint NOT NULL,
    surface text DEFAULT 'slack'::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_state FORCE ROW LEVEL SECURITY;


--
-- Name: command_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.command_policies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.command_policies FORCE ROW LEVEL SECURITY;


--
-- Name: composio_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.composio_returns (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.composio_returns FORCE ROW LEVEL SECURITY;


--
-- Name: connector_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_clients (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.connector_clients FORCE ROW LEVEL SECURITY;


--
-- Name: connector_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_status (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.connector_status FORCE ROW LEVEL SECURITY;


--
-- Name: consent_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consent_links (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.consent_links FORCE ROW LEVEL SECURITY;


--
-- Name: context_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.context_requests (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.context_requests FORCE ROW LEVEL SECURITY;


--
-- Name: credential_daily_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_daily_calls (
    slug text NOT NULL,
    day bigint NOT NULL,
    sent integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.credential_daily_calls FORCE ROW LEVEL SECURITY;


--
-- Name: credential_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_usage (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    slug text NOT NULL,
    host text NOT NULL,
    status text NOT NULL,
    upstream_status integer,
    scope_label text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.credential_usage FORCE ROW LEVEL SECURITY;


--
-- Name: credential_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credential_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credential_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credential_usage_id_seq OWNED BY public.credential_usage.id;


--
-- Name: cron_fires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_fires (
    cron_id text NOT NULL,
    fire_key text NOT NULL,
    thread_ref text NOT NULL,
    session_id text,
    fired_at bigint NOT NULL,
    scheduled_at bigint,
    ended_at bigint,
    status text,
    note text,
    reply text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.cron_fires FORCE ROW LEVEL SECURITY;


--
-- Name: cron_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_items (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.cron_items FORCE ROW LEVEL SECURITY;


--
-- Name: crons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crons (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.crons FORCE ROW LEVEL SECURITY;


--
-- Name: custom_model_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_model_providers (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.custom_model_providers FORCE ROW LEVEL SECURITY;


--
-- Name: deactivated_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deactivated_principals (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.deactivated_principals FORCE ROW LEVEL SECURITY;


--
-- Name: decision_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_providers (
    provider_id text NOT NULL,
    protocol text NOT NULL,
    base_url text,
    credential text,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.decision_providers FORCE ROW LEVEL SECURITY;


--
-- Name: decision_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_rules (
    rule_id text NOT NULL,
    hook text NOT NULL,
    question text NOT NULL,
    options json NOT NULL,
    provider_id text NOT NULL,
    model text NOT NULL,
    mode text NOT NULL,
    on_error text NOT NULL,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT decision_rules_mode_check CHECK ((mode = ANY (ARRAY['off'::text, 'observe'::text, 'enforce'::text])))
);

ALTER TABLE ONLY public.decision_rules FORCE ROW LEVEL SECURITY;


--
-- Name: deploy_git_repos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_git_repos (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.deploy_git_repos FORCE ROW LEVEL SECURITY;


--
-- Name: deployment_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_access (
    id text NOT NULL,
    last_access_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.deployment_access FORCE ROW LEVEL SECURITY;


--
-- Name: deployment_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_identity (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.deployment_identity FORCE ROW LEVEL SECURITY;


--
-- Name: deployment_layer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_layer (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.deployment_layer FORCE ROW LEVEL SECURITY;


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployments (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.deployments FORCE ROW LEVEL SECURITY;


--
-- Name: directory_channel_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channel_members (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_channel_members FORCE ROW LEVEL SECURITY;


--
-- Name: directory_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channels (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    name_lc text NOT NULL,
    is_private boolean DEFAULT false NOT NULL,
    is_external boolean DEFAULT false NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    observed_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_channels FORCE ROW LEVEL SECURITY;


--
-- Name: directory_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_group_members (
    org_id text NOT NULL,
    group_id text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_group_members FORCE ROW LEVEL SECURITY;


--
-- Name: directory_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_groups (
    org_id text NOT NULL,
    group_id text NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_groups FORCE ROW LEVEL SECURITY;


--
-- Name: directory_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_members (
    org_id text NOT NULL,
    principal_id text NOT NULL,
    display_name text NOT NULL,
    display_name_lc text NOT NULL,
    type text NOT NULL,
    slack_id text,
    avatar_url text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_members FORCE ROW LEVEL SECURITY;


--
-- Name: directory_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_meta (
    org_id text NOT NULL,
    workspace_url text,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_meta FORCE ROW LEVEL SECURITY;


--
-- Name: directory_sync; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_sync (
    org_id text NOT NULL,
    members_hash text,
    channels_hash text,
    groups_hash text,
    channel_members_synced boolean DEFAULT false NOT NULL,
    updated_at bigint NOT NULL,
    members_synced_at bigint,
    channels_synced_at bigint,
    groups_synced_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_sync FORCE ROW LEVEL SECURITY;


--
-- Name: durable_map_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.durable_map_versions (
    tbl text NOT NULL,
    v bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.durable_map_versions FORCE ROW LEVEL SECURITY;


--
-- Name: e2b_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.e2b_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.e2b_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: egress_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    source text NOT NULL,
    host text NOT NULL,
    allowed boolean NOT NULL,
    scope_label text NOT NULL,
    port integer,
    verdict text,
    via text,
    peer_ip text,
    principal_id text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.egress_events FORCE ROW LEVEL SECURITY;


--
-- Name: egress_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.egress_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: egress_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.egress_events_id_seq OWNED BY public.egress_events.id;


--
-- Name: egress_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_policies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.egress_policies FORCE ROW LEVEL SECURITY;


--
-- Name: environment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environment_attachments (
    scope_id text NOT NULL,
    environment_id text NOT NULL,
    attached_by text NOT NULL,
    attached_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.environment_attachments FORCE ROW LEVEL SECURITY;


--
-- Name: environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environments (
    id text NOT NULL,
    org_id text NOT NULL,
    name text,
    owner_actor_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.environments FORCE ROW LEVEL SECURITY;


--
-- Name: error_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    scope_label text NOT NULL,
    category text NOT NULL,
    code text NOT NULL,
    message text NOT NULL,
    session_id text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.error_events FORCE ROW LEVEL SECURITY;


--
-- Name: error_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.error_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.error_events_id_seq OWNED BY public.error_events.id;


--
-- Name: external_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_members (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.external_members FORCE ROW LEVEL SECURITY;


--
-- Name: external_slack_participants_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_slack_participants_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.external_slack_participants_flag FORCE ROW LEVEL SECURITY;


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.feature_flags FORCE ROW LEVEL SECURITY;


--
-- Name: file_artifact_deletions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifact_deletions (
    id text NOT NULL,
    deleted_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.file_artifact_deletions FORCE ROW LEVEL SECURITY;


--
-- Name: file_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifacts (
    id text NOT NULL,
    kind text DEFAULT 'file'::text NOT NULL,
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    name text NOT NULL,
    mimetype text NOT NULL,
    size_bytes bigint NOT NULL,
    blob_key text,
    sha256 text,
    direction text NOT NULL,
    created_by text NOT NULL,
    created_in_scope text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    source text DEFAULT 'live'::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.file_artifacts FORCE ROW LEVEL SECURITY;


--
-- Name: idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.idempotency FORCE ROW LEVEL SECURITY;


--
-- Name: individual_model_auth_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.individual_model_auth_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.individual_model_auth_flag FORCE ROW LEVEL SECURITY;


--
-- Name: interactive_fast_mode_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interactive_fast_mode_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.interactive_fast_mode_flag FORCE ROW LEVEL SECURITY;


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    tenant_id uuid NOT NULL,
    session_id text NOT NULL,
    seq bigint NOT NULL,
    turn_id uuid,
    kind public.item_kind NOT NULL,
    author text,
    call_id text,
    elicit_id text,
    wake_cause public.wake_cause,
    error_code text,
    text text,
    tool text,
    step integer,
    variant text,
    is_error boolean,
    hidden boolean,
    external_id text,
    through_seq bigint,
    target_seq bigint,
    approved boolean,
    blob_sha bytea,
    search tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, COALESCE(text, ''::text))) STORED,
    body jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT items_approved_kind CHECK (((approved IS NULL) OR (kind = 'ElicitationResponse'::public.item_kind))),
    CONSTRAINT items_author_check CHECK ((author <> ''::text)),
    CONSTRAINT items_author_kind CHECK (((author IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'ElicitationResponse'::public.item_kind, 'Stop'::public.item_kind, 'RuntimeChange'::public.item_kind])))),
    CONSTRAINT items_blob_sha_kind CHECK (((blob_sha IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_body_check CHECK ((jsonb_typeof(body) = 'object'::text)),
    CONSTRAINT items_call_id_check CHECK ((call_id <> ''::text)),
    CONSTRAINT items_call_id_kind CHECK (((call_id IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_elicit_id_check CHECK ((elicit_id <> ''::text)),
    CONSTRAINT items_elicit_id_kind CHECK (((elicit_id IS NOT NULL) = (kind = ANY (ARRAY['Elicitation'::public.item_kind, 'ElicitationResponse'::public.item_kind])))),
    CONSTRAINT items_error_code_check CHECK ((error_code <> ''::text)),
    CONSTRAINT items_error_code_kind CHECK (((error_code IS NOT NULL) = (kind = 'Error'::public.item_kind))),
    CONSTRAINT items_external_id_check CHECK ((external_id <> ''::text)),
    CONSTRAINT items_external_id_kind CHECK (((external_id IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_hidden_kind CHECK (((hidden IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_is_error_kind CHECK (((is_error IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_seq_check CHECK ((seq >= 0)),
    CONSTRAINT items_step_check CHECK ((step >= 0)),
    CONSTRAINT items_step_kind CHECK (((step IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind, 'Reasoning'::public.item_kind, 'AgentMessage'::public.item_kind])))),
    CONSTRAINT items_target_seq_kind CHECK (((target_seq IS NULL) OR (kind = 'Retraction'::public.item_kind))),
    CONSTRAINT items_text_check CHECK ((text <> ''::text)),
    CONSTRAINT items_text_kind CHECK (((text IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'AgentMessage'::public.item_kind, 'Reasoning'::public.item_kind, 'ToolResult'::public.item_kind, 'Error'::public.item_kind, 'ContextCompaction'::public.item_kind])))),
    CONSTRAINT items_through_seq_kind CHECK (((through_seq IS NULL) OR (kind = 'ContextCompaction'::public.item_kind))),
    CONSTRAINT items_tool_check CHECK ((tool <> ''::text)),
    CONSTRAINT items_tool_kind CHECK (((tool IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_variant_check CHECK ((variant = ANY (ARRAY['narration'::text, 'files_delivered'::text]))),
    CONSTRAINT items_variant_kind CHECK (((variant IS NULL) OR (kind = 'AgentMessage'::public.item_kind))),
    CONSTRAINT items_wake_cause_kind CHECK (((wake_cause IS NOT NULL) = (kind = 'Wake'::public.item_kind)))
);

ALTER TABLE ONLY public.items FORCE ROW LEVEL SECURITY;


--
-- Name: keychain_asks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_asks (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.keychain_asks FORCE ROW LEVEL SECURITY;


--
-- Name: keychain_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_credentials (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.keychain_credentials FORCE ROW LEVEL SECURITY;


--
-- Name: keychain_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_grants (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.keychain_grants FORCE ROW LEVEL SECURITY;


--
-- Name: llm_prompt_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_prompt_envelopes (
    hash text NOT NULL,
    body text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.llm_prompt_envelopes FORCE ROW LEVEL SECURITY;


--
-- Name: local_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.local_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: loop_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_items (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.loop_items FORCE ROW LEVEL SECURITY;


--
-- Name: loops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loops (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.loops FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.mcp_servers FORCE ROW LEVEL SECURITY;


--
-- Name: memory_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_facts (
    id bigint NOT NULL,
    scope_id text NOT NULL,
    text text NOT NULL,
    sensitivity text NOT NULL,
    sources text[] DEFAULT '{}'::text[] NOT NULL,
    source_unknown boolean NOT NULL,
    author text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    deleted_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.memory_facts FORCE ROW LEVEL SECURITY;


--
-- Name: memory_facts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.memory_facts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: memory_facts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.memory_facts_id_seq OWNED BY public.memory_facts.id;


--
-- Name: memory_tidy_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_tidy_profiles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.memory_tidy_profiles FORCE ROW LEVEL SECURITY;


--
-- Name: modal_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modal_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.modal_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: model_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_credentials (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.model_credentials FORCE ROW LEVEL SECURITY;


--
-- Name: monitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monitors (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.monitors FORCE ROW LEVEL SECURITY;


--
-- Name: oauth_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_flows (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.oauth_flows FORCE ROW LEVEL SECURITY;


--
-- Name: org_ambient_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_ambient_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.org_ambient_flag FORCE ROW LEVEL SECURITY;


--
-- Name: participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participants (
    session_id text NOT NULL,
    principal_id text NOT NULL,
    valid_from bigint NOT NULL,
    valid_to bigint,
    valid_from_seq integer,
    valid_to_seq integer,
    title text,
    archived boolean DEFAULT false NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    color text,
    read_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.participants FORCE ROW LEVEL SECURITY;


--
-- Name: principal_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.principal_links (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.principal_links FORCE ROW LEVEL SECURITY;


--
-- Name: process_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_sessions (
    process_id text NOT NULL,
    scope_id text NOT NULL,
    kind text NOT NULL,
    command text NOT NULL,
    started_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    status text NOT NULL,
    session_ref text,
    run_id text,
    sandbox_id text,
    purpose text,
    credential_files jsonb,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.process_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.projects FORCE ROW LEVEL SECURITY;


--
-- Name: qm_schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_schema_migrations (
    id text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: qm_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.qm_settings FORCE ROW LEVEL SECURITY;


--
-- Name: qm_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_tenant (
    id uuid NOT NULL
);


--
-- Name: queued_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queued_posts (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.queued_posts FORCE ROW LEVEL SECURITY;


--
-- Name: rate_limit_windows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit_windows (
    principal_id text NOT NULL,
    window_start bigint NOT NULL,
    count integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.rate_limit_windows FORCE ROW LEVEL SECURITY;


--
-- Name: recent_dm_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recent_dm_posts (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.recent_dm_posts FORCE ROW LEVEL SECURITY;


--
-- Name: run_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_activity (
    id bigint NOT NULL,
    run_id text NOT NULL,
    seq bigint NOT NULL,
    parent_seq bigint,
    type text NOT NULL,
    payload jsonb NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.run_activity FORCE ROW LEVEL SECURITY;


--
-- Name: run_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_activity_id_seq OWNED BY public.run_activity.id;


--
-- Name: run_signals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_signals (
    id bigint NOT NULL,
    run_id text NOT NULL,
    kind text NOT NULL,
    text text,
    payload jsonb,
    created_at bigint NOT NULL,
    consumed_at bigint,
    dedupe_key text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.run_signals FORCE ROW LEVEL SECURITY;


--
-- Name: run_signals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_signals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_signals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_signals_id_seq OWNED BY public.run_signals.id;


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runs (
    id text NOT NULL,
    session_id text NOT NULL,
    status text NOT NULL,
    request text NOT NULL,
    result text,
    idempotency_key text,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    lease_token text,
    lease_expires_at bigint,
    worker_id text,
    created_at bigint NOT NULL,
    started_at bigint,
    finished_at bigint,
    delivery_state text,
    error_attempts integer DEFAULT 0 NOT NULL,
    seq bigint NOT NULL,
    turn_user_seq bigint,
    retry_after bigint DEFAULT 0 NOT NULL,
    returned_at bigint,
    last_stop text,
    claim_priority smallint DEFAULT 2 NOT NULL,
    preemptions integer DEFAULT 0 NOT NULL,
    engine text DEFAULT 'legacy'::text NOT NULL,
    absurd_queue text,
    absurd_task_id uuid,
    absurd_run_id uuid,
    fair_key text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.runs FORCE ROW LEVEL SECURITY;


--
-- Name: runs_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.runs_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runs_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.runs_seq_seq OWNED BY public.runs.seq;


--
-- Name: sandbox_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_defaults (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.sandbox_defaults FORCE ROW LEVEL SECURITY;


--
-- Name: sandbox_resource_rollout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resource_rollout (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.sandbox_resource_rollout FORCE ROW LEVEL SECURITY;


--
-- Name: sandbox_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resources (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.sandbox_resources FORCE ROW LEVEL SECURITY;


--
-- Name: sandbox_routing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_routing (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.sandbox_routing FORCE ROW LEVEL SECURITY;


--
-- Name: secret_drops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secret_drops (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.secret_drops FORCE ROW LEVEL SECURITY;


--
-- Name: security_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_postures (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.security_postures FORCE ROW LEVEL SECURITY;


--
-- Name: session_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_goals (
    session_id text NOT NULL,
    objective text NOT NULL,
    status text NOT NULL,
    floor jsonb,
    token_cap bigint,
    tokens_used bigint DEFAULT 0 NOT NULL,
    active_ms bigint,
    active_since timestamp with time zone,
    completion_note text,
    cancel_note text,
    governor jsonb,
    pause_reason text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT session_goals_status_check CHECK ((status = ANY (ARRAY['active'::text, 'paused'::text, 'complete'::text, 'cancelled'::text])))
);

ALTER TABLE ONLY public.session_goals FORCE ROW LEVEL SECURITY;


--
-- Name: session_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_leases (
    session_id text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    holder text,
    acquired_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_leases FORCE ROW LEVEL SECURITY;


--
-- Name: session_llm_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_llm_requests (
    id text NOT NULL,
    session_id text NOT NULL,
    turn_seq integer,
    step integer NOT NULL,
    model text NOT NULL,
    scope_label text NOT NULL,
    truncated boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    ttft_ms integer,
    duration_ms integer,
    step_gap_ms integer,
    tool_wall_json text,
    usage_json text,
    transport_json text,
    gap_phases_json text,
    prompt_hash text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_llm_requests FORCE ROW LEVEL SECURITY;


--
-- Name: session_mailbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_mailbox (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_mailbox FORCE ROW LEVEL SECURITY;


--
-- Name: session_pins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_pins (
    id text NOT NULL,
    session_id text NOT NULL,
    text text,
    entry_seq integer,
    added_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_pins FORCE ROW LEVEL SECURITY;


--
-- Name: session_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_shares (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_shares FORCE ROW LEVEL SECURITY;


--
-- Name: session_spend_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_days (
    day bigint NOT NULL,
    rows jsonb NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_spend_days FORCE ROW LEVEL SECURITY;


--
-- Name: session_spend_dirty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_dirty (
    day bigint,
    session_id text,
    writer xid8 DEFAULT pg_current_xact_id() NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT session_spend_dirty_check CHECK ((num_nonnulls(day, session_id) = 1))
);

ALTER TABLE ONLY public.session_spend_dirty FORCE ROW LEVEL SECURITY;


--
-- Name: session_turn_pointers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_turn_pointers (
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    thread_ref text NOT NULL,
    active_turn_id text,
    updated_at bigint NOT NULL
);

ALTER TABLE ONLY public.session_turn_pointers FORCE ROW LEVEL SECURITY;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    type text NOT NULL,
    scope_id text NOT NULL,
    thread_ref text NOT NULL,
    created_at bigint NOT NULL,
    title text,
    channel_name text,
    surface text,
    last_activity bigint,
    messages integer,
    turns integer,
    forked_from_session_id text,
    forked_from_title text,
    fork_boundary_seq integer,
    origin text,
    origin_id text,
    parent_session_id text,
    spawn_meta text,
    first_user_preview text,
    last_user_preview text,
    client_tools jsonb,
    last_user_activity bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
)
WITH (fillfactor='70');

ALTER TABLE ONLY public.sessions FORCE ROW LEVEL SECURITY;


--
-- Name: sharing_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sharing_postures (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.sharing_postures FORCE ROW LEVEL SECURITY;


--
-- Name: skill_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_bundles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.skill_bundles FORCE ROW LEVEL SECURITY;


--
-- Name: skill_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_packs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.skill_packs FORCE ROW LEVEL SECURITY;


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.skills FORCE ROW LEVEL SECURITY;


--
-- Name: slack_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_accounts (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.slack_accounts FORCE ROW LEVEL SECURITY;


--
-- Name: slack_emoji_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_emoji_catalog (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.slack_emoji_catalog FORCE ROW LEVEL SECURITY;


--
-- Name: slack_installation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_installation (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.slack_installation FORCE ROW LEVEL SECURITY;


--
-- Name: slack_session_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_session_status (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.slack_session_status FORCE ROW LEVEL SECURITY;


--
-- Name: slack_staged_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_staged_envelopes (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.slack_staged_envelopes FORCE ROW LEVEL SECURITY;


--
-- Name: slack_task_acknowledgements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_task_acknowledgements (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.slack_task_acknowledgements FORCE ROW LEVEL SECURITY;


--
-- Name: soul_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.soul_configs FORCE ROW LEVEL SECURITY;


--
-- Name: soul_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_history (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.soul_history FORCE ROW LEVEL SECURITY;


--
-- Name: source_auth_replay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_auth_replay (
    event_id text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.source_auth_replay FORCE ROW LEVEL SECURITY;


--
-- Name: suggested_activity_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suggested_activity_profiles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.suggested_activity_profiles FORCE ROW LEVEL SECURITY;


--
-- Name: superserve_config_epochs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_config_epochs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.superserve_config_epochs FORCE ROW LEVEL SECURITY;


--
-- Name: superserve_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.superserve_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    team_id text NOT NULL,
    principal_id text NOT NULL,
    role text NOT NULL,
    added_by text NOT NULL,
    added_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT team_members_role_check CHECK ((role = ANY (ARRAY['member'::text, 'admin'::text])))
);

ALTER TABLE ONLY public.team_members FORCE ROW LEVEL SECURITY;


--
-- Name: team_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_rooms (
    team_id text NOT NULL,
    scope_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.team_rooms FORCE ROW LEVEL SECURITY;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    team_id text NOT NULL,
    name text NOT NULL,
    isolated_in_open boolean DEFAULT false NOT NULL,
    created_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.teams FORCE ROW LEVEL SECURITY;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    slug text NOT NULL,
    org_id text NOT NULL,
    hosts text[] DEFAULT '{}'::text[] NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    env jsonb DEFAULT '{}'::jsonb NOT NULL,
    secret_env bytea,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenants_status_check CHECK ((status = ANY (ARRAY['active'::text, 'suspended'::text])))
);


--
-- Name: tool_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_calls (
    run_id text NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    call_index integer NOT NULL,
    output text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.tool_calls FORCE ROW LEVEL SECURITY;


--
-- Name: unfulfilled_insights_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unfulfilled_insights_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.unfulfilled_insights_flag FORCE ROW LEVEL SECURITY;


--
-- Name: web_ui_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_ui_state (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.web_ui_state FORCE ROW LEVEL SECURITY;


--
-- Name: webhook_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_history (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.webhook_history FORCE ROW LEVEL SECURITY;


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.webhooks FORCE ROW LEVEL SECURITY;


--
-- Name: webui_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webui_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.webui_model_configs FORCE ROW LEVEL SECURITY;


--
-- Name: ack_emoji_picks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks ALTER COLUMN id SET DEFAULT nextval('public.ack_emoji_picks_id_seq'::regclass);


--
-- Name: ambient_judgments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments ALTER COLUMN id SET DEFAULT nextval('public.ambient_judgments_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: channel_policy_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history ALTER COLUMN id SET DEFAULT nextval('public.channel_policy_history_id_seq'::regclass);


--
-- Name: credential_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage ALTER COLUMN id SET DEFAULT nextval('public.credential_usage_id_seq'::regclass);


--
-- Name: egress_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events ALTER COLUMN id SET DEFAULT nextval('public.egress_events_id_seq'::regclass);


--
-- Name: error_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events ALTER COLUMN id SET DEFAULT nextval('public.error_events_id_seq'::regclass);


--
-- Name: memory_facts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts ALTER COLUMN id SET DEFAULT nextval('public.memory_facts_id_seq'::regclass);


--
-- Name: run_activity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity ALTER COLUMN id SET DEFAULT nextval('public.run_activity_id_seq'::regclass);


--
-- Name: run_signals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals ALTER COLUMN id SET DEFAULT nextval('public.run_signals_id_seq'::regclass);


--
-- Name: runs seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs ALTER COLUMN seq SET DEFAULT nextval('public.runs_seq_seq'::regclass);


--
-- Name: c_turns_background c_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_background
    ADD CONSTRAINT c_turns_background_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_background_t111111110000 c_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_background_t111111110000
    ADD CONSTRAINT c_turns_background_t111111110000_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_delegated c_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_delegated
    ADD CONSTRAINT c_turns_delegated_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_delegated_t111111110000 c_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_delegated_t111111110000
    ADD CONSTRAINT c_turns_delegated_t111111110000_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_people c_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_people
    ADD CONSTRAINT c_turns_people_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_people_t111111110000 c_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_people_t111111110000
    ADD CONSTRAINT c_turns_people_t111111110000_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: e_turns_background e_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_background
    ADD CONSTRAINT e_turns_background_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_background_t111111110000 e_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_background_t111111110000
    ADD CONSTRAINT e_turns_background_t111111110000_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_delegated e_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_delegated
    ADD CONSTRAINT e_turns_delegated_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_delegated_t111111110000 e_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_delegated_t111111110000
    ADD CONSTRAINT e_turns_delegated_t111111110000_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_people e_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_people
    ADD CONSTRAINT e_turns_people_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_people_t111111110000 e_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_people_t111111110000
    ADD CONSTRAINT e_turns_people_t111111110000_pkey PRIMARY KEY (event_name);


--
-- Name: queues queues_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.queues
    ADD CONSTRAINT queues_pkey PRIMARY KEY (queue_name);


--
-- Name: r_turns_background r_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_background
    ADD CONSTRAINT r_turns_background_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_background_t111111110000 r_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_background_t111111110000
    ADD CONSTRAINT r_turns_background_t111111110000_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_delegated r_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_delegated
    ADD CONSTRAINT r_turns_delegated_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_delegated_t111111110000 r_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_delegated_t111111110000
    ADD CONSTRAINT r_turns_delegated_t111111110000_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_people r_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_people
    ADD CONSTRAINT r_turns_people_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_people_t111111110000 r_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_people_t111111110000
    ADD CONSTRAINT r_turns_people_t111111110000_pkey PRIMARY KEY (run_id);


--
-- Name: t_turns_background t_turns_background_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_background
    ADD CONSTRAINT t_turns_background_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_background t_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_background
    ADD CONSTRAINT t_turns_background_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_background_t111111110000 t_turns_background_t111111110000_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_background_t111111110000
    ADD CONSTRAINT t_turns_background_t111111110000_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_background_t111111110000 t_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_background_t111111110000
    ADD CONSTRAINT t_turns_background_t111111110000_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_delegated t_turns_delegated_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_delegated
    ADD CONSTRAINT t_turns_delegated_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_delegated t_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_delegated
    ADD CONSTRAINT t_turns_delegated_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_delegated_t111111110000 t_turns_delegated_t111111110000_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_delegated_t111111110000
    ADD CONSTRAINT t_turns_delegated_t111111110000_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_delegated_t111111110000 t_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_delegated_t111111110000
    ADD CONSTRAINT t_turns_delegated_t111111110000_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_people t_turns_people_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_people
    ADD CONSTRAINT t_turns_people_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_people t_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_people
    ADD CONSTRAINT t_turns_people_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_people_t111111110000 t_turns_people_t111111110000_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_people_t111111110000
    ADD CONSTRAINT t_turns_people_t111111110000_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_people_t111111110000 t_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_people_t111111110000
    ADD CONSTRAINT t_turns_people_t111111110000_pkey PRIMARY KEY (task_id);


--
-- Name: w_turns_background w_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_background
    ADD CONSTRAINT w_turns_background_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_background_t111111110000 w_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_background_t111111110000
    ADD CONSTRAINT w_turns_background_t111111110000_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_delegated w_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_delegated
    ADD CONSTRAINT w_turns_delegated_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_delegated_t111111110000 w_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_delegated_t111111110000
    ADD CONSTRAINT w_turns_delegated_t111111110000_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_people w_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_people
    ADD CONSTRAINT w_turns_people_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_people_t111111110000 w_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_people_t111111110000
    ADD CONSTRAINT w_turns_people_t111111110000_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: ack_emoji_picks ack_emoji_picks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks
    ADD CONSTRAINT ack_emoji_picks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: ack_emoji ack_emoji_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji
    ADD CONSTRAINT ack_emoji_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: acl_grants acl_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants
    ADD CONSTRAINT acl_grants_pkey PRIMARY KEY (tenant_id, owner_scope_id, path, grantee_scope_id, permission);


--
-- Name: acl_grants_version acl_grants_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants_version
    ADD CONSTRAINT acl_grants_version_pkey PRIMARY KEY (tenant_id, only_row);


--
-- Name: admin_grants admin_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_grants
    ADD CONSTRAINT admin_grants_pkey PRIMARY KEY (tenant_id, principal_id, scope_id, role);


--
-- Name: ambient_cursors ambient_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_cursors
    ADD CONSTRAINT ambient_cursors_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: ambient_judgments ambient_judgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments
    ADD CONSTRAINT ambient_judgments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approval_grant_modes approval_grant_modes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grant_modes
    ADD CONSTRAINT approval_grant_modes_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approval_grants approval_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grants
    ADD CONSTRAINT approval_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: auth_broker_sessions auth_broker_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_broker_sessions
    ADD CONSTRAINT auth_broker_sessions_pkey PRIMARY KEY (tenant_id, token_hash);


--
-- Name: auto_flagger_configs auto_flagger_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_flagger_configs
    ADD CONSTRAINT auto_flagger_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: aws_sandbox_bodies aws_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_sandbox_bodies
    ADD CONSTRAINT aws_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: base_model_configs base_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_model_configs
    ADD CONSTRAINT base_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: blobs blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blobs
    ADD CONSTRAINT blobs_pkey PRIMARY KEY (tenant_id, sha256);


--
-- Name: branding_configs branding_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browse_max_steps_configs browse_max_steps_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_max_steps_configs
    ADD CONSTRAINT browse_max_steps_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browse_model_configs browse_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_model_configs
    ADD CONSTRAINT browse_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browser_sessions browser_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browser_sessions
    ADD CONSTRAINT browser_sessions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_files channel_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_files
    ADD CONSTRAINT channel_files_pkey PRIMARY KEY (tenant_id, org_id, container, ts, file_id);


--
-- Name: channel_header_pin_flag channel_header_pin_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_header_pin_flag
    ADD CONSTRAINT channel_header_pin_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_messages channel_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_messages
    ADD CONSTRAINT channel_messages_pkey PRIMARY KEY (tenant_id, org_id, container, ts);


--
-- Name: channel_policy_history channel_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history
    ADD CONSTRAINT channel_policy_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_policy channel_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy
    ADD CONSTRAINT channel_policy_pkey PRIMARY KEY (tenant_id, org_id, container);


--
-- Name: channel_state channel_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_state
    ADD CONSTRAINT channel_state_pkey PRIMARY KEY (tenant_id, org_id, container);


--
-- Name: command_policies command_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_policies
    ADD CONSTRAINT command_policies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: composio_returns composio_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composio_returns
    ADD CONSTRAINT composio_returns_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: connector_clients connector_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_clients
    ADD CONSTRAINT connector_clients_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: connector_status connector_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_status
    ADD CONSTRAINT connector_status_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: consent_links consent_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_links
    ADD CONSTRAINT consent_links_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: context_requests context_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.context_requests
    ADD CONSTRAINT context_requests_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: credential_daily_calls credential_daily_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_daily_calls
    ADD CONSTRAINT credential_daily_calls_pkey PRIMARY KEY (tenant_id, slug, day);


--
-- Name: credential_usage credential_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage
    ADD CONSTRAINT credential_usage_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: cron_fires cron_fires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fires
    ADD CONSTRAINT cron_fires_pkey PRIMARY KEY (tenant_id, cron_id, fire_key);


--
-- Name: cron_items cron_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_items
    ADD CONSTRAINT cron_items_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: crons crons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crons
    ADD CONSTRAINT crons_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: custom_model_providers custom_model_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_model_providers
    ADD CONSTRAINT custom_model_providers_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deactivated_principals deactivated_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deactivated_principals
    ADD CONSTRAINT deactivated_principals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: decision_providers decision_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_providers
    ADD CONSTRAINT decision_providers_pkey PRIMARY KEY (tenant_id, provider_id);


--
-- Name: decision_rules decision_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_pkey PRIMARY KEY (tenant_id, rule_id);


--
-- Name: deploy_git_repos deploy_git_repos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_git_repos
    ADD CONSTRAINT deploy_git_repos_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_access deployment_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_identity deployment_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_identity
    ADD CONSTRAINT deployment_identity_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_layer deployment_layer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_layer
    ADD CONSTRAINT deployment_layer_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: directory_channel_members directory_channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channel_members
    ADD CONSTRAINT directory_channel_members_pkey PRIMARY KEY (tenant_id, org_id, channel_id, principal_id);


--
-- Name: directory_channels directory_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channels
    ADD CONSTRAINT directory_channels_pkey PRIMARY KEY (tenant_id, org_id, channel_id);


--
-- Name: directory_group_members directory_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_group_members
    ADD CONSTRAINT directory_group_members_pkey PRIMARY KEY (tenant_id, org_id, group_id, principal_id);


--
-- Name: directory_groups directory_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_groups
    ADD CONSTRAINT directory_groups_pkey PRIMARY KEY (tenant_id, org_id, group_id);


--
-- Name: directory_members directory_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_members
    ADD CONSTRAINT directory_members_pkey PRIMARY KEY (tenant_id, org_id, principal_id);


--
-- Name: directory_meta directory_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_meta
    ADD CONSTRAINT directory_meta_pkey PRIMARY KEY (tenant_id, org_id);


--
-- Name: directory_sync directory_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_sync
    ADD CONSTRAINT directory_sync_pkey PRIMARY KEY (tenant_id, org_id);


--
-- Name: durable_map_versions durable_map_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.durable_map_versions
    ADD CONSTRAINT durable_map_versions_pkey PRIMARY KEY (tenant_id, tbl);


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2b_sandbox_bodies
    ADD CONSTRAINT e2b_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: egress_events egress_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events
    ADD CONSTRAINT egress_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: egress_policies egress_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_policies
    ADD CONSTRAINT egress_policies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: environment_attachments environment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_pkey PRIMARY KEY (tenant_id, scope_id);


--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: error_events error_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events
    ADD CONSTRAINT error_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: external_members external_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_members
    ADD CONSTRAINT external_members_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: external_slack_participants_flag external_slack_participants_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_slack_participants_flag
    ADD CONSTRAINT external_slack_participants_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_artifact_deletions file_artifact_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifact_deletions
    ADD CONSTRAINT file_artifact_deletions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_artifacts file_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifacts
    ADD CONSTRAINT file_artifacts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: idempotency idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency
    ADD CONSTRAINT idempotency_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: individual_model_auth_flag individual_model_auth_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.individual_model_auth_flag
    ADD CONSTRAINT individual_model_auth_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactive_fast_mode_flag
    ADD CONSTRAINT interactive_fast_mode_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (tenant_id, session_id, seq);


--
-- Name: keychain_asks keychain_asks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_asks
    ADD CONSTRAINT keychain_asks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: keychain_credentials keychain_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_credentials
    ADD CONSTRAINT keychain_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: keychain_grants keychain_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_grants
    ADD CONSTRAINT keychain_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: llm_prompt_envelopes llm_prompt_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_prompt_envelopes
    ADD CONSTRAINT llm_prompt_envelopes_pkey PRIMARY KEY (tenant_id, hash);


--
-- Name: local_sandbox_bodies local_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_sandbox_bodies
    ADD CONSTRAINT local_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_items loop_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_items
    ADD CONSTRAINT loop_items_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loops loops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loops
    ADD CONSTRAINT loops_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_facts memory_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_tidy_profiles memory_tidy_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_tidy_profiles
    ADD CONSTRAINT memory_tidy_profiles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modal_sandbox_bodies
    ADD CONSTRAINT modal_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: model_credentials model_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_credentials
    ADD CONSTRAINT model_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: monitors monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: oauth_flows oauth_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_flows
    ADD CONSTRAINT oauth_flows_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: org_ambient_flag org_ambient_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_ambient_flag
    ADD CONSTRAINT org_ambient_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (tenant_id, session_id, principal_id);


--
-- Name: principal_links principal_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.principal_links
    ADD CONSTRAINT principal_links_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: process_sessions process_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_sessions
    ADD CONSTRAINT process_sessions_pkey PRIMARY KEY (tenant_id, process_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: qm_schema_migrations qm_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_schema_migrations
    ADD CONSTRAINT qm_schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: qm_settings qm_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_settings
    ADD CONSTRAINT qm_settings_pkey PRIMARY KEY (tenant_id, key);


--
-- Name: qm_tenant qm_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_tenant
    ADD CONSTRAINT qm_tenant_pkey PRIMARY KEY (id);


--
-- Name: queued_posts queued_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queued_posts
    ADD CONSTRAINT queued_posts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: rate_limit_windows rate_limit_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_windows
    ADD CONSTRAINT rate_limit_windows_pkey PRIMARY KEY (tenant_id, principal_id);


--
-- Name: recent_dm_posts recent_dm_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recent_dm_posts
    ADD CONSTRAINT recent_dm_posts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: run_activity run_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity
    ADD CONSTRAINT run_activity_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: run_signals run_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals
    ADD CONSTRAINT run_signals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: runs runs_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_idempotency_key_key UNIQUE (tenant_id, idempotency_key);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_defaults sandbox_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_defaults
    ADD CONSTRAINT sandbox_defaults_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_resource_rollout sandbox_resource_rollout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resource_rollout
    ADD CONSTRAINT sandbox_resource_rollout_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_resources sandbox_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resources
    ADD CONSTRAINT sandbox_resources_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_routing sandbox_routing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_routing
    ADD CONSTRAINT sandbox_routing_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: secret_drops secret_drops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_drops
    ADD CONSTRAINT secret_drops_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: security_postures security_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_postures
    ADD CONSTRAINT security_postures_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_goals session_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_pkey PRIMARY KEY (tenant_id, session_id);


--
-- Name: session_leases session_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_leases
    ADD CONSTRAINT session_leases_pkey PRIMARY KEY (tenant_id, session_id);


--
-- Name: session_llm_requests session_llm_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_llm_requests
    ADD CONSTRAINT session_llm_requests_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_mailbox session_mailbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_mailbox
    ADD CONSTRAINT session_mailbox_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_pins session_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_pins
    ADD CONSTRAINT session_pins_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_shares session_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_shares
    ADD CONSTRAINT session_shares_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_spend_days session_spend_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_days
    ADD CONSTRAINT session_spend_days_pkey PRIMARY KEY (tenant_id, day);


--
-- Name: session_spend_dirty session_spend_dirty_day_writer_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_dirty
    ADD CONSTRAINT session_spend_dirty_day_writer_key UNIQUE (tenant_id, day, writer);


--
-- Name: session_turn_pointers session_turn_pointers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_pointers
    ADD CONSTRAINT session_turn_pointers_pkey PRIMARY KEY (tenant_id, thread_ref);


--
-- Name: sessions sessions_fork_provenance_pair; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.sessions
    ADD CONSTRAINT sessions_fork_provenance_pair CHECK (((forked_from_session_id IS NULL) = (fork_boundary_seq IS NULL))) NOT VALID;


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sessions sessions_thread_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_thread_ref_key UNIQUE (tenant_id, thread_ref);


--
-- Name: sharing_postures sharing_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sharing_postures
    ADD CONSTRAINT sharing_postures_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skill_bundles skill_bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_bundles
    ADD CONSTRAINT skill_bundles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skill_packs skill_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_accounts slack_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_accounts
    ADD CONSTRAINT slack_accounts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_emoji_catalog slack_emoji_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_emoji_catalog
    ADD CONSTRAINT slack_emoji_catalog_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_installation slack_installation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_installation
    ADD CONSTRAINT slack_installation_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_session_status slack_session_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_session_status
    ADD CONSTRAINT slack_session_status_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_staged_envelopes slack_staged_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_staged_envelopes
    ADD CONSTRAINT slack_staged_envelopes_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_task_acknowledgements
    ADD CONSTRAINT slack_task_acknowledgements_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: soul_configs soul_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_configs
    ADD CONSTRAINT soul_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: soul_history soul_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_history
    ADD CONSTRAINT soul_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: source_auth_replay source_auth_replay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_auth_replay
    ADD CONSTRAINT source_auth_replay_pkey PRIMARY KEY (tenant_id, event_id);


--
-- Name: suggested_activity_profiles suggested_activity_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggested_activity_profiles
    ADD CONSTRAINT suggested_activity_profiles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: superserve_config_epochs superserve_config_epochs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_config_epochs
    ADD CONSTRAINT superserve_config_epochs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: superserve_sandbox_bodies superserve_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_sandbox_bodies
    ADD CONSTRAINT superserve_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (tenant_id, team_id, principal_id);


--
-- Name: team_rooms team_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_pkey PRIMARY KEY (tenant_id, team_id, scope_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (tenant_id, team_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: tool_calls tool_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls
    ADD CONSTRAINT tool_calls_pkey PRIMARY KEY (tenant_id, run_id, attempt, call_index);


--
-- Name: unfulfilled_insights_flag unfulfilled_insights_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unfulfilled_insights_flag
    ADD CONSTRAINT unfulfilled_insights_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: web_ui_state web_ui_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_ui_state
    ADD CONSTRAINT web_ui_state_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webhook_history webhook_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_history
    ADD CONSTRAINT webhook_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webui_model_configs webui_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webui_model_configs
    ADD CONSTRAINT webui_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: e_turns_background_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_background_eai ON absurd.e_turns_background USING btree (emitted_at);


--
-- Name: e_turns_background_t111111110000_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_background_t111111110000_eai ON absurd.e_turns_background_t111111110000 USING btree (emitted_at);


--
-- Name: e_turns_delegated_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_delegated_eai ON absurd.e_turns_delegated USING btree (emitted_at);


--
-- Name: e_turns_delegated_t111111110000_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_delegated_t111111110000_eai ON absurd.e_turns_delegated_t111111110000 USING btree (emitted_at);


--
-- Name: e_turns_people_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_people_eai ON absurd.e_turns_people USING btree (emitted_at);


--
-- Name: e_turns_people_t111111110000_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_people_t111111110000_eai ON absurd.e_turns_people_t111111110000 USING btree (emitted_at);


--
-- Name: r_turns_background_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_cei ON absurd.r_turns_background USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_background_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_sai ON absurd.r_turns_background USING btree (state, available_at);


--
-- Name: r_turns_background_t111111110000_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_t111111110000_cei ON absurd.r_turns_background_t111111110000 USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_background_t111111110000_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_t111111110000_sai ON absurd.r_turns_background_t111111110000 USING btree (state, available_at);


--
-- Name: r_turns_background_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_t111111110000_ti ON absurd.r_turns_background_t111111110000 USING btree (task_id);


--
-- Name: r_turns_background_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_ti ON absurd.r_turns_background USING btree (task_id);


--
-- Name: r_turns_delegated_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_cei ON absurd.r_turns_delegated USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_delegated_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_sai ON absurd.r_turns_delegated USING btree (state, available_at);


--
-- Name: r_turns_delegated_t111111110000_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_t111111110000_cei ON absurd.r_turns_delegated_t111111110000 USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_delegated_t111111110000_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_t111111110000_sai ON absurd.r_turns_delegated_t111111110000 USING btree (state, available_at);


--
-- Name: r_turns_delegated_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_t111111110000_ti ON absurd.r_turns_delegated_t111111110000 USING btree (task_id);


--
-- Name: r_turns_delegated_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_ti ON absurd.r_turns_delegated USING btree (task_id);


--
-- Name: r_turns_people_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_cei ON absurd.r_turns_people USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_people_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_sai ON absurd.r_turns_people USING btree (state, available_at);


--
-- Name: r_turns_people_t111111110000_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_t111111110000_cei ON absurd.r_turns_people_t111111110000 USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_people_t111111110000_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_t111111110000_sai ON absurd.r_turns_people_t111111110000 USING btree (state, available_at);


--
-- Name: r_turns_people_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_t111111110000_ti ON absurd.r_turns_people_t111111110000 USING btree (task_id);


--
-- Name: r_turns_people_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_ti ON absurd.r_turns_people USING btree (task_id);


--
-- Name: t_turns_background_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_background_ci ON absurd.t_turns_background USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_background_t111111110000_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_background_t111111110000_ci ON absurd.t_turns_background_t111111110000 USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_delegated_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_delegated_ci ON absurd.t_turns_delegated USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_delegated_t111111110000_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_delegated_t111111110000_ci ON absurd.t_turns_delegated_t111111110000 USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_people_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_people_ci ON absurd.t_turns_people USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_people_t111111110000_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_people_t111111110000_ci ON absurd.t_turns_people_t111111110000 USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: w_turns_background_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_background_eni ON absurd.w_turns_background USING btree (event_name);


--
-- Name: w_turns_background_t111111110000_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_background_t111111110000_eni ON absurd.w_turns_background_t111111110000 USING btree (event_name);


--
-- Name: w_turns_background_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_background_t111111110000_ti ON absurd.w_turns_background_t111111110000 USING btree (task_id);


--
-- Name: w_turns_background_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_background_ti ON absurd.w_turns_background USING btree (task_id);


--
-- Name: w_turns_delegated_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_delegated_eni ON absurd.w_turns_delegated USING btree (event_name);


--
-- Name: w_turns_delegated_t111111110000_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_delegated_t111111110000_eni ON absurd.w_turns_delegated_t111111110000 USING btree (event_name);


--
-- Name: w_turns_delegated_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_delegated_t111111110000_ti ON absurd.w_turns_delegated_t111111110000 USING btree (task_id);


--
-- Name: w_turns_delegated_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_delegated_ti ON absurd.w_turns_delegated USING btree (task_id);


--
-- Name: w_turns_people_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_people_eni ON absurd.w_turns_people USING btree (event_name);


--
-- Name: w_turns_people_t111111110000_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_people_t111111110000_eni ON absurd.w_turns_people_t111111110000 USING btree (event_name);


--
-- Name: w_turns_people_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_people_t111111110000_ti ON absurd.w_turns_people_t111111110000 USING btree (task_id);


--
-- Name: w_turns_people_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_people_ti ON absurd.w_turns_people USING btree (task_id);


--
-- Name: ack_emoji_picks_org_channel_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_channel_created ON public.ack_emoji_picks USING btree (org_id, channel, created_at DESC);


--
-- Name: ack_emoji_picks_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_created ON public.ack_emoji_picks USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ack_emoji_picks_org_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_outcome ON public.ack_emoji_picks USING btree (org_id, outcome);


--
-- Name: ambient_judgments_org_container_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_container_created ON public.ambient_judgments USING btree (org_id, container, created_at DESC);


--
-- Name: ambient_judgments_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_created ON public.ambient_judgments USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ambient_judgments_org_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_decision ON public.ambient_judgments USING btree (org_id, decision);


--
-- Name: approvals_sessionid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_sessionid_fold ON public.approvals USING hash (lower((json ->> 'sessionId'::text)));


--
-- Name: approvals_sessionid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_sessionid_unicode ON public.approvals USING btree (id) WHERE ((json ->> 'sessionId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: audit_log_by_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_action ON public.audit_log USING btree (action, at DESC);


--
-- Name: audit_log_by_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_at ON public.audit_log USING btree (at DESC);


--
-- Name: audit_log_by_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX audit_log_by_idempotency_key ON public.audit_log USING btree (tenant_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: audit_log_by_scope_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_scope_at ON public.audit_log USING btree (scope_label, at DESC);


--
-- Name: auth_broker_sessions_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_email ON public.auth_broker_sessions USING btree (email);


--
-- Name: auth_broker_sessions_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_expiry ON public.auth_broker_sessions USING btree (expires_at);


--
-- Name: channel_messages_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_container ON public.channel_messages USING btree (org_id, container, ts);


--
-- Name: channel_messages_by_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_sub ON public.channel_messages USING btree (org_id, container, sub, ts);


--
-- Name: channel_messages_deleted_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_deleted_by_container ON public.channel_messages USING btree (org_id, container, deleted_at) WHERE (deleted_at > 0);


--
-- Name: channel_messages_edited_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_edited_by_container ON public.channel_messages USING btree (org_id, container, edited_at) WHERE (edited_at > 0);


--
-- Name: channel_messages_live_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_live_by_container ON public.channel_messages USING btree (org_id, container) WHERE (deleted = false);


--
-- Name: channel_messages_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_tsv ON public.channel_messages USING gin (tsv);


--
-- Name: channel_policy_history_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_policy_history_container ON public.channel_policy_history USING btree (org_id, container, id DESC);


--
-- Name: credential_usage_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_scope_ts ON public.credential_usage USING btree (scope_label, ts DESC);


--
-- Name: credential_usage_by_slug_ts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_slug_ts_id ON public.credential_usage USING btree (slug, ts DESC, id DESC);


--
-- Name: credential_usage_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_ts ON public.credential_usage USING btree (ts DESC);


--
-- Name: cron_items_cronid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cron_items_cronid_fold ON public.cron_items USING hash (lower((json ->> 'cronId'::text)));


--
-- Name: cron_items_cronid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cron_items_cronid_unicode ON public.cron_items USING btree (id) WHERE ((json ->> 'cronId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: crons_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_resource_search_gin ON public.crons USING gin (to_tsvector('simple'::regconfig, ((((COALESCE((json ->> 'title'::text), ''::text) || ' '::text) || COALESCE((json ->> 'action'::text), ''::text)) || ' '::text) || COALESCE((json ->> 'message'::text), ''::text))));


--
-- Name: decision_rules_hook; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX decision_rules_hook ON public.decision_rules USING btree (hook) WHERE (mode <> 'off'::text);


--
-- Name: deployments_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployments_resource_search_gin ON public.deployments USING gin (to_tsvector('simple'::regconfig, ((COALESCE((json ->> 'displayName'::text), (json ->> 'name'::text), ''::text) || ' '::text) || COALESCE((json ->> 'name'::text), ''::text))));


--
-- Name: directory_channels_lower_cid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_lower_cid ON public.directory_channels USING btree (org_id, lower(channel_id));


--
-- Name: directory_channels_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_name ON public.directory_channels USING btree (org_id, name_lc);


--
-- Name: directory_group_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_group_members_principal ON public.directory_group_members USING btree (org_id, principal_id, group_id);


--
-- Name: directory_members_lower_pid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_lower_pid ON public.directory_members USING btree (org_id, lower(principal_id));


--
-- Name: directory_members_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_name ON public.directory_members USING btree (org_id, display_name_lc);


--
-- Name: egress_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_scope_ts ON public.egress_events USING btree (scope_label, ts DESC);


--
-- Name: egress_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_ts ON public.egress_events USING btree (ts DESC);


--
-- Name: environment_attachments_by_env; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_attachments_by_env ON public.environment_attachments USING btree (environment_id);


--
-- Name: error_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_scope_ts ON public.error_events USING btree (scope_label, ts DESC);


--
-- Name: error_events_by_session_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_session_ts ON public.error_events USING btree (session_id, ts DESC);


--
-- Name: error_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_ts ON public.error_events USING btree (ts DESC);


--
-- Name: file_artifacts_owner_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_created ON public.file_artifacts USING btree (owner_scope_id, created_at DESC, id DESC);


--
-- Name: file_artifacts_owner_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_path ON public.file_artifacts USING btree (owner_scope_id, path);


--
-- Name: file_artifacts_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_scope_created ON public.file_artifacts USING btree (created_in_scope, created_at DESC, id DESC) WHERE (enabled = true);


--
-- Name: idx_cron_fires_cron_fired_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_cron_fired_at ON public.cron_fires USING btree (cron_id, fired_at DESC);


--
-- Name: idx_cron_fires_thread_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_thread_ref ON public.cron_fires USING btree (thread_ref);


--
-- Name: idx_proc_scope_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proc_scope_status ON public.process_sessions USING btree (scope_id, status);


--
-- Name: idx_run_activity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_created ON public.run_activity USING btree (created_at);


--
-- Name: idx_run_activity_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_run ON public.run_activity USING btree (run_id, id);


--
-- Name: idx_run_signals_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_signals_pending ON public.run_signals USING btree (run_id) WHERE (consumed_at IS NULL);


--
-- Name: idx_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_created ON public.runs USING btree (created_at DESC);


--
-- Name: idx_runs_fair_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_fair_key ON public.runs USING btree (fair_key, status) WHERE ((fair_key IS NOT NULL) AND (status = ANY (ARRAY['queued'::text, 'pending'::text, 'running'::text])));


--
-- Name: idx_runs_one_running_per_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_runs_one_running_per_session ON public.runs USING btree (tenant_id, session_id) WHERE (status = 'running'::text);


--
-- Name: idx_runs_pending_child_returns; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_child_returns ON public.runs USING btree (id) WHERE ((status = ANY (ARRAY['done'::text, 'failed'::text])) AND (returned_at IS NULL) AND (session_id ~~ 'agent:main:subagent:%'::text));


--
-- Name: idx_runs_pending_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_priority ON public.runs USING btree (claim_priority, created_at, seq) WHERE (status = 'pending'::text);


--
-- Name: idx_runs_session_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_active_created ON public.runs USING btree (session_id, created_at DESC) WHERE (status = ANY (ARRAY['pending'::text, 'running'::text]));


--
-- Name: idx_runs_session_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_created_seq ON public.runs USING btree (session_id, created_at DESC, seq DESC);


--
-- Name: idx_runs_session_in_flight; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_in_flight ON public.runs USING btree (session_id, created_at, seq) WHERE (status = ANY (ARRAY['queued'::text, 'pending'::text, 'running'::text]));


--
-- Name: idx_runs_session_queued; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_queued ON public.runs USING btree (session_id, claim_priority, created_at, seq) WHERE (status = 'queued'::text);


--
-- Name: idx_runs_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created ON public.runs USING btree (status, created_at);


--
-- Name: idx_runs_status_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created_seq ON public.runs USING btree (status, created_at, seq);


--
-- Name: idx_runs_terminal_finished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_terminal_finished ON public.runs USING btree (finished_at, id) WHERE (status = ANY (ARRAY['done'::text, 'failed'::text]));


--
-- Name: idx_sessions_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_parent_session_id ON public.sessions USING btree (parent_session_id) WHERE (parent_session_id IS NOT NULL);


--
-- Name: items_by_elicit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_elicit ON public.items USING btree (tenant_id, session_id, elicit_id) WHERE (elicit_id IS NOT NULL);


--
-- Name: items_by_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_external_id ON public.items USING btree (tenant_id, session_id, external_id) WHERE (external_id IS NOT NULL);


--
-- Name: items_by_turn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_turn ON public.items USING btree (tenant_id, turn_id, seq) WHERE (turn_id IS NOT NULL);


--
-- Name: items_one_call_per_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX items_one_call_per_kind ON public.items USING btree (tenant_id, session_id, kind, md5(call_id)) WHERE (call_id IS NOT NULL);


--
-- Name: items_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_search ON public.items USING gin (tenant_id, session_id, search);


--
-- Name: items_session_kind_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_session_kind_created ON public.items USING btree (tenant_id, session_id, kind, created_at);


--
-- Name: keychain_credentials_ownerid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_ownerid_fold ON public.keychain_credentials USING hash (lower((json ->> 'ownerId'::text)));


--
-- Name: keychain_credentials_ownerid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_ownerid_unicode ON public.keychain_credentials USING btree (id) WHERE ((json ->> 'ownerId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: keychain_grants_ownerid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_ownerid_fold ON public.keychain_grants USING hash (lower((json ->> 'ownerId'::text)));


--
-- Name: keychain_grants_ownerid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_ownerid_unicode ON public.keychain_grants USING btree (id) WHERE ((json ->> 'ownerId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: llm_prompt_envelopes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX llm_prompt_envelopes_created_at ON public.llm_prompt_envelopes USING btree (created_at);


--
-- Name: memory_facts_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX memory_facts_live ON public.memory_facts USING btree (scope_id, id) WHERE (deleted_at IS NULL);


--
-- Name: participants_by_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX participants_by_principal ON public.participants USING btree (principal_id, session_id);


--
-- Name: qm_tenant_singleton; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qm_tenant_singleton ON public.qm_tenant USING btree ((true));


--
-- Name: run_signals_by_dedupe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX run_signals_by_dedupe_key ON public.run_signals USING btree (tenant_id, dedupe_key) WHERE (dedupe_key IS NOT NULL);


--
-- Name: session_llm_requests_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_by_session ON public.session_llm_requests USING btree (session_id, created_at, step);


--
-- Name: session_llm_requests_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_created_at ON public.session_llm_requests USING btree (created_at);


--
-- Name: session_llm_requests_screens; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_screens ON public.session_llm_requests USING btree (created_at DESC) WHERE (step = '-1'::integer);


--
-- Name: session_llm_requests_spend; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend ON public.session_llm_requests USING btree (created_at, (((public.spend_usage_json(usage_json) ->> 'costUsd'::text))::double precision), (((public.spend_usage_json(usage_json) ->> 'input'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'output'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'cacheRead'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'cacheWrite'::text))::bigint)) INCLUDE (session_id, model, usage_json) WHERE ((usage_json IS NOT NULL) AND ((public.spend_usage_json(usage_json) IS NOT NULL) AND (((octet_length(session_id) + octet_length(model)) + octet_length(usage_json)) <= 2000)));


--
-- Name: session_llm_requests_spend_wide; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend_wide ON public.session_llm_requests USING btree (created_at) WHERE ((usage_json IS NOT NULL) AND (NOT ((public.spend_usage_json(usage_json) IS NOT NULL) AND (((octet_length(session_id) + octet_length(model)) + octet_length(usage_json)) <= 2000))));


--
-- Name: session_mailbox_recipientid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipientid_fold ON public.session_mailbox USING hash (lower((json ->> 'recipientId'::text)));


--
-- Name: session_mailbox_recipientid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipientid_unicode ON public.session_mailbox USING btree (id) WHERE ((json ->> 'recipientId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: session_pins_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_pins_by_session ON public.session_pins USING btree (session_id, created_at);


--
-- Name: session_turn_pointers_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_turn_pointers_active ON public.session_turn_pointers USING btree (tenant_id, updated_at) WHERE (active_turn_id IS NOT NULL);


--
-- Name: sessions_by_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_activity ON public.sessions USING btree (COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_by_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope ON public.sessions USING btree (scope_id, created_at DESC);


--
-- Name: sessions_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_conversations_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_conversations_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin = 'conversation'::text);


--
-- Name: sessions_other_background_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_other_background_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin <> ALL (ARRAY['conversation'::text, 'cron'::text]));


--
-- Name: skills_resource_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_name_idx ON public.skills USING btree ((((json -> 'manifest'::text) ->> 'name'::text)));


--
-- Name: skills_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_search_gin ON public.skills USING gin (to_tsvector('simple'::regconfig, ((COALESCE(((json -> 'manifest'::text) ->> 'name'::text), ''::text) || ' '::text) || COALESCE(((json -> 'manifest'::text) ->> 'description'::text), ''::text))));


--
-- Name: source_auth_replay_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_auth_replay_expires_at ON public.source_auth_replay USING btree (expires_at);


--
-- Name: team_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_members_principal ON public.team_members USING btree (principal_id);


--
-- Name: team_rooms_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_rooms_scope ON public.team_rooms USING btree (scope_id);


--
-- Name: webhooks_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_resource_search_gin ON public.webhooks USING gin (to_tsvector('simple'::regconfig, ((COALESCE((json ->> 'action'::text), ''::text) || ' '::text) || COALESCE(((json -> 'verification'::text) ->> 'scheme'::text), ''::text))));


--
-- Name: approvals_sessionid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.approvals_sessionid_stats ON (json ->> 'sessionId'::text) FROM public.approvals;


--
-- Name: cron_items_cronid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.cron_items_cronid_stats ON (json ->> 'cronId'::text) FROM public.cron_items;


--
-- Name: keychain_credentials_ownerid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.keychain_credentials_ownerid_stats ON (json ->> 'ownerId'::text) FROM public.keychain_credentials;


--
-- Name: keychain_grants_ownerid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.keychain_grants_ownerid_stats ON (json ->> 'ownerId'::text) FROM public.keychain_grants;


--
-- Name: session_mailbox_recipientid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.session_mailbox_recipientid_stats ON (json ->> 'recipientId'::text) FROM public.session_mailbox;


--
-- Name: acl_grants acl_grants_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER acl_grants_bump AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.acl_grants FOR EACH STATEMENT EXECUTE FUNCTION public.acl_grants_bump_version();


--
-- Name: blobs blobs_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_immutable BEFORE DELETE OR UPDATE ON public.blobs FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: blobs blobs_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_no_truncate BEFORE TRUNCATE ON public.blobs FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_append_only BEFORE UPDATE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_delete_through_session; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_delete_through_session BEFORE DELETE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_direct_delete();


--
-- Name: items items_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_no_truncate BEFORE TRUNCATE ON public.items FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: session_llm_requests session_llm_requests_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_llm_requests_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF created_at, session_id, model, usage_json ON public.session_llm_requests FOR EACH ROW EXECUTE FUNCTION public.invalidate_request_spend();


--
-- Name: sessions sessions_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sessions_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF id, scope_id, origin, thread_ref, parent_session_id ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.invalidate_session_spend();


--
-- Name: decision_rules decision_rules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_provider_id_fkey FOREIGN KEY (tenant_id, provider_id) REFERENCES public.decision_providers(tenant_id, provider_id);


--
-- Name: deployment_access deployment_access_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_id_fkey FOREIGN KEY (tenant_id, id) REFERENCES public.deployments(tenant_id, id) ON DELETE CASCADE;


--
-- Name: environment_attachments environment_attachments_environment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_environment_id_fkey FOREIGN KEY (tenant_id, environment_id) REFERENCES public.environments(tenant_id, id);


--
-- Name: items items_blob; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_blob FOREIGN KEY (tenant_id, blob_sha) REFERENCES public.blobs(tenant_id, sha256);


--
-- Name: items items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_session_id_fkey FOREIGN KEY (tenant_id, session_id) REFERENCES public.sessions(tenant_id, id) ON DELETE CASCADE;


--
-- Name: session_goals session_goals_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_session_id_fkey FOREIGN KEY (tenant_id, session_id) REFERENCES public.sessions(tenant_id, id) ON DELETE CASCADE;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (tenant_id, team_id) REFERENCES public.teams(tenant_id, team_id) ON DELETE CASCADE;


--
-- Name: team_rooms team_rooms_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_team_id_fkey FOREIGN KEY (tenant_id, team_id) REFERENCES public.teams(tenant_id, team_id) ON DELETE CASCADE;


--
-- Name: ack_emoji; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ack_emoji ENABLE ROW LEVEL SECURITY;

--
-- Name: ack_emoji_picks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ack_emoji_picks ENABLE ROW LEVEL SECURITY;

--
-- Name: acl_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.acl_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: acl_grants_version; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.acl_grants_version ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: ambient_cursors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ambient_cursors ENABLE ROW LEVEL SECURITY;

--
-- Name: ambient_judgments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ambient_judgments ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_grant_modes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_grant_modes ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: approvals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approvals ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: auth_broker_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_broker_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: auto_flagger_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auto_flagger_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: aws_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.aws_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: base_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.base_model_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: blobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.blobs ENABLE ROW LEVEL SECURITY;

--
-- Name: branding_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.branding_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browse_max_steps_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browse_max_steps_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browse_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browse_model_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browser_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browser_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_files; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_files ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_header_pin_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_header_pin_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_policy; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_policy ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_policy_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_policy_history ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_state ENABLE ROW LEVEL SECURITY;

--
-- Name: command_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.command_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: composio_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.composio_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: connector_clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.connector_clients ENABLE ROW LEVEL SECURITY;

--
-- Name: connector_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.connector_status ENABLE ROW LEVEL SECURITY;

--
-- Name: consent_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.consent_links ENABLE ROW LEVEL SECURITY;

--
-- Name: context_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.context_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_daily_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credential_daily_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_usage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credential_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: cron_fires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cron_fires ENABLE ROW LEVEL SECURITY;

--
-- Name: cron_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cron_items ENABLE ROW LEVEL SECURITY;

--
-- Name: crons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.crons ENABLE ROW LEVEL SECURITY;

--
-- Name: custom_model_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.custom_model_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: deactivated_principals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deactivated_principals ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: deploy_git_repos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deploy_git_repos ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_access; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_access ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_identity; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_identity ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_layer; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_layer ENABLE ROW LEVEL SECURITY;

--
-- Name: deployments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployments ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_channel_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_channel_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_group_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_group_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_meta; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_meta ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_sync; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_sync ENABLE ROW LEVEL SECURITY;

--
-- Name: durable_map_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.durable_map_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: e2b_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.e2b_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: egress_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.egress_events ENABLE ROW LEVEL SECURITY;

--
-- Name: egress_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.egress_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: environment_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.environment_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: environments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.environments ENABLE ROW LEVEL SECURITY;

--
-- Name: error_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.error_events ENABLE ROW LEVEL SECURITY;

--
-- Name: external_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_members ENABLE ROW LEVEL SECURITY;

--
-- Name: external_slack_participants_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_slack_participants_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_flags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;

--
-- Name: file_artifact_deletions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_artifact_deletions ENABLE ROW LEVEL SECURITY;

--
-- Name: file_artifacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_artifacts ENABLE ROW LEVEL SECURITY;

--
-- Name: idempotency; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.idempotency ENABLE ROW LEVEL SECURITY;

--
-- Name: individual_model_auth_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.individual_model_auth_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: interactive_fast_mode_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.interactive_fast_mode_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_asks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_asks ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: llm_prompt_envelopes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.llm_prompt_envelopes ENABLE ROW LEVEL SECURITY;

--
-- Name: local_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_items ENABLE ROW LEVEL SECURITY;

--
-- Name: loops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loops ENABLE ROW LEVEL SECURITY;

--
-- Name: mcp_servers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mcp_servers ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_facts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_facts ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_tidy_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_tidy_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: modal_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.modal_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: model_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.model_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: monitors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.monitors ENABLE ROW LEVEL SECURITY;

--
-- Name: oauth_flows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oauth_flows ENABLE ROW LEVEL SECURITY;

--
-- Name: org_ambient_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_ambient_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: participants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.participants ENABLE ROW LEVEL SECURITY;

--
-- Name: principal_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.principal_links ENABLE ROW LEVEL SECURITY;

--
-- Name: process_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.process_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- Name: qm_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qm_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: ack_emoji qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.ack_emoji USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: ack_emoji_picks qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.ack_emoji_picks USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: acl_grants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.acl_grants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: acl_grants_version qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.acl_grants_version USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: admin_grants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.admin_grants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: ambient_cursors qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.ambient_cursors USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: ambient_judgments qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.ambient_judgments USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: approval_grant_modes qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.approval_grant_modes USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: approval_grants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.approval_grants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: approvals qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.approvals USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: audit_log qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.audit_log USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: auth_broker_sessions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.auth_broker_sessions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: auto_flagger_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.auto_flagger_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: aws_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.aws_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: base_model_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.base_model_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: blobs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.blobs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: branding_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.branding_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: browse_max_steps_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.browse_max_steps_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: browse_model_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.browse_model_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: browser_sessions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.browser_sessions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_files qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_files USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_header_pin_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_header_pin_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_messages qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_messages USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_policy qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_policy USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_policy_history qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_policy_history USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_state qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_state USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: command_policies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.command_policies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: composio_returns qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.composio_returns USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: connector_clients qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.connector_clients USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: connector_status qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.connector_status USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: consent_links qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.consent_links USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: context_requests qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.context_requests USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: credential_daily_calls qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.credential_daily_calls USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: credential_usage qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.credential_usage USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: cron_fires qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.cron_fires USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: cron_items qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.cron_items USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: crons qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.crons USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: custom_model_providers qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.custom_model_providers USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deactivated_principals qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deactivated_principals USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: decision_providers qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.decision_providers USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: decision_rules qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.decision_rules USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deploy_git_repos qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deploy_git_repos USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deployment_access qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deployment_access USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deployment_identity qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deployment_identity USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deployment_layer qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deployment_layer USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deployments qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deployments USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_channel_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_channel_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_channels qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_channels USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_group_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_group_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_groups qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_groups USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_meta qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_meta USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_sync qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_sync USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: durable_map_versions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.durable_map_versions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: e2b_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.e2b_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: egress_events qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.egress_events USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: egress_policies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.egress_policies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: environment_attachments qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.environment_attachments USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: environments qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.environments USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: error_events qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.error_events USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: external_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.external_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: external_slack_participants_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.external_slack_participants_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: feature_flags qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.feature_flags USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: file_artifact_deletions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.file_artifact_deletions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: file_artifacts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.file_artifacts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: idempotency qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.idempotency USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: individual_model_auth_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.individual_model_auth_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: interactive_fast_mode_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.interactive_fast_mode_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: items qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.items USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: keychain_asks qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.keychain_asks USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: keychain_credentials qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.keychain_credentials USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: keychain_grants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.keychain_grants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: llm_prompt_envelopes qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.llm_prompt_envelopes USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: local_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.local_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: loop_items qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.loop_items USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: loops qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.loops USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: mcp_servers qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.mcp_servers USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: memory_facts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.memory_facts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: memory_tidy_profiles qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.memory_tidy_profiles USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: modal_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.modal_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: model_credentials qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.model_credentials USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: monitors qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.monitors USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: oauth_flows qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.oauth_flows USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: org_ambient_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.org_ambient_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: participants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.participants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: principal_links qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.principal_links USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: process_sessions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.process_sessions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: projects qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.projects USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: qm_settings qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.qm_settings USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: queued_posts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.queued_posts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: rate_limit_windows qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.rate_limit_windows USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: recent_dm_posts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.recent_dm_posts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: run_activity qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.run_activity USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: run_signals qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.run_signals USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: runs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.runs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sandbox_defaults qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sandbox_defaults USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sandbox_resource_rollout qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sandbox_resource_rollout USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sandbox_resources qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sandbox_resources USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sandbox_routing qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sandbox_routing USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: secret_drops qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.secret_drops USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: security_postures qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.security_postures USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_goals qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_goals USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_leases qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_leases USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_llm_requests qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_llm_requests USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_mailbox qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_mailbox USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_pins qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_pins USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_shares qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_shares USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_spend_days qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_spend_days USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_spend_dirty qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_spend_dirty USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_turn_pointers qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_turn_pointers USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sessions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sessions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sharing_postures qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sharing_postures USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: skill_bundles qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.skill_bundles USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: skill_packs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.skill_packs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: skills qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.skills USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_accounts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_accounts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_emoji_catalog qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_emoji_catalog USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_installation qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_installation USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_session_status qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_session_status USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_staged_envelopes qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_staged_envelopes USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_task_acknowledgements qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_task_acknowledgements USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: soul_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.soul_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: soul_history qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.soul_history USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: source_auth_replay qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.source_auth_replay USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: suggested_activity_profiles qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.suggested_activity_profiles USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: superserve_config_epochs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.superserve_config_epochs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: superserve_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.superserve_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: team_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.team_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: team_rooms qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.team_rooms USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: teams qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.teams USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: tool_calls qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.tool_calls USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: unfulfilled_insights_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.unfulfilled_insights_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: web_ui_state qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.web_ui_state USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: webhook_history qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.webhook_history USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: webhooks qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.webhooks USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: webui_model_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.webui_model_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: queued_posts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.queued_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: rate_limit_windows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rate_limit_windows ENABLE ROW LEVEL SECURITY;

--
-- Name: recent_dm_posts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recent_dm_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: run_activity; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.run_activity ENABLE ROW LEVEL SECURITY;

--
-- Name: run_signals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.run_signals ENABLE ROW LEVEL SECURITY;

--
-- Name: runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runs ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_defaults; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_defaults ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_resource_rollout; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_resource_rollout ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_resources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_resources ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_routing; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_routing ENABLE ROW LEVEL SECURITY;

--
-- Name: secret_drops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.secret_drops ENABLE ROW LEVEL SECURITY;

--
-- Name: security_postures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_postures ENABLE ROW LEVEL SECURITY;

--
-- Name: session_goals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_goals ENABLE ROW LEVEL SECURITY;

--
-- Name: session_leases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_leases ENABLE ROW LEVEL SECURITY;

--
-- Name: session_llm_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_llm_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: session_mailbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_mailbox ENABLE ROW LEVEL SECURITY;

--
-- Name: session_pins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_pins ENABLE ROW LEVEL SECURITY;

--
-- Name: session_shares; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_shares ENABLE ROW LEVEL SECURITY;

--
-- Name: session_spend_days; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_spend_days ENABLE ROW LEVEL SECURITY;

--
-- Name: session_spend_dirty; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_spend_dirty ENABLE ROW LEVEL SECURITY;

--
-- Name: session_turn_pointers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_turn_pointers ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sharing_postures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sharing_postures ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_bundles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_bundles ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_packs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_packs ENABLE ROW LEVEL SECURITY;

--
-- Name: skills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_emoji_catalog; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_emoji_catalog ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_installation; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_installation ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_session_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_session_status ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_staged_envelopes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_staged_envelopes ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_task_acknowledgements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_task_acknowledgements ENABLE ROW LEVEL SECURITY;

--
-- Name: soul_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.soul_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: soul_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.soul_history ENABLE ROW LEVEL SECURITY;

--
-- Name: source_auth_replay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.source_auth_replay ENABLE ROW LEVEL SECURITY;

--
-- Name: suggested_activity_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suggested_activity_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: superserve_config_epochs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.superserve_config_epochs ENABLE ROW LEVEL SECURITY;

--
-- Name: superserve_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.superserve_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: team_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

--
-- Name: team_rooms; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.team_rooms ENABLE ROW LEVEL SECURITY;

--
-- Name: teams; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

--
-- Name: tool_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tool_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: unfulfilled_insights_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.unfulfilled_insights_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: web_ui_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.web_ui_state ENABLE ROW LEVEL SECURITY;

--
-- Name: webhook_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhook_history ENABLE ROW LEVEL SECURITY;

--
-- Name: webhooks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: webui_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webui_model_configs ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-1.pgdg26.04+2)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-1.pgdg26.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: queues; Type: TABLE DATA; Schema: absurd; Owner: -
--

INSERT INTO absurd.queues VALUES ('turns_people', '2026-10-26 15:39:13.281062+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_delegated', '2026-10-26 15:39:13.357036+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_background', '2026-10-26 15:39:13.442448+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_people_t111111110000', '2026-10-26 15:39:24.326528+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_delegated_t111111110000', '2026-10-26 15:39:24.415583+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_background_t111111110000', '2026-10-26 15:39:24.502395+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');


--
-- Data for Name: acl_grants_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.acl_grants_version VALUES (true, 2, 'b7ab8aa5-c18b-405a-af1c-c2515e2593e9');


--
-- Data for Name: qm_schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_schema_migrations VALUES ('absurd/0.5.1', '4f8dd2e6249339a7c89d650d4d71b5a04228cf329a45f515a834acdeca3864e9', '2026-10-26 15:39:13.254118+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0001', '11758af3276004ec5ba9f283d35867d074999b2413b1ab6d74a4545e8fba16fa', '2026-10-26 15:39:13.516158+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0002', '86f3cbd7981ea8e137a31f6e66936ce53654c013c6f20dbb9924692a2263ed0d', '2026-10-26 15:39:13.526648+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0003-file-ids', '2ad7a5a68acb5da6ed801d2b4c1d56391e14bf1eef0356948f661c5a293825de', '2026-10-26 15:39:13.535254+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0001', '542f2a64d2814b329f2c1ad2eb8ed2728e8044b78efa6343eafb5598bc83cb1d', '2026-10-26 15:39:13.540278+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0002', 'bce8b31764744856dab57f8ced3a2e33b36e5896ff0f915152dc466741be3828', '2026-10-26 15:39:13.565458+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/grants/0001', '1a92727b41adaa11bf3029a419a8a5ca9213b0fbab91df905b7e58803cc73ce4', '2026-10-26 15:39:13.57144+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0001', '42188c2f50734398496ddd5a47a9ec3c15a507059c713a4a6ced0b0b81d908eb', '2026-10-26 15:39:13.581393+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0002', 'eb3194ec38847b601025c41b99616c4385770930074e808b21e53af9463d7ad0', '2026-10-26 15:39:13.610232+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0003', '74b2011593ba178ca8decc6f7c82528f7bd161c4651fc2700a78839dac32fc04', '2026-10-26 15:39:13.611927+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/egress_events/0001', 'cfbf4ab51c2b0a4ac45eaeeb7a7011d7b2a4a4d9c21072473ed27400b03fe054', '2026-10-26 15:39:13.621712+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/error_events/0001', 'd5bab01c9f83042aace325e98636b614bcb8a6d77fedaed373f02efde282f5b8', '2026-10-26 15:39:13.639243+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/broker-sessions/0001', '2f958c4c732f8a8a79cb1d31215236fea9565ee2ce5e62270952b889ec5c1265', '2026-10-26 15:39:13.660169+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/replay-dedupe/0001', '8714fae4d626c773edfacf59d807e324955a205abb2be2bc76753cdbbc14adf7', '2026-10-26 15:39:13.67754+00');
INSERT INTO public.qm_schema_migrations VALUES ('cron/fires/0001', '462f9f784160d6e31019707b7df3c35ef0a2979fd3c9fb9d4d581fb89de6cad1', '2026-10-26 15:39:13.692597+00');
INSERT INTO public.qm_schema_migrations VALUES ('decisions/0001', '5259b744d814f2aae9b056e69f4488b87276b8db7eeb17d140d6e89bab93218a', '2026-10-26 15:39:13.711146+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0007-drop', '9f662d39f4ae88a5050475b17bc79410a3faa6f9f91ce83c26b177c91c3acaaa', '2026-10-26 15:39:13.733447+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/access/0001', 'fa35b86cbdfa9e8766ac5e47ffc926986b87ec5bad3ef1d7070fb8e2a1f3f9c2', '2026-10-26 15:39:13.735422+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0001', 'c47a45848f9d225ff601c9df13dc272349c7df7525e7e2417f33d68be7672cc1', '2026-10-26 15:39:13.754107+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0002', '4da6cc4f2496dd53d6381faea3f9f8e16e55394cfe46de516a692ede8157e8b0', '2026-10-26 15:39:13.838007+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0003', '1aaf42502793ebc31b253b12903cf192d2d8d6bcc9e4c1d31e834ed385f2a030', '2026-10-26 15:39:13.840725+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0004', '5376eae39ee0e8d99157e30b6edfbe8b35a0a0998bc4766a86529a45c0e83c4d', '2026-10-26 15:39:13.856682+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0005', '38afbb8d963f48be05d5837f7f06e9f531229316c973c5f87eaa790e2611a8d9', '2026-10-26 15:39:13.859303+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ack_emoji/0001', 'b5cc8b58d6905bf400f15326b4fa4fd3517171dc7e3a2108d23ccc936612ab57', '2026-10-26 15:39:13.861616+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ambient_cursors/0001', 'af7f98b52db7c0fe09648b4ca964f6ccaeb1bbe283cc4d39184f8084db465551', '2026-10-26 15:39:13.880795+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grant_modes/0001', '71fcc4c066ec51b5ea8529444cadf6b02193c31760bde9adbf1d198d31c5829a', '2026-10-26 15:39:13.891615+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/0001', '584a7fe0f0a43a421793efed03be20afc249a2ce02dd3ff4924e4cd536ebbc9d', '2026-10-26 15:39:13.901319+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/0001', 'cd76491910753bae97e30680661f57cdde84d6583d724198cba5e0d71032dcb5', '2026-10-26 15:39:13.912253+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/lookup-sessionid-drop', 'f97131836d0b702bc1a1693e03bd5d97558a5aa95c5324ec0ce4a8b357814141', '2026-10-26 15:39:13.922476+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/lookup-sessionid-hash', 'cc98fbd26fca3ecf2c80295e1057e90abbcde3481211ce9082daed8aeedab4f3', '2026-10-26 15:39:13.931+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/select-sessionid', 'e44a660c6180087f9a8b08be2493eedd0595d4029552b08e3c089d2be47796f4', '2026-10-26 15:39:13.943142+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/stats-sessionid', 'c3c521e26580047f3e4b337f1cf2713f30c21e3d3b8c4c44d699b4dd17e7be45', '2026-10-26 15:39:13.944838+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/auto_flagger_configs/0001', '9a05f950a2b795595aae939eb60be8564511ac523a19961af482051a42c16ff5', '2026-10-26 15:39:13.948236+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/aws_sandbox_bodies/0001', '190bacea57ed75da62849825a5e3206905422d5ffc9f2192d9039222306b378d', '2026-10-26 15:39:13.958167+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/base_model_configs/0001', '7ee3b9db6bc36c92985dddf061cba7ef0b5d736fb44452febaef04c50211624e', '2026-10-26 15:39:13.968449+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/branding_configs/0001', '06c1123ae332e721fe619c8614392636ff446d1a47cd42396e8d3d819ade6dac', '2026-10-26 15:39:13.979861+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_max_steps_configs/0001', 'ae78a8a7cd7a78fc6886bbeb9241aadc057b4958713499e0591be82e878f2e41', '2026-10-26 15:39:13.990019+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_model_configs/0001', '1e06c0cfef0dae9b35d698363d2268d44e3715c0d51210b955f1870d67fa0c02', '2026-10-26 15:39:13.99986+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browser_sessions/0001', '49bcab3ee00cac7b5aa4b3eaa303cfffc34521de73d763cbc4dd204a7a0e8b6f', '2026-10-26 15:39:14.010324+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/channel_header_pin_flag/0001', 'e8f344ed5c29eb3d19ec1a095947f1219e19ddbf0c2b70abdb0784d7c7b0465e', '2026-10-26 15:39:14.020795+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/command_policies/0001', '3b924df4ca67254193724e9a509ce0ee76f1d52bb42c2e0f80f0d408e046749d', '2026-10-26 15:39:14.031559+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/composio_returns/0001', 'e2c6917d12757feffde5140a25db74adeef597fecfa970ab81f5775b0d802460', '2026-10-26 15:39:14.043116+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_clients/0001', 'c8e67053c62396d17890f6d5cbccf60c2097b520ceeb1005007ce4c7ffd38ab9', '2026-10-26 15:39:14.053026+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_status/0001', '6c6632c1e1eae187d4ee42d04ff898901d613a0e7dadfd3056ebd040e97c2219', '2026-10-26 15:39:14.064171+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/consent_links/0001', '4023e872f3c4ef2342dd2db8d0a936662868024875a139162d5c1960dfe5a6db', '2026-10-26 15:39:14.07573+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/context_requests/0001', 'c06306bda2afa606283f9a391786e561e5f0854b3efe5c9b761813acd3238b87', '2026-10-26 15:39:14.086101+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/0001', '0b16ff9849b8701115c2ac3e5486753c854623a586d8a60be95aa23c7b61f5dd', '2026-10-26 15:39:14.096171+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/lookup-cronid-drop', '73226a4cc40bd4e240836e74ab06a8deb66e9f11751865419428330d6fd07f65', '2026-10-26 15:39:14.106153+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/lookup-cronid-hash', 'b60775d1cd6885c70bdb43fdf74b70e297deb9e225daa3ac48214f90a4cf003d', '2026-10-26 15:39:14.114778+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/select-cronid', 'ba50d129c2d7ae3cfbea934278f49bec01e60eeecbcc0ba551cf4539e9467949', '2026-10-26 15:39:14.127443+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/stats-cronid', '7885f49cc713c07e2dc56adaa65cdab3efb9a17342839b5a019762bf28ab0183', '2026-10-26 15:39:14.129523+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0001', '0235672021171d1e58bd485fae8b56090ed58be3a12b156dc7491ac3d825dea3', '2026-10-26 15:39:14.13213+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0001-drop-run-as', '95e375cb70abd7dff68cf61a371167695b3e3427c31f38a9722142c244b0f97a', '2026-10-26 15:39:14.142689+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0002-loops-to-crons', '61ac2ad5d1909cfbe1119e0e16519a0f6e551a653d154b132349305ac12cd20a', '2026-10-26 15:39:14.153829+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/custom_model_providers/0001', '151ac01f9e2a37c511b3f56296050b37a7a4c9c13c7ef946259d5805def997d6', '2026-10-26 15:39:14.165913+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deactivated_principals/0001', '74cf2f5e2185abf08a2c93da115858a42c6f10fe94d814815342888e735ee355', '2026-10-26 15:39:14.177671+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deploy_git_repos/0001', '4957c2777766eb31eaa136953ed5046bc298d8341aab69a43545594f0970ea4c', '2026-10-26 15:39:14.188348+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_identity/0001', '11b012ea31d25b354799885bfc8f1f68a8e9ca2108d72ccee7102a36cbaa1c1b', '2026-10-26 15:39:14.199084+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_layer/0001', '1e9f09c7e5ca32924a4074a7cca5fff79865d31794515c02cd287b337b419803', '2026-10-26 15:39:14.210382+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0001', 'f592ba8aeb41d74822e3960e9632d29adfba5bd0e79c7f21fc91e7258ad0e555', '2026-10-26 15:39:14.220229+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/e2b_sandbox_bodies/0001', '86fde308e21c9f2855750b885fc7a2c860eec53662e9713979cb5af7b6a844a0', '2026-10-26 15:39:14.222505+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/egress_policies/0001', 'e26a4391eabca30277592e928b512beacfa4d9388ebb189a6d22b7acc388c775', '2026-10-26 15:39:14.232369+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_members/0001', 'ea7b43915e8761f9148a2cff9f5c401e192a25b4b71b9535c0ee4710f1fdcba6', '2026-10-26 15:39:14.243513+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_slack_participants_flag/0001', '4c7dbf123c9b99cd85215958cfd9581b83e634b2e02b405548c2777001836291', '2026-10-26 15:39:14.253077+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/feature_flags/0001', '10919fe9fb09ca1141ed38917d5d11b6dad1f53f7f35724b03ad33ebb0712319', '2026-10-26 15:39:14.263232+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/idempotency/0001', 'e171e640e06976d6c0f869c90a3775c68a3ef228f78b56da4edbe7a0e29d7f9f', '2026-10-26 15:39:14.274112+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/individual_model_auth_flag/0001', '80e854a8e2377cb348357c97a3485c9739f4abdd65c3bbab523a0d911b7bb19d', '2026-10-26 15:39:14.288418+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/interactive_fast_mode_flag/0001', '3a1e6bcaa71527b414f5bb5f98610230cda67463b86823723b9283cc4b93aaf0', '2026-10-26 15:39:14.298654+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/internal_member_overrides/0002-drop', 'bababa8a7b29a956b7b90a33a4981f655b8e397a4a440b1fda639179cf5222d9', '2026-10-26 15:39:14.310745+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_asks/0001', 'aef8c37ef4fffa25f96ead4d5ae73b5bcb0b60aa7248050f9bd69d6c064a3a55', '2026-10-26 15:39:14.314143+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0001', 'b7dd2271dfd424898bc65f6adb658b8b51b07f0a9e6a9ef47b5e76fe51c0eda7', '2026-10-26 15:39:14.326105+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0002-delete-auto-captured-logins', 'e2c3d2c3fb7d240450004a535a8af950db3b6ff35ca284da0f393ec31c0b4fde', '2026-10-26 15:39:14.337853+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/lookup-ownerid-drop', '460b2be11208138a00b181b518ca38bc58322dcd37f158ff672496b3fc1248c1', '2026-10-26 15:39:14.349977+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/lookup-ownerid-hash', '84860ad9d9f1634d9bf17e0a928a6d11513200dc6fb43c881928bf933d6da455', '2026-10-26 15:39:14.358917+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/select-ownerid', '6ce3ea87541dd9462ef96981c7c3aac35120340f6477a319b46806f717a90039', '2026-10-26 15:39:14.371618+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/stats-ownerid', 'fa449596f80d2fb3d6eff92f3d52a5e82a58db3c5556520b9fc273a5403d7773', '2026-10-26 15:39:14.373841+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/0001', '6331a8b0daa7ae875d6b09457f7ca1f865812e9a036efa23186793632f94d3d4', '2026-10-26 15:39:14.376792+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/lookup-ownerid-drop', 'b0d3eb453249ac97e0271a551c0b69f7ff93591507521ae1ffde71ce0cd3cee8', '2026-10-26 15:39:14.379304+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/lookup-ownerid-hash', 'c7f3b4ab099eadee97ffb0d0e30a949b63bab34a1356773c9efa85ef5f87063e', '2026-10-26 15:39:14.388339+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/select-ownerid', '2f8bc9481bd50e162894c41aaca606fb666eadae3600ef2297512d6c27e9c33a', '2026-10-26 15:39:14.402894+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/stats-ownerid', '504fbbd9176f279f9c9ce9e2e58c475196dbbdc3c6697e81704ae568753ec676', '2026-10-26 15:39:14.40453+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/local_sandbox_bodies/0001', '8ddedfb7055df7571b770f0835d30c47892655123031f453aa765ee995348c18', '2026-10-26 15:39:14.407882+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/mcp_servers/0001', '656e5902aface901aa8ccea2d404b26454bdf5fc59b0523132b9c339e08b7800', '2026-10-26 15:39:14.418615+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/memory_tidy_profiles/0001', '9b4bb200823266468b607b2f81f3a50bd860cf25c41f980ddb0a61d9ea5e643e', '2026-10-26 15:39:14.4291+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/modal_sandbox_bodies/0001', 'e5a58d41d449a16030a2f8bce471141fe85753cf3e17fe112dfdafea1cf7ddb0', '2026-10-26 15:39:14.440667+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_credentials/0001', 'ede2f544fbfa17aadf339b7830db978823fdd8ffd626f900816c22bb26817474', '2026-10-26 15:39:14.452056+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_registry/0002-drop', 'dd86b4efd9ab54d0a1678bde9502e53fe2aab03327d8b6bc00f5d4ce5fd82c8f', '2026-10-26 15:39:14.464265+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/0001', '352b4ae3e97e45c43ffebb22ddafe1fadc56a37ac025a61d660eb0007613b580', '2026-10-26 15:39:14.467132+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/oauth_flows/0001', '043983772bd290d5722456d63082a660c76e26fe9b6fad0e4a46baa138140f4b', '2026-10-26 15:39:14.479045+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/org_ambient_flag/0001', '7934678d620174a9abb1571803f937a6828cfad2bfe3dd3714d73d44a2679bc5', '2026-10-26 15:39:14.489829+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/pinned_skills/0002-drop', '182c675b050a7a76d0d4283945e26a6e0449972b27fe104c9aeab0fd0452666a', '2026-10-26 15:39:14.500651+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/principal_links/0001', '3b3529b8c4a3803a044be89c7881e1aa1e9e1b430f1e5e5d15f49d80e002c38a', '2026-10-26 15:39:14.502887+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/projects/0001', 'c3542e30f1dc3a4200d39f2043e94c5e9e9d641902bcdc83cdde198ce79f36f3', '2026-10-26 15:39:14.513498+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/queued_posts/0001', 'b17cc1893878b663b2107f1f050dbfb395ae51fa4347c89e6a174e61b5e1515c', '2026-10-26 15:39:14.524914+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/recent_dm_posts/0001', '26601d1a20ca7ce8e30cf7e0892043a4cbb0d3eda33e84062480953d9a228170', '2026-10-26 15:39:14.536829+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_defaults/0001', '781d981103854e2b2c71435edb92d150e76aa8d93a4d519cd0b44c3fd2cb9921', '2026-10-26 15:39:14.547851+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resources/0001', '162e15a2d6f50446d52b17d3ee77f2461ee0ec1c0207b09498e21d335ebc2bdd', '2026-10-26 15:39:14.557666+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/secret_drops/0001', 'd53b8ea0189d918d65ec2f1f521bd1ea1ce7fdf533f516e365cc91732e016b96', '2026-10-26 15:39:14.568161+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/security_postures/0001', '811ad86fa544d98be740f332eb0315a9935d16b5a48ba0cec1516b819998c27d', '2026-10-26 15:39:14.577582+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/0001', 'ef49edb075b1c00c3bcff3526b595f74ca1d16704e497a83fdede49f21f515d6', '2026-10-26 15:39:14.588203+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-recipientid-drop', '0515b8739e932343b78ec1052a9e80c773febf0860ded4409618c7e3e3a4aa4f', '2026-10-26 15:39:14.598473+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-recipientid-hash', 'd4acbff880f7e84d2a1f1eac9ddb44aaa1781e104830c8e2d297ad5c2b324f77', '2026-10-26 15:39:14.607287+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/select-recipientid', '0f783946ba4ea3d80a9542d6a9bc3996678cd465abf0dfa4769c6788e3efe260', '2026-10-26 15:39:14.619306+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/stats-recipientid', '6899798a87557911875dfed8682094a5f6ebc0b3f535b9794f28b4705aff0807', '2026-10-26 15:39:14.620787+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_shares/0001', '77d2a755c000aad13df96fdf9433b717b79c5ad8a5e11ac671ea33379aa55f1e', '2026-10-26 15:39:14.623359+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sharing_postures/0001', '16f5bcc02513285518e6913f70c043dda0d44fa4d0bdbe14ec578b5f06f1d178', '2026-10-26 15:39:14.633215+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_bundles/0001', 'e3e3974648f7657b6dca0c331b64d90f36529e9c3ffec1ae05282a370c0ba1ec', '2026-10-26 15:39:14.644324+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_packs/0001', 'ec3020db9e97c12b42fd33acc59bac01b741616fb2ac31327f6180068d35f708', '2026-10-26 15:39:14.654536+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/0001', 'efe2a0c8ad67467be845d93206eddea17c15784175006b9a1cc82615ad0a33ea', '2026-10-26 15:39:14.666049+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_accounts/0001', '48ff469a6b3ccaa72d47ce443808b2be4ef38640dec7ba8733419789d5c6e8b9', '2026-10-26 15:39:14.677404+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_emoji_catalog/0001', '72e45c26308d61173a6de2ae9e78bbae52dc943e6f12981fa51455d273253a1a', '2026-10-26 15:39:14.687748+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_installation/0001', '31b96f65fded9ee0898ccf44766f6e542d30b0deb3b8da0d06381839be94764c', '2026-10-26 15:39:14.698063+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_session_status/0001', '211ec9c63a6104511f45ee1f2315e49f5b749e9fb2a8780dfdf5b6174ef0bc51', '2026-10-26 15:39:14.708393+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_staged_envelopes/0001', 'c3a5173bc2f0bf0e739fee4a59214c5e2d6236374f44a925016e74ac48188375', '2026-10-26 15:39:14.718428+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_task_acknowledgements/0001', 'bf9fad755c2e7c4dcbb795ad589832b78136e41cac793b0decf98cf180acdcc4', '2026-10-26 15:39:14.728663+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_configs/0001', '8528037c99399b8fdcba2e29dc7dccbc0bb359d6cd5e9ca8f4e0d34a6fc7a4e3', '2026-10-26 15:39:14.739645+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_history/0001', '2a9607ecb96935a95b97fdefc042c7517a58802c4cf9fcee67d7e8da3a4603e2', '2026-10-26 15:39:14.750946+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0001', 'f0850d1e9f12f26babce849b90b52eab95b81530aabf802e87f160a395985ba3', '2026-10-26 15:39:14.762573+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0001-nightly-on-use', '319965364d5048237981818039583f6e2d97e2f69553906fb8311b569867d720', '2026-10-26 15:39:14.772797+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_config_epochs/0001', '03a29556205a6f0e0a80fb7e1b828de610ad20169b342cb80623685a31496477', '2026-10-26 15:39:14.776026+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_sandbox_bodies/0001', '49673eb711120ab7e1fb3d0b5d5dd2d9ffccaa59c331e88112d5c82d907c6220', '2026-10-26 15:39:14.787255+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/0002-drop', '6fd03996fb6c9b0b5ea06db198f83a16cf39dafbf7bc9fddb8965e54b3030635', '2026-10-26 15:39:14.798284+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/triggers/0001-drop-recipient-consent', '690a465b166e66765bd18fc38375020f8b9adbc3d503e384e307d2e02c00c320', '2026-10-26 15:39:14.801472+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/turn_wall_clock_configs/0002-drop', '4b4ebf24b233ddccbb94d3b562b09e87adfe3e64eb1a4f2792ab192036f6b781', '2026-10-26 15:39:14.813501+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/unfulfilled_insights_flag/0001', '6039de5aad6758a517701cab7a47ee158162e21bf79f965f71d780bf9fc41d22', '2026-10-26 15:39:14.816435+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/web_ui_state/0001', 'c432e9df04d30e5533c79ae12ec1564541072ce1138af9ea320f08c533a7cac0', '2026-10-26 15:39:14.828034+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhook_history/0001', '5d99f7bc000a792e237082339eccb490bf124c0dfe7fb14f816b8978e73ec7b4', '2026-10-26 15:39:14.838204+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0001', '95a66510c7e6983e713290d0066264128baa406a19f390af6ba18873e2360c28', '2026-10-26 15:39:14.8484+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0002-disable-rows-orphaned-by-webhook-removal', '5049d35f8e432183fed151377a615e25ec6a97677b7a7ec7da57b155c7425db7', '2026-10-26 15:39:14.850647+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webui_model_configs/0001', '37bb44ffc7579effc5c0ea6c47fc8e7a231207c2e123711daaac34b79f379983', '2026-10-26 15:39:14.853239+00');
INSERT INTO public.qm_schema_migrations VALUES ('environments/store/0001', 'f6eb00919601e6c50bca7857a93061761d2bd1a31396ed7cf9373f93c8ffcae7', '2026-10-26 15:39:14.86369+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0001', '568d83afca3a8ce6287cbe85ad570612d9bb01ad0a8b7d78aa54e6fdc1dc1b0e', '2026-10-26 15:39:14.888243+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0002', 'fc47df852bd24c895b47e97d407eec54a71db90f407c5731627d82b2c63b5819', '2026-10-26 15:39:14.909093+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0000-records-column', '450e71b07659508640f782635a5019fa31b906cc63fdc97e7236d28b0d4c3aea', '2026-10-26 15:39:14.919855+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0001', 'cc560bef4c54ea2007b66eb46bf7258b70c9de98da901348f271c5da38c06597', '2026-10-26 15:39:14.922256+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0001', '5ca2d3af76a021c55ec15829f5798347851f3d73df53f36041dc04fbb2253324', '2026-10-26 15:39:14.937053+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0002', '3677d509807832aecda3cf903f22c42bc3d31a6d9c97b4156f981d376f589999', '2026-10-26 15:39:14.952487+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0003', 'd24a770a83eddffda0658e3e650a3c420ffddb6f68c379d5933f720b2e98cb19', '2026-10-26 15:39:14.954601+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0004', '9c17b6f267eb528657ab97b7bf27735d1c8aa5b8eaefdfe9489346839ea89052', '2026-10-26 15:39:14.956563+00');
INSERT INTO public.qm_schema_migrations VALUES ('ratelimit/limiter/0001', '27463ccd35e5a63321d9a3abb88d5691a23919ad6a9cee945645ce4e487d9437', '2026-10-26 15:39:14.958642+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/crons/0001', '1e33169a8550366f1651f4a9be634b8c04293f3cc197cbf7f741c45af798b632', '2026-10-26 15:39:14.968395+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/deploys/0001', '97db7e33f1bd293034b3e1eb24909bb28ac2c31db3c128dc8d378bd18b91929e', '2026-10-26 15:39:14.971657+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/skills/0001', '77217c6a8da2b9714ede4668b3b52497b83399c65bea3b9c9a311e9565d4d5ef', '2026-10-26 15:39:14.974721+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/webhooks/0001', 'afdb2392eed83a8db7402eececbbdaebbc1563444c21616db1998fd330e40881', '2026-10-26 15:39:14.981449+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/activity/0001', '985e4430016c037b986909566aceb68f53870fc50a71158dbaf73c1c5a15c509', '2026-10-26 15:39:14.984262+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0001', 'f94f67b5c878383af0026a0a44b1f252f83585dec0e12b79b9db6e8de841cacf', '2026-10-26 15:39:15.00142+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0002', '5eaf490533f72a518bd27d4846b052532a7715976e2e5b3b3432b16d1416bb59', '2026-10-26 15:39:15.900843+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0001', '07a121d0fa4e8ae4049e0574939dbf938c8615dc39ce29b74805a7e8ccb4ad0f', '2026-10-26 15:39:15.930375+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0002', 'c0fc23238fbe0ace56a28278bcb6cadfb100eb2c24ee83ce873588d466930270', '2026-10-26 15:39:16.054526+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0003', '8594c46c02ee90d43292a4c083fedea6c72d93b5f414f75e9e20d2db51b1b595', '2026-10-26 15:39:16.110954+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0004', '287116e5f86a67157788d505fecb2ea319974509b5ce35df6febfc8b9f059d6b', '2026-10-26 15:39:16.114084+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0004-subagent-returns', '390cf57f79622a535c61b02f59c3727d49d7bc51ac7710da184a24352415ad52', '2026-10-26 15:39:16.116611+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0005-session-history', '98df79620c5dfbedcc8b3b1ea38ada86d7948a0fd2fb6f9f8646c2c826b30612', '2026-10-26 15:39:16.144054+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0006-terminal-finished', 'c1b9fac31ffd7f3e0e19ae28007a3a0870f64ba04c1c6b608153dcc262970920', '2026-10-26 15:39:16.155832+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0007-last-stop', '3112c3322da219fd1be29ff632b726a529864794f3659846e320cf6ba54cbe56', '2026-10-26 15:39:16.157887+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0008-claim-priority', 'd67a00e019c5343ea8a03ec0b1e851f714de191cd8f1ba404263665105ba61ad', '2026-10-26 15:39:16.160132+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0009-claim-priority-index', '9922f90b6cea5da7af6ad0cbff5b718cd741c68260a2420abdb2889f441ef8ef', '2026-10-26 15:39:16.181686+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0010-drop-turn-metrics', 'cc3fdea1e8cfc3979dab84d9474d09741aee1d882875519eef9f0ebeeacc94b0', '2026-10-26 15:39:16.183664+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0011-turn-engine', '19f17b8388ec6184be64548b0f944a4f5e8abed18fb8097e2398b7d38cdfe3e5', '2026-10-26 15:39:16.186588+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0012-turn-engine-indexes', 'f7143920515057b8ad8b5736bdb3b207d92f5de191cbf3bbe2b5f2fca5ea7103', '2026-10-26 15:39:16.223496+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0013-turn-fairness', 'cae259a475a766c868f021f7017b92e2e09f2664f7a24568028f32830851f9ce', '2026-10-26 15:39:16.225299+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0014-turn-fairness-index', '1d9fb42b948d43e00eb1499cf533cc55a249ae9b78a6ae0f2c51d21249e1f070', '2026-10-26 15:39:16.26051+00');
INSERT INTO public.qm_schema_migrations VALUES ('runtime/0002-drop-harness-choice', '2e7a8523090c84d00b557197f2e3038b5b2fd418e6b3b4b08c10ef0cf596a792', '2026-10-26 15:39:16.262698+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0001', 'cf56c9f6488806677a229698193ef6dd7cb74300c343bdb1930c17702c5ccf2f', '2026-10-26 15:39:16.266733+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0002', 'ca9877865861adf81cfb433750327462aedcfa1e60d4e87a7845d1a77f64c2ec', '2026-10-26 15:39:16.362472+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0003', 'fd77efdccf169dee81da809a54313be30a0aaf92cdea4f6c33e34555bb2396c8', '2026-10-26 15:39:16.464805+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0004', '856cc6940c934b59e37d511271630f77d72b235c92ab0e2e2085207d15750a75', '2026-10-26 15:39:16.46824+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0005', '4b0824aa4311df8c66b57b16f331e9dcf3dfc8d11c112a000d83f46b1fba1bd0', '2026-10-26 15:39:16.48214+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0006', '57037691db0c87e9eeb28927758ae35e426eb8a8b7f7b5b8440bb08817f39203', '2026-10-26 15:39:16.488182+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0007', '8322f0c560da60399baf59f0364e8125e836384cd8b4d9795bd1c114d4d7d514', '2026-10-26 15:39:16.511748+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0008', '4b32bec77fa021de97736856a70a45bf1e51e59e574987e0d044fe748ec4cf58', '2026-10-26 15:39:16.514339+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0009', '40558264e0589a236a8a5a688a42eb49acf8a774371b9e1c6a3e5e0a84065c7d', '2026-10-26 15:39:16.516607+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0010', '29832445f9d3bfaf0d97f11b2748a1ca533ff57c6f4bd96c594e83a6ab4f7c9a', '2026-10-26 15:39:16.532414+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0011', 'be590472124ab471453cfbbd7d3c1a0c57f792c97704707fba3682f4183f870d', '2026-10-26 15:39:16.535392+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0012', '6f52591c733daffdda7aca112ad5a21cfec5c0c36f97838d74b107a79b7100bf', '2026-10-26 15:39:16.538135+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0013', '86c8d0eff24f8f2deab4f33eccff6d0206b3a9a64943a812eec0965203dd5262', '2026-10-26 15:39:16.545102+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0014-search-write-through-v1', 'e91226e6e5897b86e296c43e75a3f8d00633a1a7752a46c4c9f7cabf44f3b747', '2026-10-26 15:39:16.563805+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0015-search-backfill-v1', '3f942dd9aefb26588756cd936f73e08704df8071454b1f3d6fba7fe41f373864', '2026-10-26 15:39:16.566928+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0016-status', '89fbf5684830326730fdbde5f2de9cea69dcc1661a5f9e17e897232d5d74c9b4', '2026-10-26 15:39:16.570035+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0016-tape-source-role', '2725fb5df8e2a82fe5936486e45e7f999bd0606cf3355d6bfbb01296d17374f7', '2026-10-26 15:39:16.572146+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0017-subagent-parentage', '46f54668e4e535b7e891170e85453eaa4ccb4f923f2fc666d0376967efa5295a', '2026-10-26 15:39:16.574441+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0017-transcript-entries', '828dfba948c6272dd747748c04ad777a0f84f5fde23d0b803fa5bf28872a6ef7', '2026-10-26 15:39:16.580686+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0018-llm-requests-created-at', '0f550cd1401ea9f6dc7d62c7d154e4a8a4624e8fb27d10e75ed2bc000a54f5e7', '2026-10-26 15:39:16.58834+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0019-participant-activity-indexes', '4bd9bfdadffe0d2c4de382feacce65c06987f061df940eecc7991699b1249348', '2026-10-26 15:39:16.614315+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json', 'febf07cde8b9ffe09a497d44a0e524a5c994f7708a0fab6d245315e4ab1e717a', '2026-10-26 15:39:16.615873+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json-size', '4f34eed7d24be1ea5e81263d9eb4dafa4a5c54da709332feb38b2f6fab6f7025', '2026-10-26 15:39:16.618136+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json-size-plpgsql', '1d69838eefe8377d3f8010707c0ce816bafd340b3d9da3c0cc15bb4fad038e16', '2026-10-26 15:39:16.619961+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0021-spend-covering-index', 'e11f84353f7637fff2ccb5bf9aa54de9a9fe1494cd8181adf52676edf0bf8f5a', '2026-10-26 15:39:16.644059+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0022-spend-days', '66bddbc128d3257accf4501d5f2890a9cddf8b9ae5287b38dacabdaa4005bdad', '2026-10-26 15:39:16.645945+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0023-spend-days-backfill', '8c5baecc5ec81cf33f24c53c58bb6d93f7589458a4bd442ab67a19fa783398ca', '2026-10-26 15:39:16.666152+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0024-user-previews', 'ca1d0192587bdc5d07690988e7767c2d79d0f3ee8a1627fffcac24499d74df47', '2026-10-26 15:39:16.668894+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0025-org-activity-index', '00366567fac31a93877a9373dd7613084091565a4933372068d9d5fce9d9f4a1', '2026-10-26 15:39:16.6823+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0026-participant-read-at', 'a3949603eac7d7fb64dba0852a23b4ee7468717875774144e5d74d852e49418e', '2026-10-26 15:39:16.684148+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0027-agent-reply-index', '65af103073ef18b66547651fc007e4f1b704a98126e6974eea121ca877f1e090', '2026-10-26 15:39:16.69639+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0028-drop-run-tasks', '5aa0a3c8a071fffcddb859cdab12735dd331c97d3258da4807152b64e503ae22', '2026-10-26 15:39:16.69822+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0029-legacy-tape-steps', 'a103ebb697c0d2cdf4a843791127955ff6c42729ca1ba5880446e02aa24e7235', '2026-10-26 15:39:16.700201+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0030-legacy-tape-steps-size-guard', '3b7f668e1acedcda4613ba41110f62932b404ba93884c829aa209d744a7a12c8', '2026-10-26 15:39:16.731241+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0031-drop-session-tape', '3100b33fe1e55d5abe05f50b655f3ff73142e3608af3616ba4954209b5f42e5b', '2026-10-26 15:39:16.745577+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0032-session-goals', '67b3486e1426f893bfbf64fb5412083ca30a2287038afc358793c5222171dd2c', '2026-10-26 15:39:16.767005+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0033-client-tools', '3d46f3d967516132f7f67d0ce5ee46127a9a46761ad9d143aba12db374b293aa', '2026-10-26 15:39:16.814866+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0034-session-origin-backfill', '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', '2026-10-26 15:39:16.817964+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0035-items', 'b3f15f62b55af30d7f6b79f037a09d157ea1e1ad9aad5702742dff01263c016d', '2026-10-26 15:39:16.819854+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0035-items-keep-call-ids', 'cfddc304ecc65adc4dd9eca2fe6ddac6a53eb05bfd8ac9d282e420750d3c8f94', '2026-10-26 15:39:16.882218+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0036-items-cutover', '43c41a637d03afe4ce8d1314298783a8190c56da4e0d25aa3bf810c13fb6f439', '2026-10-26 15:39:16.885546+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0037-drop-legacy-history', '9454a05ac35a704ccd7027e7f7f07d4c97acc589009d107ca538028e57d1a7d8', '2026-10-26 15:39:16.892164+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0038-scoped-origin-pages', '7b4a021bdfa47d06b19676f0ab93ba251eff93f69547d1a777e5ff35ba0d6eeb', '2026-10-26 15:39:16.922336+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0039-items-call-id-digest-index', 'cffad89ce3e55cfb9db84abace87cc310ef3f5385520019b6523cb680de3ba4a', '2026-10-26 15:39:16.934071+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0040-items-call-id-digest-swap', '558e686736d1eba1d5fac1866fabe2433b5e0cf420123873e237ea7327409c38', '2026-10-26 15:39:16.935727+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0041-drop-inline-llm-request', '398ae13963cbb65985f948db602bcf952d396598f7edd10244960a6d398c2894', '2026-10-26 15:39:16.939275+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0042-llm-prompt-envelopes-created-at', '4dcffa4ab23b943c3fc761c0edb9f2e01cbbb8473d73823721695da765eec3ed', '2026-10-26 15:39:16.951961+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0043-last-user-activity', '6ac9dd6674c99c00f47b823cadddbbba866db625bb72713fb1b3b32e13a982a1', '2026-10-26 15:39:16.953861+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0044-last-user-activity-backfill', '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', '2026-10-26 15:39:16.956872+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ack-emoji-pick/0001', 'f810bb939d938048d4852a518c04ee315dc42e415e237a31b35129fe08678228', '2026-10-26 15:39:16.959064+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ambient-judgment/0001', '70c0f2d71fdc4d464b4a9d35fcb078b5efdf4dc4fcf769f8379eaa1afb4ad61e', '2026-10-26 15:39:16.981015+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/channel-policy/0001', '5be6f79d080af7a40c4c28708c906359fab2e5cdb23ffd24823da12186fa19ef', '2026-10-26 15:39:17.003207+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0001', 'd823cafcb1d6fbe0400d4ec7cbf745d768af8d02b492681092b95136b706518d', '2026-10-26 15:39:17.024777+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0002', 'a940914e3f7a04f8508e88b31035c3b4d74438087f716b6d1832f90ed78c9357', '2026-10-26 15:39:17.089659+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0003', 'b3f05a3e976216b758fd8482c603917505c231787c853b46e8c76a7d80377f08', '2026-10-26 15:39:17.09266+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0004', 'e64e42c1db30b3f2fe0cf8de0a274316bba539131c677b8242cb11ab55304eee', '2026-10-26 15:39:17.107088+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0005', '0730c53e72559cdd0eba1830f2e243dd539dabfeceb2702161fc0511dabba8e0', '2026-10-26 15:39:17.109568+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0006', '17e5f4f46573989bf031b3c79a41f191bc614c53e265829bb7bd5a17cad19208', '2026-10-26 15:39:17.11181+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0007', 'd56a4323978d8233aab8258422908b794bf960dc2059e252b3850e6da3902a36', '2026-10-26 15:39:17.115096+00');
INSERT INTO public.qm_schema_migrations VALUES ('teams/0001', '2b8c0d4f17fb526e042960f55feab31d269a33b644872e2c87266be47429a174', '2026-10-26 15:39:17.11766+00');
INSERT INTO public.qm_schema_migrations VALUES ('turns/0001-ledger', '232697d51c3a7fad84bba53124f9f16882663afdbfa7200c3490842ed27578d3', '2026-10-26 15:39:17.155779+00');
INSERT INTO public.qm_schema_migrations VALUES ('turns/0002-tenant-queues', 'eb721fd4eccba37068ede563b419b6a81392575d24a5963307ce1f79df555126', '2026-10-26 15:39:17.172468+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resource_rollout/0001', 'dcd22153628d543510d7b0354f04f44e5ced4caace605e4d11fc5d2a23e4951a', '2026-10-26 15:39:23.06241+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_routing/0001', '87419da3caad64f369b0b2fab335aba22d336730b4a11abf8bddf24300a49448', '2026-10-26 15:39:23.27709+00');


--
-- Data for Name: qm_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_tenant VALUES ('b7ab8aa5-c18b-405a-af1c-c2515e2593e9');


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000001', 'closedai', 'closedai', '{closedai.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');
INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000002', 'kittenmittens', 'kittenmittens', '{kittenmittens.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');
INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000003', 'openaguy', 'openaguy', '{openaguy.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');
INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000004', 'mt-fake-1', 'mt-fake-1', '{mt-fake-1.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');
INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000005', 'mt-fake-2', 'mt-fake-2', '{mt-fake-2.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');


--
-- PostgreSQL database dump complete
--


