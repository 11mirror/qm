--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-1.pgdg26.04+2)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-1.pgdg26.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: item_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.item_kind AS ENUM (
    'UserMessage',
    'SteeringMessage',
    'AgentMessage',
    'Reasoning',
    'ToolCall',
    'ToolResult',
    'Elicitation',
    'ElicitationResponse',
    'Wake',
    'Error',
    'ContextCompaction',
    'Retraction',
    'Stop',
    'RuntimeChange'
);


--
-- Name: wake_cause; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.wake_cause AS ENUM (
    'cron',
    'webhook',
    'child_done',
    'system'
);


--
-- Name: acl_grants_bump_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.acl_grants_bump_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        INSERT INTO acl_grants_version(only_row, v) VALUES (TRUE, 1)
        ON CONFLICT (only_row) DO UPDATE SET v = acl_grants_version.v + 1;
        RETURN NULL;
      END
      $$;


--
-- Name: forbid_direct_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_direct_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     IF pg_trigger_depth() > 1 THEN RETURN OLD; END IF;
     RAISE EXCEPTION 'DELETE on % is only allowed through its session', TG_TABLE_NAME
       USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: forbid_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     RAISE EXCEPTION '% on % is forbidden', TG_OP, TG_TABLE_NAME USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: invalidate_request_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_request_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             INSERT INTO session_spend_dirty(day)
             SELECT DISTINCT floor(at::numeric / 86400000)::bigint
               FROM (VALUES
                 (CASE WHEN TG_OP <> 'INSERT' AND OLD.usage_json IS NOT NULL THEN OLD.created_at END),
                 (CASE WHEN TG_OP <> 'DELETE' AND NEW.usage_json IS NOT NULL THEN NEW.created_at END)
               ) changed(at) WHERE at IS NOT NULL
             ON CONFLICT DO NOTHING;
             RETURN NULL;
           END $$;


--
-- Name: invalidate_session_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_session_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             IF TG_OP = 'UPDATE' AND ROW(OLD.id, OLD.scope_id, OLD.origin, OLD.thread_ref, OLD.parent_session_id)
                  IS NOT DISTINCT FROM ROW(NEW.id, NEW.scope_id, NEW.origin, NEW.thread_ref, NEW.parent_session_id) THEN
               RETURN NULL;
             END IF;
             INSERT INTO session_spend_dirty(session_id)
             SELECT DISTINCT id FROM (VALUES (OLD.id), (NEW.id)) changed(id) WHERE id IS NOT NULL;
             RETURN NULL;
           END $$;


--
-- Name: qm_sync_legacy_cron_fire(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_sync_legacy_cron_fire() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        INSERT INTO cron_fires (cron_id, fire_key, thread_ref, session_id, fired_at, scheduled_at, ended_at, status, note, reply)
        SELECT source.cron_id, source.fire_key, COALESCE(source.json->>'threadRef', 'cron:' || source.cron_id), source.json->>'sessionId', source.fired_at, (source.json->>'scheduledAt')::bigint, COALESCE((source.json->>'endedAt')::bigint, CASE WHEN source.json->>'status' IS DISTINCT FROM 'running' THEN source.fired_at END), source.json->>'status', source.json->>'note', source.json->>'reply' FROM (SELECT NEW.*) source
        ON CONFLICT (cron_id, fire_key) DO UPDATE SET thread_ref = EXCLUDED.thread_ref, session_id = EXCLUDED.session_id, fired_at = EXCLUDED.fired_at, scheduled_at = EXCLUDED.scheduled_at, ended_at = EXCLUDED.ended_at, status = EXCLUDED.status, note = EXCLUDED.note, reply = EXCLUDED.reply
  WHERE EXCLUDED.fired_at >= cron_fires.fired_at
    AND (cron_fires.ended_at IS NULL OR EXCLUDED.ended_at IS NOT NULL)
    AND (cron_fires.thread_ref, cron_fires.session_id, cron_fires.fired_at, cron_fires.scheduled_at, cron_fires.ended_at, cron_fires.status, cron_fires.note, cron_fires.reply) IS DISTINCT FROM (EXCLUDED.thread_ref, EXCLUDED.session_id, EXCLUDED.fired_at, EXCLUDED.scheduled_at, EXCLUDED.ended_at, EXCLUDED.status, EXCLUDED.note, EXCLUDED.reply);
        RETURN NEW;
      END
    $$;


--
-- Name: qm_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$ SELECT id FROM qm_tenant $$;


--
-- Name: safe_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.safe_json(t text) RETURNS json
    LANGUAGE plpgsql IMMUTABLE
    AS $$
        BEGIN RETURN t::json; EXCEPTION WHEN others THEN RETURN NULL; END $$;


--
-- Name: spend_usage_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.spend_usage_json(t text) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE
    AS $$
             DECLARE j jsonb;
             BEGIN
               IF t IS NULL OR octet_length(t) > 2000 OR NOT pg_input_is_valid(t, 'jsonb') THEN
                 RETURN NULL;
               END IF;
               j := t::jsonb;
               IF pg_input_is_valid(j ->> 'costUsd', 'double precision') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'input', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'output', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheRead', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheWrite', 'bigint') IS NOT FALSE THEN
                 RETURN j;
               END IF;
               RETURN NULL;
             END
             $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ack_emoji; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: ack_emoji_picks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji_picks (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    channel text NOT NULL,
    ts text NOT NULL,
    outcome text NOT NULL,
    picked text,
    icon text,
    message text,
    candidates text,
    model text,
    latency_ms integer,
    created_at bigint NOT NULL
);


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ack_emoji_picks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ack_emoji_picks_id_seq OWNED BY public.ack_emoji_picks.id;


--
-- Name: acl_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants (
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    grantee_scope_id text NOT NULL,
    permission text NOT NULL,
    granted_by text NOT NULL
);


--
-- Name: acl_grants_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants_version (
    only_row boolean DEFAULT true NOT NULL,
    v bigint NOT NULL,
    CONSTRAINT acl_grants_version_only_row_check CHECK (only_row)
);


--
-- Name: admin_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_grants (
    principal_id text NOT NULL,
    scope_id text NOT NULL,
    role text NOT NULL,
    granted_by text,
    created_at bigint
);


--
-- Name: ambient_cursors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_cursors (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: ambient_judgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_judgments (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    container text NOT NULL,
    decision text NOT NULL,
    reason text,
    asked_by text,
    prompt text,
    model text,
    latency_ms integer,
    ts_from text,
    ts_to text,
    created_at bigint NOT NULL
);


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ambient_judgments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ambient_judgments_id_seq OWNED BY public.ambient_judgments.id;


--
-- Name: approval_grant_modes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grant_modes (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: approval_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grants (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approvals (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: approved_harness_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approved_harness_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    at bigint NOT NULL,
    principal_id text NOT NULL,
    action text NOT NULL,
    resource text NOT NULL,
    scope_label text NOT NULL,
    status text,
    detail text,
    idempotency_key text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auth_broker_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_broker_sessions (
    token_hash text NOT NULL,
    email text NOT NULL,
    authenticated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    absolute_expires_at timestamp with time zone NOT NULL,
    idle_seconds integer NOT NULL
);


--
-- Name: auto_flagger_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_flagger_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: aws_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aws_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: base_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.base_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blobs (
    tenant_id uuid NOT NULL,
    sha256 bytea NOT NULL,
    size bigint NOT NULL,
    mime text,
    storage_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT blobs_sha256_check CHECK ((length(sha256) = 32)),
    CONSTRAINT blobs_size_check CHECK ((size >= 0)),
    CONSTRAINT blobs_storage_key_check CHECK ((storage_key <> ''::text))
);


--
-- Name: branding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: browse_max_steps_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_max_steps_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: browse_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: browser_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browser_sessions (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: channel_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_files (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    file_id text NOT NULL,
    name text,
    mimetype text,
    created_at bigint NOT NULL,
    title text,
    size bigint
);


--
-- Name: channel_header_pin_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_header_pin_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: channel_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_messages (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    sub text,
    author_id text,
    author_name text,
    text text DEFAULT ''::text NOT NULL,
    mentions jsonb,
    self boolean DEFAULT false NOT NULL,
    bot boolean DEFAULT false NOT NULL,
    mentions_self boolean DEFAULT false NOT NULL,
    edited_at bigint,
    deleted boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    handled boolean DEFAULT false NOT NULL,
    tsv tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(text, ''::text))) STORED,
    deleted_at bigint,
    broadcast boolean DEFAULT false NOT NULL,
    subtype text,
    bot_id text
);


--
-- Name: channel_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy (
    org_id text NOT NULL,
    container text NOT NULL,
    orders text DEFAULT ''::text NOT NULL,
    bots jsonb DEFAULT '{}'::jsonb NOT NULL,
    set_by text,
    updated_at bigint NOT NULL,
    ambient_enabled boolean
);


--
-- Name: channel_policy_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy_history (
    id bigint NOT NULL,
    org_id text NOT NULL,
    container text NOT NULL,
    orders text NOT NULL,
    set_by text,
    session_id text,
    created_at bigint NOT NULL,
    bots jsonb,
    ambient_enabled boolean
);


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.channel_policy_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.channel_policy_history_id_seq OWNED BY public.channel_policy_history.id;


--
-- Name: channel_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_state (
    org_id text NOT NULL,
    container text NOT NULL,
    last_ts text,
    oldest_ts text,
    name text,
    kind text,
    members jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: command_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.command_policies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: composio_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.composio_returns (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: connector_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_clients (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: connector_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_status (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: consent_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consent_links (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: context_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.context_requests (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: credential_daily_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_daily_calls (
    slug text NOT NULL,
    day bigint NOT NULL,
    sent integer NOT NULL
);


--
-- Name: credential_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_usage (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    slug text NOT NULL,
    host text NOT NULL,
    status text NOT NULL,
    upstream_status integer,
    scope_label text NOT NULL,
    principal_id text NOT NULL
);


--
-- Name: credential_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credential_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credential_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credential_usage_id_seq OWNED BY public.credential_usage.id;


--
-- Name: cron_fires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_fires (
    cron_id text NOT NULL,
    fire_key text NOT NULL,
    thread_ref text NOT NULL,
    session_id text,
    fired_at bigint NOT NULL,
    scheduled_at bigint,
    ended_at bigint,
    status text,
    note text,
    reply text
);


--
-- Name: crons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crons (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: custom_model_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_model_providers (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: deactivated_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deactivated_principals (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: decision_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_providers (
    provider_id text NOT NULL,
    protocol text NOT NULL,
    base_url text,
    credential text,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: decision_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_rules (
    rule_id text NOT NULL,
    hook text NOT NULL,
    question text NOT NULL,
    options json NOT NULL,
    provider_id text NOT NULL,
    model text NOT NULL,
    mode text NOT NULL,
    on_error text NOT NULL,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    CONSTRAINT decision_rules_mode_check CHECK ((mode = ANY (ARRAY['off'::text, 'observe'::text, 'enforce'::text])))
);


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deliveries (
    id text NOT NULL,
    idempotency_key text NOT NULL,
    destination jsonb NOT NULL,
    text text NOT NULL,
    created_at bigint NOT NULL,
    delivered_at bigint,
    attachments jsonb,
    provenance jsonb,
    recipient_thread_ref text,
    shadow boolean DEFAULT false NOT NULL,
    deliver_latency_ms integer,
    slack_api_ms integer,
    claim_expires_at bigint,
    expired_at bigint,
    source_cron_id text
);


--
-- Name: deploy_git_repos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_git_repos (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: deployment_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_access (
    id text NOT NULL,
    last_access_at bigint NOT NULL
);


--
-- Name: deployment_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_identity (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: deployment_layer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_layer (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployments (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: directory_channel_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channel_members (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    principal_id text NOT NULL
);


--
-- Name: directory_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channels (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    name_lc text NOT NULL,
    is_private boolean DEFAULT false NOT NULL,
    is_external boolean DEFAULT false NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    observed_at bigint
);


--
-- Name: directory_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_group_members (
    org_id text NOT NULL,
    group_id text NOT NULL,
    principal_id text NOT NULL
);


--
-- Name: directory_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_groups (
    org_id text NOT NULL,
    group_id text NOT NULL,
    roster_known boolean DEFAULT false NOT NULL
);


--
-- Name: directory_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_members (
    org_id text NOT NULL,
    principal_id text NOT NULL,
    display_name text NOT NULL,
    display_name_lc text NOT NULL,
    type text NOT NULL,
    slack_id text,
    avatar_url text
);


--
-- Name: directory_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_meta (
    org_id text NOT NULL,
    workspace_url text,
    updated_at bigint NOT NULL
);


--
-- Name: directory_sync; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_sync (
    org_id text NOT NULL,
    members_hash text,
    channels_hash text,
    groups_hash text,
    channel_members_synced boolean DEFAULT false NOT NULL,
    updated_at bigint NOT NULL,
    members_synced_at bigint,
    channels_synced_at bigint,
    groups_synced_at bigint
);


--
-- Name: do_managed_agents_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.do_managed_agents_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: durable_map_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.durable_map_versions (
    tbl text NOT NULL,
    v bigint NOT NULL
);


--
-- Name: e2b_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.e2b_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: egress_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    source text NOT NULL,
    host text NOT NULL,
    allowed boolean NOT NULL,
    scope_label text NOT NULL,
    port integer,
    verdict text,
    via text,
    peer_ip text,
    principal_id text
);


--
-- Name: egress_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.egress_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: egress_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.egress_events_id_seq OWNED BY public.egress_events.id;


--
-- Name: egress_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_policies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: environment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environment_attachments (
    scope_id text NOT NULL,
    environment_id text NOT NULL,
    attached_by text NOT NULL,
    attached_at bigint NOT NULL
);


--
-- Name: environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environments (
    id text NOT NULL,
    org_id text NOT NULL,
    name text,
    owner_actor_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: error_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    scope_label text NOT NULL,
    category text NOT NULL,
    code text NOT NULL,
    message text NOT NULL,
    session_id text
);


--
-- Name: error_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.error_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.error_events_id_seq OWNED BY public.error_events.id;


--
-- Name: external_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_members (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: external_slack_participants_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_slack_participants_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: file_artifact_deletions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifact_deletions (
    id text NOT NULL,
    deleted_at bigint NOT NULL
);


--
-- Name: file_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifacts (
    id text NOT NULL,
    kind text DEFAULT 'file'::text NOT NULL,
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    name text NOT NULL,
    mimetype text NOT NULL,
    size_bytes bigint NOT NULL,
    blob_key text,
    sha256 text,
    direction text NOT NULL,
    created_by text NOT NULL,
    created_in_scope text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    source text DEFAULT 'live'::text NOT NULL
);


--
-- Name: idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: individual_model_auth_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.individual_model_auth_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: interactive_fast_mode_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interactive_fast_mode_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    tenant_id uuid NOT NULL,
    session_id text NOT NULL,
    seq bigint NOT NULL,
    turn_id uuid,
    kind public.item_kind NOT NULL,
    author text,
    call_id text,
    elicit_id text,
    wake_cause public.wake_cause,
    error_code text,
    text text,
    tool text,
    step integer,
    variant text,
    is_error boolean,
    hidden boolean,
    external_id text,
    through_seq bigint,
    target_seq bigint,
    approved boolean,
    blob_sha bytea,
    search tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, COALESCE(text, ''::text))) STORED,
    body jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT items_approved_kind CHECK (((approved IS NULL) OR (kind = 'ElicitationResponse'::public.item_kind))),
    CONSTRAINT items_author_check CHECK ((author <> ''::text)),
    CONSTRAINT items_author_kind CHECK (((author IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'ElicitationResponse'::public.item_kind, 'Stop'::public.item_kind, 'RuntimeChange'::public.item_kind])))),
    CONSTRAINT items_blob_sha_kind CHECK (((blob_sha IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_body_check CHECK ((jsonb_typeof(body) = 'object'::text)),
    CONSTRAINT items_call_id_check CHECK ((call_id <> ''::text)),
    CONSTRAINT items_call_id_kind CHECK (((call_id IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_elicit_id_check CHECK ((elicit_id <> ''::text)),
    CONSTRAINT items_elicit_id_kind CHECK (((elicit_id IS NOT NULL) = (kind = ANY (ARRAY['Elicitation'::public.item_kind, 'ElicitationResponse'::public.item_kind])))),
    CONSTRAINT items_error_code_check CHECK ((error_code <> ''::text)),
    CONSTRAINT items_error_code_kind CHECK (((error_code IS NOT NULL) = (kind = 'Error'::public.item_kind))),
    CONSTRAINT items_external_id_check CHECK ((external_id <> ''::text)),
    CONSTRAINT items_external_id_kind CHECK (((external_id IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_hidden_kind CHECK (((hidden IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_is_error_kind CHECK (((is_error IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_seq_check CHECK ((seq >= 0)),
    CONSTRAINT items_step_check CHECK ((step >= 0)),
    CONSTRAINT items_step_kind CHECK (((step IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind, 'Reasoning'::public.item_kind, 'AgentMessage'::public.item_kind])))),
    CONSTRAINT items_target_seq_kind CHECK (((target_seq IS NULL) OR (kind = 'Retraction'::public.item_kind))),
    CONSTRAINT items_text_check CHECK ((text <> ''::text)),
    CONSTRAINT items_text_kind CHECK (((text IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'AgentMessage'::public.item_kind, 'Reasoning'::public.item_kind, 'ToolResult'::public.item_kind, 'Error'::public.item_kind, 'ContextCompaction'::public.item_kind])))),
    CONSTRAINT items_through_seq_kind CHECK (((through_seq IS NULL) OR (kind = 'ContextCompaction'::public.item_kind))),
    CONSTRAINT items_tool_check CHECK ((tool <> ''::text)),
    CONSTRAINT items_tool_kind CHECK (((tool IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_variant_check CHECK ((variant = ANY (ARRAY['narration'::text, 'files_delivered'::text]))),
    CONSTRAINT items_variant_kind CHECK (((variant IS NULL) OR (kind = 'AgentMessage'::public.item_kind))),
    CONSTRAINT items_wake_cause_kind CHECK (((wake_cause IS NOT NULL) = (kind = 'Wake'::public.item_kind)))
);


--
-- Name: keychain_asks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_asks (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: keychain_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_credentials (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: keychain_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_grants (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: llm_prompt_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_prompt_envelopes (
    hash text NOT NULL,
    body text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: loop_ingress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ingress (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: loop_ingress_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ingress_deliveries (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: loop_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_items (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: loop_outputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_outputs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: loop_ship_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ship_grants (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: loops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loops (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: memory_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_facts (
    id bigint NOT NULL,
    scope_id text NOT NULL,
    text text NOT NULL,
    sensitivity text NOT NULL,
    sources text[] DEFAULT '{}'::text[] NOT NULL,
    source_unknown boolean NOT NULL,
    author text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    deleted_at bigint
);


--
-- Name: memory_facts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.memory_facts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: memory_facts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.memory_facts_id_seq OWNED BY public.memory_facts.id;


--
-- Name: memory_tidy_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_tidy_profiles (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: modal_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modal_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: model_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_credentials (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: model_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_registry (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: monitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monitors (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: oauth_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_flows (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: org_ambient_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_ambient_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participants (
    session_id text NOT NULL,
    principal_id text NOT NULL,
    valid_from bigint NOT NULL,
    valid_to bigint,
    valid_from_seq integer,
    valid_to_seq integer,
    title text,
    archived boolean DEFAULT false NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    color text,
    read_at bigint
);


--
-- Name: principal_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.principal_links (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: process_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_sessions (
    process_id text NOT NULL,
    scope_id text NOT NULL,
    kind text NOT NULL,
    command text NOT NULL,
    started_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    status text NOT NULL,
    session_ref text,
    run_id text,
    sandbox_id text,
    purpose text,
    credential_files jsonb
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: qm_schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_schema_migrations (
    id text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: qm_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: qm_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_tenant (
    id uuid NOT NULL
);


--
-- Name: rate_limit_windows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit_windows (
    principal_id text NOT NULL,
    window_start bigint NOT NULL,
    count integer NOT NULL
);


--
-- Name: run_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_activity (
    id bigint NOT NULL,
    run_id text NOT NULL,
    seq bigint NOT NULL,
    parent_seq bigint,
    type text NOT NULL,
    payload jsonb NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: run_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_activity_id_seq OWNED BY public.run_activity.id;


--
-- Name: run_signals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_signals (
    id bigint NOT NULL,
    run_id text NOT NULL,
    kind text NOT NULL,
    text text,
    payload jsonb,
    created_at bigint NOT NULL,
    consumed_at bigint,
    dedupe_key text
);


--
-- Name: run_signals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_signals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_signals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_signals_id_seq OWNED BY public.run_signals.id;


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runs (
    id text NOT NULL,
    session_id text NOT NULL,
    status text NOT NULL,
    request text NOT NULL,
    result text,
    idempotency_key text,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    lease_token text,
    lease_expires_at bigint,
    worker_id text,
    created_at bigint NOT NULL,
    started_at bigint,
    finished_at bigint,
    delivery_state text,
    error_attempts integer DEFAULT 0 NOT NULL,
    seq bigint NOT NULL,
    turn_user_seq bigint,
    retry_after bigint DEFAULT 0 NOT NULL,
    returned_at bigint,
    last_stop text,
    claim_priority smallint DEFAULT 2 NOT NULL,
    preemptions integer DEFAULT 0 NOT NULL
);


--
-- Name: runs_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.runs_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runs_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.runs_seq_seq OWNED BY public.runs.seq;


--
-- Name: sandbox_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_defaults (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: sandbox_resource_rollout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resource_rollout (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: sandbox_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resources (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: sandbox_routing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_routing (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: secret_drops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secret_drops (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: security_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_postures (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: session_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_goals (
    session_id text NOT NULL,
    objective text NOT NULL,
    status text NOT NULL,
    floor jsonb,
    token_cap bigint,
    tokens_used bigint DEFAULT 0 NOT NULL,
    active_ms bigint,
    active_since timestamp with time zone,
    completion_note text,
    cancel_note text,
    governor jsonb,
    pause_reason text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT session_goals_status_check CHECK ((status = ANY (ARRAY['active'::text, 'paused'::text, 'complete'::text, 'cancelled'::text])))
);


--
-- Name: session_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_leases (
    session_id text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    holder text,
    acquired_at bigint
);


--
-- Name: session_llm_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_llm_requests (
    id text NOT NULL,
    session_id text NOT NULL,
    turn_seq integer,
    step integer NOT NULL,
    model text NOT NULL,
    scope_label text NOT NULL,
    truncated boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    ttft_ms integer,
    duration_ms integer,
    step_gap_ms integer,
    tool_wall_json text,
    usage_json text,
    transport_json text,
    gap_phases_json text,
    prompt_hash text
);


--
-- Name: session_mailbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_mailbox (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: session_pins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_pins (
    id text NOT NULL,
    session_id text NOT NULL,
    text text,
    entry_seq integer,
    added_by text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: session_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_shares (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: session_spend_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_days (
    day bigint NOT NULL,
    rows jsonb NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: session_spend_dirty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_dirty (
    day bigint,
    session_id text,
    writer xid8 DEFAULT pg_current_xact_id() NOT NULL,
    CONSTRAINT session_spend_dirty_check CHECK ((num_nonnulls(day, session_id) = 1))
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    type text NOT NULL,
    scope_id text NOT NULL,
    thread_ref text NOT NULL,
    created_at bigint NOT NULL,
    title text,
    channel_name text,
    surface text,
    last_activity bigint,
    messages integer,
    turns integer,
    forked_from_session_id text,
    forked_from_title text,
    fork_boundary_seq integer,
    origin text,
    origin_id text,
    parent_session_id text,
    spawn_meta text,
    first_user_preview text,
    last_user_preview text,
    client_tools jsonb,
    last_user_activity bigint
)
WITH (fillfactor='70');


--
-- Name: sharing_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sharing_postures (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: skill_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_bundles (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: skill_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_packs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: slack_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_accounts (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: slack_emoji_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_emoji_catalog (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: slack_installation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_installation (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: slack_session_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_session_status (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: slack_staged_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_staged_envelopes (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: slack_task_acknowledgements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_task_acknowledgements (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: smolmachines_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smolmachines_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: soul_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: soul_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_history (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: source_auth_replay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_auth_replay (
    event_id text NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: suggested_activity_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suggested_activity_profiles (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: superserve_config_epochs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_config_epochs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: superserve_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: swarms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swarms (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    team_id text NOT NULL,
    principal_id text NOT NULL,
    role text NOT NULL,
    added_by text NOT NULL,
    added_at bigint NOT NULL,
    CONSTRAINT team_members_role_check CHECK ((role = ANY (ARRAY['member'::text, 'admin'::text])))
);


--
-- Name: team_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_rooms (
    team_id text NOT NULL,
    scope_id text NOT NULL
);


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    team_id text NOT NULL,
    name text NOT NULL,
    isolated_in_open boolean DEFAULT false NOT NULL,
    created_by text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: tool_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_calls (
    run_id text NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    call_index integer NOT NULL,
    output text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: unfulfilled_insights_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unfulfilled_insights_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: web_ui_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_ui_state (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: webhook_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_history (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: webui_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webui_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: ack_emoji_picks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks ALTER COLUMN id SET DEFAULT nextval('public.ack_emoji_picks_id_seq'::regclass);


--
-- Name: ambient_judgments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments ALTER COLUMN id SET DEFAULT nextval('public.ambient_judgments_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: channel_policy_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history ALTER COLUMN id SET DEFAULT nextval('public.channel_policy_history_id_seq'::regclass);


--
-- Name: credential_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage ALTER COLUMN id SET DEFAULT nextval('public.credential_usage_id_seq'::regclass);


--
-- Name: egress_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events ALTER COLUMN id SET DEFAULT nextval('public.egress_events_id_seq'::regclass);


--
-- Name: error_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events ALTER COLUMN id SET DEFAULT nextval('public.error_events_id_seq'::regclass);


--
-- Name: memory_facts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts ALTER COLUMN id SET DEFAULT nextval('public.memory_facts_id_seq'::regclass);


--
-- Name: run_activity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity ALTER COLUMN id SET DEFAULT nextval('public.run_activity_id_seq'::regclass);


--
-- Name: run_signals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals ALTER COLUMN id SET DEFAULT nextval('public.run_signals_id_seq'::regclass);


--
-- Name: runs seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs ALTER COLUMN seq SET DEFAULT nextval('public.runs_seq_seq'::regclass);


--
-- Name: ack_emoji_picks ack_emoji_picks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks
    ADD CONSTRAINT ack_emoji_picks_pkey PRIMARY KEY (id);


--
-- Name: ack_emoji ack_emoji_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji
    ADD CONSTRAINT ack_emoji_pkey PRIMARY KEY (id);


--
-- Name: acl_grants acl_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants
    ADD CONSTRAINT acl_grants_pkey PRIMARY KEY (owner_scope_id, path, grantee_scope_id, permission);


--
-- Name: acl_grants_version acl_grants_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants_version
    ADD CONSTRAINT acl_grants_version_pkey PRIMARY KEY (only_row);


--
-- Name: admin_grants admin_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_grants
    ADD CONSTRAINT admin_grants_pkey PRIMARY KEY (principal_id, scope_id, role);


--
-- Name: ambient_cursors ambient_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_cursors
    ADD CONSTRAINT ambient_cursors_pkey PRIMARY KEY (id);


--
-- Name: ambient_judgments ambient_judgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments
    ADD CONSTRAINT ambient_judgments_pkey PRIMARY KEY (id);


--
-- Name: approval_grant_modes approval_grant_modes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grant_modes
    ADD CONSTRAINT approval_grant_modes_pkey PRIMARY KEY (id);


--
-- Name: approval_grants approval_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grants
    ADD CONSTRAINT approval_grants_pkey PRIMARY KEY (id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (id);


--
-- Name: approved_harness_configs approved_harness_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approved_harness_configs
    ADD CONSTRAINT approved_harness_configs_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: auth_broker_sessions auth_broker_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_broker_sessions
    ADD CONSTRAINT auth_broker_sessions_pkey PRIMARY KEY (token_hash);


--
-- Name: auto_flagger_configs auto_flagger_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_flagger_configs
    ADD CONSTRAINT auto_flagger_configs_pkey PRIMARY KEY (id);


--
-- Name: aws_sandbox_bodies aws_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_sandbox_bodies
    ADD CONSTRAINT aws_sandbox_bodies_pkey PRIMARY KEY (id);


--
-- Name: base_model_configs base_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_model_configs
    ADD CONSTRAINT base_model_configs_pkey PRIMARY KEY (id);


--
-- Name: blobs blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blobs
    ADD CONSTRAINT blobs_pkey PRIMARY KEY (tenant_id, sha256);


--
-- Name: branding_configs branding_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_pkey PRIMARY KEY (id);


--
-- Name: browse_max_steps_configs browse_max_steps_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_max_steps_configs
    ADD CONSTRAINT browse_max_steps_configs_pkey PRIMARY KEY (id);


--
-- Name: browse_model_configs browse_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_model_configs
    ADD CONSTRAINT browse_model_configs_pkey PRIMARY KEY (id);


--
-- Name: browser_sessions browser_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browser_sessions
    ADD CONSTRAINT browser_sessions_pkey PRIMARY KEY (id);


--
-- Name: channel_files channel_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_files
    ADD CONSTRAINT channel_files_pkey PRIMARY KEY (org_id, container, ts, file_id);


--
-- Name: channel_header_pin_flag channel_header_pin_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_header_pin_flag
    ADD CONSTRAINT channel_header_pin_flag_pkey PRIMARY KEY (id);


--
-- Name: channel_messages channel_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_messages
    ADD CONSTRAINT channel_messages_pkey PRIMARY KEY (org_id, container, ts);


--
-- Name: channel_policy_history channel_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history
    ADD CONSTRAINT channel_policy_history_pkey PRIMARY KEY (id);


--
-- Name: channel_policy channel_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy
    ADD CONSTRAINT channel_policy_pkey PRIMARY KEY (org_id, container);


--
-- Name: channel_state channel_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_state
    ADD CONSTRAINT channel_state_pkey PRIMARY KEY (org_id, container);


--
-- Name: command_policies command_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_policies
    ADD CONSTRAINT command_policies_pkey PRIMARY KEY (id);


--
-- Name: composio_returns composio_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composio_returns
    ADD CONSTRAINT composio_returns_pkey PRIMARY KEY (id);


--
-- Name: connector_clients connector_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_clients
    ADD CONSTRAINT connector_clients_pkey PRIMARY KEY (id);


--
-- Name: connector_status connector_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_status
    ADD CONSTRAINT connector_status_pkey PRIMARY KEY (id);


--
-- Name: consent_links consent_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_links
    ADD CONSTRAINT consent_links_pkey PRIMARY KEY (id);


--
-- Name: context_requests context_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.context_requests
    ADD CONSTRAINT context_requests_pkey PRIMARY KEY (id);


--
-- Name: credential_daily_calls credential_daily_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_daily_calls
    ADD CONSTRAINT credential_daily_calls_pkey PRIMARY KEY (slug, day);


--
-- Name: credential_usage credential_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage
    ADD CONSTRAINT credential_usage_pkey PRIMARY KEY (id);


--
-- Name: cron_fires cron_fires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fires
    ADD CONSTRAINT cron_fires_pkey PRIMARY KEY (cron_id, fire_key);


--
-- Name: crons crons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crons
    ADD CONSTRAINT crons_pkey PRIMARY KEY (id);


--
-- Name: custom_model_providers custom_model_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_model_providers
    ADD CONSTRAINT custom_model_providers_pkey PRIMARY KEY (id);


--
-- Name: deactivated_principals deactivated_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deactivated_principals
    ADD CONSTRAINT deactivated_principals_pkey PRIMARY KEY (id);


--
-- Name: decision_providers decision_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_providers
    ADD CONSTRAINT decision_providers_pkey PRIMARY KEY (provider_id);


--
-- Name: decision_rules decision_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_pkey PRIMARY KEY (rule_id);


--
-- Name: deliveries deliveries_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (id);


--
-- Name: deploy_git_repos deploy_git_repos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_git_repos
    ADD CONSTRAINT deploy_git_repos_pkey PRIMARY KEY (id);


--
-- Name: deployment_access deployment_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_pkey PRIMARY KEY (id);


--
-- Name: deployment_identity deployment_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_identity
    ADD CONSTRAINT deployment_identity_pkey PRIMARY KEY (id);


--
-- Name: deployment_layer deployment_layer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_layer
    ADD CONSTRAINT deployment_layer_pkey PRIMARY KEY (id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (id);


--
-- Name: directory_channel_members directory_channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channel_members
    ADD CONSTRAINT directory_channel_members_pkey PRIMARY KEY (org_id, channel_id, principal_id);


--
-- Name: directory_channels directory_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channels
    ADD CONSTRAINT directory_channels_pkey PRIMARY KEY (org_id, channel_id);


--
-- Name: directory_group_members directory_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_group_members
    ADD CONSTRAINT directory_group_members_pkey PRIMARY KEY (org_id, group_id, principal_id);


--
-- Name: directory_groups directory_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_groups
    ADD CONSTRAINT directory_groups_pkey PRIMARY KEY (org_id, group_id);


--
-- Name: directory_members directory_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_members
    ADD CONSTRAINT directory_members_pkey PRIMARY KEY (org_id, principal_id);


--
-- Name: directory_meta directory_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_meta
    ADD CONSTRAINT directory_meta_pkey PRIMARY KEY (org_id);


--
-- Name: directory_sync directory_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_sync
    ADD CONSTRAINT directory_sync_pkey PRIMARY KEY (org_id);


--
-- Name: do_managed_agents_sandbox_bodies do_managed_agents_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.do_managed_agents_sandbox_bodies
    ADD CONSTRAINT do_managed_agents_sandbox_bodies_pkey PRIMARY KEY (id);


--
-- Name: durable_map_versions durable_map_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.durable_map_versions
    ADD CONSTRAINT durable_map_versions_pkey PRIMARY KEY (tbl);


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2b_sandbox_bodies
    ADD CONSTRAINT e2b_sandbox_bodies_pkey PRIMARY KEY (id);


--
-- Name: egress_events egress_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events
    ADD CONSTRAINT egress_events_pkey PRIMARY KEY (id);


--
-- Name: egress_policies egress_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_policies
    ADD CONSTRAINT egress_policies_pkey PRIMARY KEY (id);


--
-- Name: environment_attachments environment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_pkey PRIMARY KEY (scope_id);


--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (id);


--
-- Name: error_events error_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events
    ADD CONSTRAINT error_events_pkey PRIMARY KEY (id);


--
-- Name: external_members external_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_members
    ADD CONSTRAINT external_members_pkey PRIMARY KEY (id);


--
-- Name: external_slack_participants_flag external_slack_participants_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_slack_participants_flag
    ADD CONSTRAINT external_slack_participants_flag_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: file_artifact_deletions file_artifact_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifact_deletions
    ADD CONSTRAINT file_artifact_deletions_pkey PRIMARY KEY (id);


--
-- Name: file_artifacts file_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifacts
    ADD CONSTRAINT file_artifacts_pkey PRIMARY KEY (id);


--
-- Name: idempotency idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency
    ADD CONSTRAINT idempotency_pkey PRIMARY KEY (id);


--
-- Name: individual_model_auth_flag individual_model_auth_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.individual_model_auth_flag
    ADD CONSTRAINT individual_model_auth_flag_pkey PRIMARY KEY (id);


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactive_fast_mode_flag
    ADD CONSTRAINT interactive_fast_mode_flag_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (tenant_id, session_id, seq);


--
-- Name: keychain_asks keychain_asks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_asks
    ADD CONSTRAINT keychain_asks_pkey PRIMARY KEY (id);


--
-- Name: keychain_credentials keychain_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_credentials
    ADD CONSTRAINT keychain_credentials_pkey PRIMARY KEY (id);


--
-- Name: keychain_grants keychain_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_grants
    ADD CONSTRAINT keychain_grants_pkey PRIMARY KEY (id);


--
-- Name: llm_prompt_envelopes llm_prompt_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_prompt_envelopes
    ADD CONSTRAINT llm_prompt_envelopes_pkey PRIMARY KEY (hash);


--
-- Name: loop_ingress_deliveries loop_ingress_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress_deliveries
    ADD CONSTRAINT loop_ingress_deliveries_pkey PRIMARY KEY (id);


--
-- Name: loop_ingress loop_ingress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress
    ADD CONSTRAINT loop_ingress_pkey PRIMARY KEY (id);


--
-- Name: loop_items loop_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_items
    ADD CONSTRAINT loop_items_pkey PRIMARY KEY (id);


--
-- Name: loop_outputs loop_outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_outputs
    ADD CONSTRAINT loop_outputs_pkey PRIMARY KEY (id);


--
-- Name: loop_ship_grants loop_ship_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ship_grants
    ADD CONSTRAINT loop_ship_grants_pkey PRIMARY KEY (id);


--
-- Name: loops loops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loops
    ADD CONSTRAINT loops_pkey PRIMARY KEY (id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (id);


--
-- Name: memory_facts memory_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_pkey PRIMARY KEY (id);


--
-- Name: memory_tidy_profiles memory_tidy_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_tidy_profiles
    ADD CONSTRAINT memory_tidy_profiles_pkey PRIMARY KEY (id);


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modal_sandbox_bodies
    ADD CONSTRAINT modal_sandbox_bodies_pkey PRIMARY KEY (id);


--
-- Name: model_credentials model_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_credentials
    ADD CONSTRAINT model_credentials_pkey PRIMARY KEY (id);


--
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (id);


--
-- Name: monitors monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_pkey PRIMARY KEY (id);


--
-- Name: oauth_flows oauth_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_flows
    ADD CONSTRAINT oauth_flows_pkey PRIMARY KEY (id);


--
-- Name: org_ambient_flag org_ambient_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_ambient_flag
    ADD CONSTRAINT org_ambient_flag_pkey PRIMARY KEY (id);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (session_id, principal_id);


--
-- Name: principal_links principal_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.principal_links
    ADD CONSTRAINT principal_links_pkey PRIMARY KEY (id);


--
-- Name: process_sessions process_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_sessions
    ADD CONSTRAINT process_sessions_pkey PRIMARY KEY (process_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: qm_schema_migrations qm_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_schema_migrations
    ADD CONSTRAINT qm_schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: qm_settings qm_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_settings
    ADD CONSTRAINT qm_settings_pkey PRIMARY KEY (key);


--
-- Name: qm_tenant qm_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_tenant
    ADD CONSTRAINT qm_tenant_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_windows rate_limit_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_windows
    ADD CONSTRAINT rate_limit_windows_pkey PRIMARY KEY (principal_id);


--
-- Name: run_activity run_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity
    ADD CONSTRAINT run_activity_pkey PRIMARY KEY (id);


--
-- Name: run_signals run_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals
    ADD CONSTRAINT run_signals_pkey PRIMARY KEY (id);


--
-- Name: runs runs_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (id);


--
-- Name: sandbox_defaults sandbox_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_defaults
    ADD CONSTRAINT sandbox_defaults_pkey PRIMARY KEY (id);


--
-- Name: sandbox_resource_rollout sandbox_resource_rollout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resource_rollout
    ADD CONSTRAINT sandbox_resource_rollout_pkey PRIMARY KEY (id);


--
-- Name: sandbox_resources sandbox_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resources
    ADD CONSTRAINT sandbox_resources_pkey PRIMARY KEY (id);


--
-- Name: sandbox_routing sandbox_routing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_routing
    ADD CONSTRAINT sandbox_routing_pkey PRIMARY KEY (id);


--
-- Name: secret_drops secret_drops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_drops
    ADD CONSTRAINT secret_drops_pkey PRIMARY KEY (id);


--
-- Name: security_postures security_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_postures
    ADD CONSTRAINT security_postures_pkey PRIMARY KEY (id);


--
-- Name: session_goals session_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_pkey PRIMARY KEY (session_id);


--
-- Name: session_leases session_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_leases
    ADD CONSTRAINT session_leases_pkey PRIMARY KEY (session_id);


--
-- Name: session_llm_requests session_llm_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_llm_requests
    ADD CONSTRAINT session_llm_requests_pkey PRIMARY KEY (id);


--
-- Name: session_mailbox session_mailbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_mailbox
    ADD CONSTRAINT session_mailbox_pkey PRIMARY KEY (id);


--
-- Name: session_pins session_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_pins
    ADD CONSTRAINT session_pins_pkey PRIMARY KEY (id);


--
-- Name: session_shares session_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_shares
    ADD CONSTRAINT session_shares_pkey PRIMARY KEY (id);


--
-- Name: session_spend_days session_spend_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_days
    ADD CONSTRAINT session_spend_days_pkey PRIMARY KEY (day);


--
-- Name: session_spend_dirty session_spend_dirty_day_writer_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_dirty
    ADD CONSTRAINT session_spend_dirty_day_writer_key UNIQUE (day, writer);


--
-- Name: sessions sessions_fork_provenance_pair; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.sessions
    ADD CONSTRAINT sessions_fork_provenance_pair CHECK (((forked_from_session_id IS NULL) = (fork_boundary_seq IS NULL))) NOT VALID;


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_thread_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_thread_ref_key UNIQUE (thread_ref);


--
-- Name: sharing_postures sharing_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sharing_postures
    ADD CONSTRAINT sharing_postures_pkey PRIMARY KEY (id);


--
-- Name: skill_bundles skill_bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_bundles
    ADD CONSTRAINT skill_bundles_pkey PRIMARY KEY (id);


--
-- Name: skill_packs skill_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_pkey PRIMARY KEY (id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- Name: slack_accounts slack_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_accounts
    ADD CONSTRAINT slack_accounts_pkey PRIMARY KEY (id);


--
-- Name: slack_emoji_catalog slack_emoji_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_emoji_catalog
    ADD CONSTRAINT slack_emoji_catalog_pkey PRIMARY KEY (id);


--
-- Name: slack_installation slack_installation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_installation
    ADD CONSTRAINT slack_installation_pkey PRIMARY KEY (id);


--
-- Name: slack_session_status slack_session_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_session_status
    ADD CONSTRAINT slack_session_status_pkey PRIMARY KEY (id);


--
-- Name: slack_staged_envelopes slack_staged_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_staged_envelopes
    ADD CONSTRAINT slack_staged_envelopes_pkey PRIMARY KEY (id);


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_task_acknowledgements
    ADD CONSTRAINT slack_task_acknowledgements_pkey PRIMARY KEY (id);


--
-- Name: smolmachines_sandbox_bodies smolmachines_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smolmachines_sandbox_bodies
    ADD CONSTRAINT smolmachines_sandbox_bodies_pkey PRIMARY KEY (id);


--
-- Name: soul_configs soul_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_configs
    ADD CONSTRAINT soul_configs_pkey PRIMARY KEY (id);


--
-- Name: soul_history soul_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_history
    ADD CONSTRAINT soul_history_pkey PRIMARY KEY (id);


--
-- Name: source_auth_replay source_auth_replay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_auth_replay
    ADD CONSTRAINT source_auth_replay_pkey PRIMARY KEY (event_id);


--
-- Name: suggested_activity_profiles suggested_activity_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggested_activity_profiles
    ADD CONSTRAINT suggested_activity_profiles_pkey PRIMARY KEY (id);


--
-- Name: superserve_config_epochs superserve_config_epochs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_config_epochs
    ADD CONSTRAINT superserve_config_epochs_pkey PRIMARY KEY (id);


--
-- Name: superserve_sandbox_bodies superserve_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_sandbox_bodies
    ADD CONSTRAINT superserve_sandbox_bodies_pkey PRIMARY KEY (id);


--
-- Name: swarms swarms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarms
    ADD CONSTRAINT swarms_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (team_id, principal_id);


--
-- Name: team_rooms team_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_pkey PRIMARY KEY (team_id, scope_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (team_id);


--
-- Name: tool_calls tool_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls
    ADD CONSTRAINT tool_calls_pkey PRIMARY KEY (run_id, attempt, call_index);


--
-- Name: unfulfilled_insights_flag unfulfilled_insights_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unfulfilled_insights_flag
    ADD CONSTRAINT unfulfilled_insights_flag_pkey PRIMARY KEY (id);


--
-- Name: web_ui_state web_ui_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_ui_state
    ADD CONSTRAINT web_ui_state_pkey PRIMARY KEY (id);


--
-- Name: webhook_history webhook_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_history
    ADD CONSTRAINT webhook_history_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: webui_model_configs webui_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webui_model_configs
    ADD CONSTRAINT webui_model_configs_pkey PRIMARY KEY (id);


--
-- Name: ack_emoji_picks_org_channel_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_channel_created ON public.ack_emoji_picks USING btree (org_id, channel, created_at DESC);


--
-- Name: ack_emoji_picks_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_created ON public.ack_emoji_picks USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ack_emoji_picks_org_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_outcome ON public.ack_emoji_picks USING btree (org_id, outcome);


--
-- Name: ambient_judgments_org_container_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_container_created ON public.ambient_judgments USING btree (org_id, container, created_at DESC);


--
-- Name: ambient_judgments_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_created ON public.ambient_judgments USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ambient_judgments_org_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_decision ON public.ambient_judgments USING btree (org_id, decision);


--
-- Name: approvals_sessionid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_sessionid_fold ON public.approvals USING hash (lower((json ->> 'sessionId'::text)));


--
-- Name: approvals_sessionid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_sessionid_unicode ON public.approvals USING btree (id) WHERE ((json ->> 'sessionId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: audit_log_by_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_action ON public.audit_log USING btree (action, at DESC);


--
-- Name: audit_log_by_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_at ON public.audit_log USING btree (at DESC);


--
-- Name: audit_log_by_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX audit_log_by_idempotency_key ON public.audit_log USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: audit_log_by_scope_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_scope_at ON public.audit_log USING btree (scope_label, at DESC);


--
-- Name: auth_broker_sessions_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_email ON public.auth_broker_sessions USING btree (email);


--
-- Name: auth_broker_sessions_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_expiry ON public.auth_broker_sessions USING btree (expires_at);


--
-- Name: channel_messages_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_container ON public.channel_messages USING btree (org_id, container, ts);


--
-- Name: channel_messages_by_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_sub ON public.channel_messages USING btree (org_id, container, sub, ts);


--
-- Name: channel_messages_deleted_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_deleted_by_container ON public.channel_messages USING btree (org_id, container, deleted_at) WHERE (deleted_at > 0);


--
-- Name: channel_messages_edited_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_edited_by_container ON public.channel_messages USING btree (org_id, container, edited_at) WHERE (edited_at > 0);


--
-- Name: channel_messages_live_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_live_by_container ON public.channel_messages USING btree (org_id, container) WHERE (deleted = false);


--
-- Name: channel_messages_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_tsv ON public.channel_messages USING gin (tsv);


--
-- Name: channel_policy_history_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_policy_history_container ON public.channel_policy_history USING btree (org_id, container, id DESC);


--
-- Name: credential_usage_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_scope_ts ON public.credential_usage USING btree (scope_label, ts DESC);


--
-- Name: credential_usage_by_slug_ts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_slug_ts_id ON public.credential_usage USING btree (slug, ts DESC, id DESC);


--
-- Name: credential_usage_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_ts ON public.credential_usage USING btree (ts DESC);


--
-- Name: crons_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_resource_search_gin ON public.crons USING gin (to_tsvector('simple'::regconfig, ((((COALESCE((json ->> 'title'::text), ''::text) || ' '::text) || COALESCE((json ->> 'action'::text), ''::text)) || ' '::text) || COALESCE((json ->> 'message'::text), ''::text))));


--
-- Name: decision_rules_hook; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX decision_rules_hook ON public.decision_rules USING btree (hook) WHERE (mode <> 'off'::text);


--
-- Name: deployments_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployments_resource_search_gin ON public.deployments USING gin (to_tsvector('simple'::regconfig, ((COALESCE((json ->> 'displayName'::text), (json ->> 'name'::text), ''::text) || ' '::text) || COALESCE((json ->> 'name'::text), ''::text))));


--
-- Name: directory_channels_lower_cid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_lower_cid ON public.directory_channels USING btree (org_id, lower(channel_id));


--
-- Name: directory_channels_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_name ON public.directory_channels USING btree (org_id, name_lc);


--
-- Name: directory_group_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_group_members_principal ON public.directory_group_members USING btree (org_id, principal_id, group_id);


--
-- Name: directory_members_lower_pid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_lower_pid ON public.directory_members USING btree (org_id, lower(principal_id));


--
-- Name: directory_members_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_name ON public.directory_members USING btree (org_id, display_name_lc);


--
-- Name: egress_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_scope_ts ON public.egress_events USING btree (scope_label, ts DESC);


--
-- Name: egress_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_ts ON public.egress_events USING btree (ts DESC);


--
-- Name: environment_attachments_by_env; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_attachments_by_env ON public.environment_attachments USING btree (environment_id);


--
-- Name: error_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_scope_ts ON public.error_events USING btree (scope_label, ts DESC);


--
-- Name: error_events_by_session_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_session_ts ON public.error_events USING btree (session_id, ts DESC);


--
-- Name: error_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_ts ON public.error_events USING btree (ts DESC);


--
-- Name: file_artifacts_owner_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_created ON public.file_artifacts USING btree (owner_scope_id, created_at DESC, id DESC);


--
-- Name: file_artifacts_owner_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_path ON public.file_artifacts USING btree (owner_scope_id, path);


--
-- Name: file_artifacts_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_scope_created ON public.file_artifacts USING btree (created_in_scope, created_at DESC, id DESC) WHERE (enabled = true);


--
-- Name: idx_cron_fires_cron_fired_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_cron_fired_at ON public.cron_fires USING btree (cron_id, fired_at DESC);


--
-- Name: idx_cron_fires_thread_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_thread_ref ON public.cron_fires USING btree (thread_ref);


--
-- Name: idx_deliveries_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_pending ON public.deliveries USING btree (((destination ->> 'type'::text)), created_at) WHERE (delivered_at IS NULL);


--
-- Name: idx_deliveries_pending_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_pending_live ON public.deliveries USING btree (((destination ->> 'type'::text)), created_at) WHERE ((delivered_at IS NULL) AND (expired_at IS NULL));


--
-- Name: idx_deliveries_recipient_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_recipient_thread ON public.deliveries USING btree (recipient_thread_ref, created_at) WHERE (recipient_thread_ref IS NOT NULL);


--
-- Name: idx_deliveries_shadow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_shadow ON public.deliveries USING btree (created_at) WHERE (shadow AND (delivered_at IS NULL));


--
-- Name: idx_deliveries_source_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_source_session ON public.deliveries USING btree (((provenance ->> 'sourceSessionId'::text)), created_at) WHERE (provenance IS NOT NULL);


--
-- Name: idx_deliveries_source_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_source_thread ON public.deliveries USING btree (((provenance ->> 'sourceThreadRef'::text)), created_at) WHERE (provenance IS NOT NULL);


--
-- Name: idx_proc_scope_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proc_scope_status ON public.process_sessions USING btree (scope_id, status);


--
-- Name: idx_run_activity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_created ON public.run_activity USING btree (created_at);


--
-- Name: idx_run_activity_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_run ON public.run_activity USING btree (run_id, id);


--
-- Name: idx_run_signals_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_signals_pending ON public.run_signals USING btree (run_id) WHERE (consumed_at IS NULL);


--
-- Name: idx_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_created ON public.runs USING btree (created_at DESC);


--
-- Name: idx_runs_one_running_per_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_runs_one_running_per_session ON public.runs USING btree (session_id) WHERE (status = 'running'::text);


--
-- Name: idx_runs_pending_child_returns; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_child_returns ON public.runs USING btree (id) WHERE ((status = ANY (ARRAY['done'::text, 'failed'::text])) AND (returned_at IS NULL) AND (session_id ~~ 'agent:main:subagent:%'::text));


--
-- Name: idx_runs_pending_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_priority ON public.runs USING btree (claim_priority, created_at, seq) WHERE (status = 'pending'::text);


--
-- Name: idx_runs_session_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_active_created ON public.runs USING btree (session_id, created_at DESC) WHERE (status = ANY (ARRAY['pending'::text, 'running'::text]));


--
-- Name: idx_runs_session_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_created_seq ON public.runs USING btree (session_id, created_at DESC, seq DESC);


--
-- Name: idx_runs_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created ON public.runs USING btree (status, created_at);


--
-- Name: idx_runs_status_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created_seq ON public.runs USING btree (status, created_at, seq);


--
-- Name: idx_runs_terminal_finished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_terminal_finished ON public.runs USING btree (finished_at, id) WHERE (status = ANY (ARRAY['done'::text, 'failed'::text]));


--
-- Name: idx_sessions_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_parent_session_id ON public.sessions USING btree (parent_session_id) WHERE (parent_session_id IS NOT NULL);


--
-- Name: items_by_elicit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_elicit ON public.items USING btree (tenant_id, session_id, elicit_id) WHERE (elicit_id IS NOT NULL);


--
-- Name: items_by_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_external_id ON public.items USING btree (tenant_id, session_id, external_id) WHERE (external_id IS NOT NULL);


--
-- Name: items_by_turn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_turn ON public.items USING btree (tenant_id, turn_id, seq) WHERE (turn_id IS NOT NULL);


--
-- Name: items_one_call_per_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX items_one_call_per_kind ON public.items USING btree (tenant_id, session_id, kind, md5(call_id)) WHERE (call_id IS NOT NULL);


--
-- Name: items_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_search ON public.items USING gin (tenant_id, session_id, search);


--
-- Name: items_session_kind_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_session_kind_created ON public.items USING btree (tenant_id, session_id, kind, created_at);


--
-- Name: keychain_credentials_ownerid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_ownerid_fold ON public.keychain_credentials USING hash (lower((json ->> 'ownerId'::text)));


--
-- Name: keychain_credentials_ownerid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_ownerid_unicode ON public.keychain_credentials USING btree (id) WHERE ((json ->> 'ownerId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: keychain_grants_ownerid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_ownerid_fold ON public.keychain_grants USING hash (lower((json ->> 'ownerId'::text)));


--
-- Name: keychain_grants_ownerid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_ownerid_unicode ON public.keychain_grants USING btree (id) WHERE ((json ->> 'ownerId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: llm_prompt_envelopes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX llm_prompt_envelopes_created_at ON public.llm_prompt_envelopes USING btree (created_at);


--
-- Name: loop_ingress_deliveries_queuekey_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_deliveries_queuekey_fold ON public.loop_ingress_deliveries USING hash (lower((json ->> 'queueKey'::text)));


--
-- Name: loop_ingress_deliveries_queuekey_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_deliveries_queuekey_unicode ON public.loop_ingress_deliveries USING btree (id) WHERE ((json ->> 'queueKey'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_ingress_loopid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_loopid_fold ON public.loop_ingress USING hash (lower((json ->> 'loopId'::text)));


--
-- Name: loop_ingress_loopid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_loopid_unicode ON public.loop_ingress USING btree (id) WHERE ((json ->> 'loopId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_items_loopid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_items_loopid_fold ON public.loop_items USING hash (lower((json ->> 'loopId'::text)));


--
-- Name: loop_items_loopid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_items_loopid_unicode ON public.loop_items USING btree (id) WHERE ((json ->> 'loopId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_outputs_itemid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_outputs_itemid_fold ON public.loop_outputs USING hash (lower((json ->> 'itemId'::text)));


--
-- Name: loop_outputs_itemid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_outputs_itemid_unicode ON public.loop_outputs USING btree (id) WHERE ((json ->> 'itemId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: memory_facts_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX memory_facts_live ON public.memory_facts USING btree (scope_id, id) WHERE (deleted_at IS NULL);


--
-- Name: participants_by_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX participants_by_principal ON public.participants USING btree (principal_id, session_id);


--
-- Name: qm_tenant_singleton; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qm_tenant_singleton ON public.qm_tenant USING btree ((true));


--
-- Name: run_signals_by_dedupe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX run_signals_by_dedupe_key ON public.run_signals USING btree (dedupe_key) WHERE (dedupe_key IS NOT NULL);


--
-- Name: session_llm_requests_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_by_session ON public.session_llm_requests USING btree (session_id, created_at, step);


--
-- Name: session_llm_requests_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_created_at ON public.session_llm_requests USING btree (created_at);


--
-- Name: session_llm_requests_screens; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_screens ON public.session_llm_requests USING btree (created_at DESC) WHERE (step = '-1'::integer);


--
-- Name: session_llm_requests_spend; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend ON public.session_llm_requests USING btree (created_at, (((public.spend_usage_json(usage_json) ->> 'costUsd'::text))::double precision), (((public.spend_usage_json(usage_json) ->> 'input'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'output'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'cacheRead'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'cacheWrite'::text))::bigint)) INCLUDE (session_id, model, usage_json) WHERE ((usage_json IS NOT NULL) AND ((public.spend_usage_json(usage_json) IS NOT NULL) AND (((octet_length(session_id) + octet_length(model)) + octet_length(usage_json)) <= 2000)));


--
-- Name: session_llm_requests_spend_wide; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend_wide ON public.session_llm_requests USING btree (created_at) WHERE ((usage_json IS NOT NULL) AND (NOT ((public.spend_usage_json(usage_json) IS NOT NULL) AND (((octet_length(session_id) + octet_length(model)) + octet_length(usage_json)) <= 2000))));


--
-- Name: session_mailbox_recipientid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipientid_fold ON public.session_mailbox USING hash (lower((json ->> 'recipientId'::text)));


--
-- Name: session_mailbox_recipientid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipientid_unicode ON public.session_mailbox USING btree (id) WHERE ((json ->> 'recipientId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: session_pins_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_pins_by_session ON public.session_pins USING btree (session_id, created_at);


--
-- Name: sessions_by_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_activity ON public.sessions USING btree (COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_by_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope ON public.sessions USING btree (scope_id, created_at DESC);


--
-- Name: sessions_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_conversations_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_conversations_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin = 'conversation'::text);


--
-- Name: sessions_other_background_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_other_background_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin <> ALL (ARRAY['conversation'::text, 'cron'::text]));


--
-- Name: skills_resource_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_name_idx ON public.skills USING btree ((((json -> 'manifest'::text) ->> 'name'::text)));


--
-- Name: skills_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_search_gin ON public.skills USING gin (to_tsvector('simple'::regconfig, ((COALESCE(((json -> 'manifest'::text) ->> 'name'::text), ''::text) || ' '::text) || COALESCE(((json -> 'manifest'::text) ->> 'description'::text), ''::text))));


--
-- Name: source_auth_replay_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_auth_replay_expires_at ON public.source_auth_replay USING btree (expires_at);


--
-- Name: swarms_pending_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX swarms_pending_fold ON public.swarms USING hash (lower((json ->> 'pending'::text)));


--
-- Name: swarms_pending_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX swarms_pending_unicode ON public.swarms USING btree (id) WHERE ((json ->> 'pending'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: team_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_members_principal ON public.team_members USING btree (principal_id);


--
-- Name: team_rooms_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_rooms_scope ON public.team_rooms USING btree (scope_id);


--
-- Name: webhooks_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_resource_search_gin ON public.webhooks USING gin (to_tsvector('simple'::regconfig, ((COALESCE((json ->> 'action'::text), ''::text) || ' '::text) || COALESCE(((json -> 'verification'::text) ->> 'scheme'::text), ''::text))));


--
-- Name: approvals_sessionid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.approvals_sessionid_stats ON (json ->> 'sessionId'::text) FROM public.approvals;


--
-- Name: keychain_credentials_ownerid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.keychain_credentials_ownerid_stats ON (json ->> 'ownerId'::text) FROM public.keychain_credentials;


--
-- Name: keychain_grants_ownerid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.keychain_grants_ownerid_stats ON (json ->> 'ownerId'::text) FROM public.keychain_grants;


--
-- Name: loop_ingress_deliveries_queuekey_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_ingress_deliveries_queuekey_stats ON (json ->> 'queueKey'::text) FROM public.loop_ingress_deliveries;


--
-- Name: loop_ingress_loopid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_ingress_loopid_stats ON (json ->> 'loopId'::text) FROM public.loop_ingress;


--
-- Name: loop_items_loopid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_items_loopid_stats ON (json ->> 'loopId'::text) FROM public.loop_items;


--
-- Name: loop_outputs_itemid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_outputs_itemid_stats ON (json ->> 'itemId'::text) FROM public.loop_outputs;


--
-- Name: session_mailbox_recipientid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.session_mailbox_recipientid_stats ON (json ->> 'recipientId'::text) FROM public.session_mailbox;


--
-- Name: swarms_pending_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.swarms_pending_stats ON (json ->> 'pending'::text) FROM public.swarms;


--
-- Name: acl_grants acl_grants_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER acl_grants_bump AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.acl_grants FOR EACH STATEMENT EXECUTE FUNCTION public.acl_grants_bump_version();


--
-- Name: blobs blobs_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_immutable BEFORE DELETE OR UPDATE ON public.blobs FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: blobs blobs_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_no_truncate BEFORE TRUNCATE ON public.blobs FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_append_only BEFORE UPDATE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_delete_through_session; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_delete_through_session BEFORE DELETE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_direct_delete();


--
-- Name: items items_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_no_truncate BEFORE TRUNCATE ON public.items FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: session_llm_requests session_llm_requests_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_llm_requests_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF created_at, session_id, model, usage_json ON public.session_llm_requests FOR EACH ROW EXECUTE FUNCTION public.invalidate_request_spend();


--
-- Name: sessions sessions_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sessions_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF id, scope_id, origin, thread_ref, parent_session_id ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.invalidate_session_spend();


--
-- Name: decision_rules decision_rules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.decision_providers(provider_id);


--
-- Name: deployment_access deployment_access_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_id_fkey FOREIGN KEY (id) REFERENCES public.deployments(id) ON DELETE CASCADE;


--
-- Name: environment_attachments environment_attachments_environment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_environment_id_fkey FOREIGN KEY (environment_id) REFERENCES public.environments(id);


--
-- Name: items items_blob; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_blob FOREIGN KEY (tenant_id, blob_sha) REFERENCES public.blobs(tenant_id, sha256);


--
-- Name: items items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: session_goals session_goals_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: team_rooms team_rooms_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-1.pgdg26.04+2)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-1.pgdg26.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: acl_grants_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.acl_grants_version VALUES (true, 2);


--
-- Data for Name: qm_schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0001', '11758af3276004ec5ba9f283d35867d074999b2413b1ab6d74a4545e8fba16fa', '2026-10-26 15:40:33.132909+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0002', '86f3cbd7981ea8e137a31f6e66936ce53654c013c6f20dbb9924692a2263ed0d', '2026-10-26 15:40:33.144305+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0003-file-ids', '2ad7a5a68acb5da6ed801d2b4c1d56391e14bf1eef0356948f661c5a293825de', '2026-10-26 15:40:33.153268+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0001', '542f2a64d2814b329f2c1ad2eb8ed2728e8044b78efa6343eafb5598bc83cb1d', '2026-10-26 15:40:33.159233+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0002', 'bce8b31764744856dab57f8ced3a2e33b36e5896ff0f915152dc466741be3828', '2026-10-26 15:40:33.18241+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/grants/0001', '1a92727b41adaa11bf3029a419a8a5ca9213b0fbab91df905b7e58803cc73ce4', '2026-10-26 15:40:33.224215+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0001', '42188c2f50734398496ddd5a47a9ec3c15a507059c713a4a6ced0b0b81d908eb', '2026-10-26 15:40:33.24334+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0002', 'eb3194ec38847b601025c41b99616c4385770930074e808b21e53af9463d7ad0', '2026-10-26 15:40:33.279472+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0003', '74b2011593ba178ca8decc6f7c82528f7bd161c4651fc2700a78839dac32fc04', '2026-10-26 15:40:33.281833+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/egress_events/0001', 'cfbf4ab51c2b0a4ac45eaeeb7a7011d7b2a4a4d9c21072473ed27400b03fe054', '2026-10-26 15:40:33.293927+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/error_events/0001', 'd5bab01c9f83042aace325e98636b614bcb8a6d77fedaed373f02efde282f5b8', '2026-10-26 15:40:33.31321+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/broker-sessions/0001', '2f958c4c732f8a8a79cb1d31215236fea9565ee2ce5e62270952b889ec5c1265', '2026-10-26 15:40:33.334893+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/replay-dedupe/0001', '8714fae4d626c773edfacf59d807e324955a205abb2be2bc76753cdbbc14adf7', '2026-10-26 15:40:33.352195+00');
INSERT INTO public.qm_schema_migrations VALUES ('cron/fires/0001', '462f9f784160d6e31019707b7df3c35ef0a2979fd3c9fb9d4d581fb89de6cad1', '2026-10-26 15:40:33.367054+00');
INSERT INTO public.qm_schema_migrations VALUES ('decisions/0001', '5259b744d814f2aae9b056e69f4488b87276b8db7eeb17d140d6e89bab93218a', '2026-10-26 15:40:33.386663+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0001', '518a78830cb91440cee2642d600fb0532084bbe2e2bc4c69c47cc51756be614e', '2026-10-26 15:40:33.412213+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0004', 'a712456e95a8e05c1bfa3dcfe8e2cdffe6a49c94f191bd2cb9e594277e1b895c', '2026-10-26 15:40:33.451287+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0005', 'd725fa7f171c9b29c14146029a2804cf94a814e8146c8c1a2b16953310fbfd1e', '2026-10-26 15:40:33.4541+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0006', '7d0550f008aa2df653dd112199318a24a7151912338aa408e499fce0d1f756a1', '2026-10-26 15:40:33.460223+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/access/0001', 'fa35b86cbdfa9e8766ac5e47ffc926986b87ec5bad3ef1d7070fb8e2a1f3f9c2', '2026-10-26 15:40:33.462773+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0001', 'c47a45848f9d225ff601c9df13dc272349c7df7525e7e2417f33d68be7672cc1', '2026-10-26 15:40:33.482381+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0002', '4da6cc4f2496dd53d6381faea3f9f8e16e55394cfe46de516a692ede8157e8b0', '2026-10-26 15:40:33.629633+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0003', '1aaf42502793ebc31b253b12903cf192d2d8d6bcc9e4c1d31e834ed385f2a030', '2026-10-26 15:40:33.632196+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0004', '5376eae39ee0e8d99157e30b6edfbe8b35a0a0998bc4766a86529a45c0e83c4d', '2026-10-26 15:40:33.648959+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0005', '38afbb8d963f48be05d5837f7f06e9f531229316c973c5f87eaa790e2611a8d9', '2026-10-26 15:40:33.651632+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ack_emoji/0001', 'b5cc8b58d6905bf400f15326b4fa4fd3517171dc7e3a2108d23ccc936612ab57', '2026-10-26 15:40:33.654841+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ambient_cursors/0001', 'af7f98b52db7c0fe09648b4ca964f6ccaeb1bbe283cc4d39184f8084db465551', '2026-10-26 15:40:33.674753+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grant_modes/0001', '71fcc4c066ec51b5ea8529444cadf6b02193c31760bde9adbf1d198d31c5829a', '2026-10-26 15:40:33.684915+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/0001', '584a7fe0f0a43a421793efed03be20afc249a2ce02dd3ff4924e4cd536ebbc9d', '2026-10-26 15:40:33.695938+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/0001', 'cd76491910753bae97e30680661f57cdde84d6583d724198cba5e0d71032dcb5', '2026-10-26 15:40:33.705472+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/lookup-sessionid-drop', 'f97131836d0b702bc1a1693e03bd5d97558a5aa95c5324ec0ce4a8b357814141', '2026-10-26 15:40:33.717698+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/lookup-sessionid-hash', 'cc98fbd26fca3ecf2c80295e1057e90abbcde3481211ce9082daed8aeedab4f3', '2026-10-26 15:40:33.726577+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/select-sessionid', 'e44a660c6180087f9a8b08be2493eedd0595d4029552b08e3c089d2be47796f4', '2026-10-26 15:40:33.73926+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/stats-sessionid', 'c3c521e26580047f3e4b337f1cf2713f30c21e3d3b8c4c44d699b4dd17e7be45', '2026-10-26 15:40:33.740909+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approved_harness_configs/0001', 'b7b4549c3b3c96c9352eb96ce04efd9ec095b12d835025c99d23db6d7cec1189', '2026-10-26 15:40:33.744008+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/auto_flagger_configs/0001', '9a05f950a2b795595aae939eb60be8564511ac523a19961af482051a42c16ff5', '2026-10-26 15:40:33.75417+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/aws_sandbox_bodies/0001', '190bacea57ed75da62849825a5e3206905422d5ffc9f2192d9039222306b378d', '2026-10-26 15:40:33.764458+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/base_model_configs/0001', '7ee3b9db6bc36c92985dddf061cba7ef0b5d736fb44452febaef04c50211624e', '2026-10-26 15:40:33.774496+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/branding_configs/0001', '06c1123ae332e721fe619c8614392636ff446d1a47cd42396e8d3d819ade6dac', '2026-10-26 15:40:33.783873+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_max_steps_configs/0001', 'ae78a8a7cd7a78fc6886bbeb9241aadc057b4958713499e0591be82e878f2e41', '2026-10-26 15:40:33.793041+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_model_configs/0001', '1e06c0cfef0dae9b35d698363d2268d44e3715c0d51210b955f1870d67fa0c02', '2026-10-26 15:40:33.804265+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browser_sessions/0001', '49bcab3ee00cac7b5aa4b3eaa303cfffc34521de73d763cbc4dd204a7a0e8b6f', '2026-10-26 15:40:33.814485+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/channel_header_pin_flag/0001', 'e8f344ed5c29eb3d19ec1a095947f1219e19ddbf0c2b70abdb0784d7c7b0465e', '2026-10-26 15:40:33.824218+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/command_policies/0001', '3b924df4ca67254193724e9a509ce0ee76f1d52bb42c2e0f80f0d408e046749d', '2026-10-26 15:40:33.833901+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/composio_returns/0001', 'e2c6917d12757feffde5140a25db74adeef597fecfa970ab81f5775b0d802460', '2026-10-26 15:40:33.844299+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_clients/0001', 'c8e67053c62396d17890f6d5cbccf60c2097b520ceeb1005007ce4c7ffd38ab9', '2026-10-26 15:40:33.854101+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_status/0001', '6c6632c1e1eae187d4ee42d04ff898901d613a0e7dadfd3056ebd040e97c2219', '2026-10-26 15:40:33.863936+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/consent_links/0001', '4023e872f3c4ef2342dd2db8d0a936662868024875a139162d5c1960dfe5a6db', '2026-10-26 15:40:33.873964+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/context_requests/0001', 'c06306bda2afa606283f9a391786e561e5f0854b3efe5c9b761813acd3238b87', '2026-10-26 15:40:33.885301+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0001', '0235672021171d1e58bd485fae8b56090ed58be3a12b156dc7491ac3d825dea3', '2026-10-26 15:40:33.896146+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0001-drop-run-as', '95e375cb70abd7dff68cf61a371167695b3e3427c31f38a9722142c244b0f97a', '2026-10-26 15:40:33.905742+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/custom_model_providers/0001', '151ac01f9e2a37c511b3f56296050b37a7a4c9c13c7ef946259d5805def997d6', '2026-10-26 15:40:33.916082+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deactivated_principals/0001', '74cf2f5e2185abf08a2c93da115858a42c6f10fe94d814815342888e735ee355', '2026-10-26 15:40:33.926558+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deploy_git_repos/0001', '4957c2777766eb31eaa136953ed5046bc298d8341aab69a43545594f0970ea4c', '2026-10-26 15:40:33.936664+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_identity/0001', '11b012ea31d25b354799885bfc8f1f68a8e9ca2108d72ccee7102a36cbaa1c1b', '2026-10-26 15:40:33.946133+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_layer/0001', '1e9f09c7e5ca32924a4074a7cca5fff79865d31794515c02cd287b337b419803', '2026-10-26 15:40:33.956984+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0001', 'f592ba8aeb41d74822e3960e9632d29adfba5bd0e79c7f21fc91e7258ad0e555', '2026-10-26 15:40:33.968465+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/do_managed_agents_sandbox_bodies/0001', '1e4868c1a418add4a2b99f2cf87f147aeafc859eb31e0cf968489ffaa91ee4ad', '2026-10-26 15:40:33.970949+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/e2b_sandbox_bodies/0001', '86fde308e21c9f2855750b885fc7a2c860eec53662e9713979cb5af7b6a844a0', '2026-10-26 15:40:33.98099+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/egress_policies/0001', 'e26a4391eabca30277592e928b512beacfa4d9388ebb189a6d22b7acc388c775', '2026-10-26 15:40:33.992347+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_members/0001', 'ea7b43915e8761f9148a2cff9f5c401e192a25b4b71b9535c0ee4710f1fdcba6', '2026-10-26 15:40:34.004297+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_slack_participants_flag/0001', '4c7dbf123c9b99cd85215958cfd9581b83e634b2e02b405548c2777001836291', '2026-10-26 15:40:34.049375+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/feature_flags/0001', '10919fe9fb09ca1141ed38917d5d11b6dad1f53f7f35724b03ad33ebb0712319', '2026-10-26 15:40:34.061255+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/idempotency/0001', 'e171e640e06976d6c0f869c90a3775c68a3ef228f78b56da4edbe7a0e29d7f9f', '2026-10-26 15:40:34.071866+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/individual_model_auth_flag/0001', '80e854a8e2377cb348357c97a3485c9739f4abdd65c3bbab523a0d911b7bb19d', '2026-10-26 15:40:34.082477+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/interactive_fast_mode_flag/0001', '3a1e6bcaa71527b414f5bb5f98610230cda67463b86823723b9283cc4b93aaf0', '2026-10-26 15:40:34.093385+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/internal_member_overrides/0002-drop', 'bababa8a7b29a956b7b90a33a4981f655b8e397a4a440b1fda639179cf5222d9', '2026-10-26 15:40:34.103745+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_asks/0001', 'aef8c37ef4fffa25f96ead4d5ae73b5bcb0b60aa7248050f9bd69d6c064a3a55', '2026-10-26 15:40:34.106351+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0001', 'b7dd2271dfd424898bc65f6adb658b8b51b07f0a9e6a9ef47b5e76fe51c0eda7', '2026-10-26 15:40:34.118203+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0002-delete-auto-captured-logins', 'e2c3d2c3fb7d240450004a535a8af950db3b6ff35ca284da0f393ec31c0b4fde', '2026-10-26 15:40:34.130358+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/lookup-ownerid-drop', '460b2be11208138a00b181b518ca38bc58322dcd37f158ff672496b3fc1248c1', '2026-10-26 15:40:34.142025+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/lookup-ownerid-hash', '84860ad9d9f1634d9bf17e0a928a6d11513200dc6fb43c881928bf933d6da455', '2026-10-26 15:40:34.150236+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/select-ownerid', '6ce3ea87541dd9462ef96981c7c3aac35120340f6477a319b46806f717a90039', '2026-10-26 15:40:34.162846+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/stats-ownerid', 'fa449596f80d2fb3d6eff92f3d52a5e82a58db3c5556520b9fc273a5403d7773', '2026-10-26 15:40:34.164449+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/0001', '6331a8b0daa7ae875d6b09457f7ca1f865812e9a036efa23186793632f94d3d4', '2026-10-26 15:40:34.167251+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/lookup-ownerid-drop', 'b0d3eb453249ac97e0271a551c0b69f7ff93591507521ae1ffde71ce0cd3cee8', '2026-10-26 15:40:34.169581+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/lookup-ownerid-hash', 'c7f3b4ab099eadee97ffb0d0e30a949b63bab34a1356773c9efa85ef5f87063e', '2026-10-26 15:40:34.177366+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/select-ownerid', '2f8bc9481bd50e162894c41aaca606fb666eadae3600ef2297512d6c27e9c33a', '2026-10-26 15:40:34.18953+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/stats-ownerid', '504fbbd9176f279f9c9ce9e2e58c475196dbbdc3c6697e81704ae568753ec676', '2026-10-26 15:40:34.191217+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/0001', '4d2ab585c043345d1594b6415ff08408e594f3e38af807afaf2eeb21bce93f11', '2026-10-26 15:40:34.193882+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/lookup-queuekey-drop', 'b0302105ca749092efde87bc17e75762786db0b1aff63a2fc6039ff1745241b2', '2026-10-26 15:40:34.204071+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/lookup-queuekey-hash', 'ad86fd50b697f06a2ca776dcf2ac2881cb0cc8ac5de1a5331e30be6f2c4ed936', '2026-10-26 15:40:34.211903+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/select-queuekey', 'f2723f1f7b7fa434f8ed9251e2ad1234e4d074d13802543abf5141cdedb5dd9f', '2026-10-26 15:40:34.223397+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/stats-queuekey', 'c94b5443b22df93b53ad607e3a9c04ce9b40dfec6de998b771db8ff83c2ae57a', '2026-10-26 15:40:34.224846+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/0001', '9d74414c582e3fd4a3c2319f32b86f516f13ee7731fa54a8a3b567ee052c6aae', '2026-10-26 15:40:34.227482+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/lookup-loopid-drop', '9f9e885e67107f38a8a490d6653cc021582439fed748a4129d1c5a4edf87378f', '2026-10-26 15:40:34.236805+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/lookup-loopid-hash', 'd808ba6969eea145047c46626267a9bf9da846db528b5e5f0e4491732b0678c0', '2026-10-26 15:40:34.24431+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/select-loopid', '2a95bd8533d9e39901bee0c2baa743edc3a63d93c56554a95413ef915cfd5017', '2026-10-26 15:40:34.255758+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/stats-loopid', '55593a39f9c53aa1f19a0134fdc3f8f3b18cb4b432a136123f2615b115669e69', '2026-10-26 15:40:34.257444+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/0001', '051d43294fb2c30a5491655d2d21cfdf0f64687bbd64934e32cc05686951aa43', '2026-10-26 15:40:34.259799+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/lookup-loopid-drop', 'c49a0f7eb4b19400ea1739d129413d31936a49d5a53e9cb933bd11d06649f42c', '2026-10-26 15:40:34.268716+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/lookup-loopid-hash', 'ad7ed85cad25c85b37d0885352a4822b4ca37e01ca4ae46ebdfbed075e471908', '2026-10-26 15:40:34.277122+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/select-loopid', '00c11d5d6776cedd88870c3b29570b162f721eac857042c34c618a5940d8aad5', '2026-10-26 15:40:34.290993+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/stats-loopid', '3a20258517de4424e12f6042fd985486a0abff81806d729d669863557692f856', '2026-10-26 15:40:34.292688+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/0001', 'aa3599a15647d3a3248c397f30180b0b144407b1629f8702c23641da644b9a29', '2026-10-26 15:40:34.295279+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/lookup-itemid-drop', '6d17d66f11252bcda44b6e1004568c2879058032509a8fa29203d17e2fb4b99c', '2026-10-26 15:40:34.305165+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/lookup-itemid-hash', '0b3e31cfdd5546781ac566674717506d96b88c56e9b9ebce2de915c7527e5283', '2026-10-26 15:40:34.312802+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/select-itemid', '0a75890492f409aa80c3fc549ce0f24f6f228f110904fdbbaeabd2cec6a98829', '2026-10-26 15:40:34.325653+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/stats-itemid', '28a0babc667695fa45a675d047fe7b16d85a973238b4c3678a03e0c122b157a9', '2026-10-26 15:40:34.327523+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ship_grants/0001', '9f567f5220fa83c5e4255f674b18dc5f75c33711447d8eaf9ad46ca710dc6919', '2026-10-26 15:40:34.33046+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loops/0001', '2ece5bd63a110354855bf2e0a58c31dda1c38c392fd48999aa186443db931af1', '2026-10-26 15:40:34.340296+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/mcp_servers/0001', '656e5902aface901aa8ccea2d404b26454bdf5fc59b0523132b9c339e08b7800', '2026-10-26 15:40:34.342456+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/memory_tidy_profiles/0001', '9b4bb200823266468b607b2f81f3a50bd860cf25c41f980ddb0a61d9ea5e643e', '2026-10-26 15:40:34.352266+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/modal_sandbox_bodies/0001', 'e5a58d41d449a16030a2f8bce471141fe85753cf3e17fe112dfdafea1cf7ddb0', '2026-10-26 15:40:34.362664+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_credentials/0001', 'ede2f544fbfa17aadf339b7830db978823fdd8ffd626f900816c22bb26817474', '2026-10-26 15:40:34.372986+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_registry/0001', 'cb7c405b5b231a9f19f672884c2c8fccb470fae508f60e11ceff3eae7727e834', '2026-10-26 15:40:34.382973+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/0001', '352b4ae3e97e45c43ffebb22ddafe1fadc56a37ac025a61d660eb0007613b580', '2026-10-26 15:40:34.392935+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/oauth_flows/0001', '043983772bd290d5722456d63082a660c76e26fe9b6fad0e4a46baa138140f4b', '2026-10-26 15:40:34.40266+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/org_ambient_flag/0001', '7934678d620174a9abb1571803f937a6828cfad2bfe3dd3714d73d44a2679bc5', '2026-10-26 15:40:34.41201+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/pinned_skills/0002-drop', '182c675b050a7a76d0d4283945e26a6e0449972b27fe104c9aeab0fd0452666a', '2026-10-26 15:40:34.421803+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/principal_links/0001', '3b3529b8c4a3803a044be89c7881e1aa1e9e1b430f1e5e5d15f49d80e002c38a', '2026-10-26 15:40:34.423627+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/projects/0001', 'c3542e30f1dc3a4200d39f2043e94c5e9e9d641902bcdc83cdde198ce79f36f3', '2026-10-26 15:40:34.433152+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_defaults/0001', '781d981103854e2b2c71435edb92d150e76aa8d93a4d519cd0b44c3fd2cb9921', '2026-10-26 15:40:34.443332+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resources/0001', '162e15a2d6f50446d52b17d3ee77f2461ee0ec1c0207b09498e21d335ebc2bdd', '2026-10-26 15:40:34.452633+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/secret_drops/0001', 'd53b8ea0189d918d65ec2f1f521bd1ea1ce7fdf533f516e365cc91732e016b96', '2026-10-26 15:40:34.462598+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/security_postures/0001', '811ad86fa544d98be740f332eb0315a9935d16b5a48ba0cec1516b819998c27d', '2026-10-26 15:40:34.473567+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/0001', 'ef49edb075b1c00c3bcff3526b595f74ca1d16704e497a83fdede49f21f515d6', '2026-10-26 15:40:34.485085+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-recipientid-drop', '0515b8739e932343b78ec1052a9e80c773febf0860ded4409618c7e3e3a4aa4f', '2026-10-26 15:40:34.499563+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-recipientid-hash', 'd4acbff880f7e84d2a1f1eac9ddb44aaa1781e104830c8e2d297ad5c2b324f77', '2026-10-26 15:40:34.507582+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/select-recipientid', '0f783946ba4ea3d80a9542d6a9bc3996678cd465abf0dfa4769c6788e3efe260', '2026-10-26 15:40:34.520065+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/stats-recipientid', '6899798a87557911875dfed8682094a5f6ebc0b3f535b9794f28b4705aff0807', '2026-10-26 15:40:34.521878+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_shares/0001', '77d2a755c000aad13df96fdf9433b717b79c5ad8a5e11ac671ea33379aa55f1e', '2026-10-26 15:40:34.524438+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sharing_postures/0001', '16f5bcc02513285518e6913f70c043dda0d44fa4d0bdbe14ec578b5f06f1d178', '2026-10-26 15:40:34.534325+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_bundles/0001', 'e3e3974648f7657b6dca0c331b64d90f36529e9c3ffec1ae05282a370c0ba1ec', '2026-10-26 15:40:34.544459+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_packs/0001', 'ec3020db9e97c12b42fd33acc59bac01b741616fb2ac31327f6180068d35f708', '2026-10-26 15:40:34.554284+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/0001', 'efe2a0c8ad67467be845d93206eddea17c15784175006b9a1cc82615ad0a33ea', '2026-10-26 15:40:34.564973+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_accounts/0001', '48ff469a6b3ccaa72d47ce443808b2be4ef38640dec7ba8733419789d5c6e8b9', '2026-10-26 15:40:34.574739+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_emoji_catalog/0001', '72e45c26308d61173a6de2ae9e78bbae52dc943e6f12981fa51455d273253a1a', '2026-10-26 15:40:34.583859+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_installation/0001', '31b96f65fded9ee0898ccf44766f6e542d30b0deb3b8da0d06381839be94764c', '2026-10-26 15:40:34.593757+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_session_status/0001', '211ec9c63a6104511f45ee1f2315e49f5b749e9fb2a8780dfdf5b6174ef0bc51', '2026-10-26 15:40:34.604299+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_staged_envelopes/0001', 'c3a5173bc2f0bf0e739fee4a59214c5e2d6236374f44a925016e74ac48188375', '2026-10-26 15:40:34.614232+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_task_acknowledgements/0001', 'bf9fad755c2e7c4dcbb795ad589832b78136e41cac793b0decf98cf180acdcc4', '2026-10-26 15:40:34.623778+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/smolmachines_sandbox_bodies/0001', '7732ed446a800d053f5dffbcdc24b81b83e57d4cb9ce741b4a294bbd26f15c7d', '2026-10-26 15:40:34.633302+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_configs/0001', '8528037c99399b8fdcba2e29dc7dccbc0bb359d6cd5e9ca8f4e0d34a6fc7a4e3', '2026-10-26 15:40:34.642863+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_history/0001', '2a9607ecb96935a95b97fdefc042c7517a58802c4cf9fcee67d7e8da3a4603e2', '2026-10-26 15:40:34.652937+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0001', 'f0850d1e9f12f26babce849b90b52eab95b81530aabf802e87f160a395985ba3', '2026-10-26 15:40:34.662914+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0001-nightly-on-use', '319965364d5048237981818039583f6e2d97e2f69553906fb8311b569867d720', '2026-10-26 15:40:34.672778+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_config_epochs/0001', '03a29556205a6f0e0a80fb7e1b828de610ad20169b342cb80623685a31496477', '2026-10-26 15:40:34.67628+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_sandbox_bodies/0001', '49673eb711120ab7e1fb3d0b5d5dd2d9ffccaa59c331e88112d5c82d907c6220', '2026-10-26 15:40:34.687404+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/0001', '06c668b8a0fe2334046b16835e71facb31ef6324bab697acfd0f2a428cf8babe', '2026-10-26 15:40:34.696829+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/lookup-pending-drop', '73b853b6b1f937076c35ccc041a7d0b9677f93078402956b2fe85cb07eb4edcb', '2026-10-26 15:40:34.706652+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/lookup-pending-hash', '2ef7efc86dbe12da3a19fc4b7016155a964bf364b28c907489287456919ff422', '2026-10-26 15:40:34.71389+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/select-pending', '2fc4854407c8b8a0f0fc8d8982508164b03ee36a545beece349c379549e84d84', '2026-10-26 15:40:34.725966+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/stats-pending', 'bc2f52d2abd272e95fc41a0ea3649aa5758bd7dfcbc9de666a3b7d097aa9377c', '2026-10-26 15:40:34.727465+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/triggers/0001-drop-recipient-consent', '690a465b166e66765bd18fc38375020f8b9adbc3d503e384e307d2e02c00c320', '2026-10-26 15:40:34.73001+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/turn_wall_clock_configs/0002-drop', '4b4ebf24b233ddccbb94d3b562b09e87adfe3e64eb1a4f2792ab192036f6b781', '2026-10-26 15:40:34.740665+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/unfulfilled_insights_flag/0001', '6039de5aad6758a517701cab7a47ee158162e21bf79f965f71d780bf9fc41d22', '2026-10-26 15:40:34.742697+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/web_ui_state/0001', 'c432e9df04d30e5533c79ae12ec1564541072ce1138af9ea320f08c533a7cac0', '2026-10-26 15:40:34.752683+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhook_history/0001', '5d99f7bc000a792e237082339eccb490bf124c0dfe7fb14f816b8978e73ec7b4', '2026-10-26 15:40:34.764787+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0001', '95a66510c7e6983e713290d0066264128baa406a19f390af6ba18873e2360c28', '2026-10-26 15:40:34.77474+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0002-disable-rows-orphaned-by-webhook-removal', '5049d35f8e432183fed151377a615e25ec6a97677b7a7ec7da57b155c7425db7', '2026-10-26 15:40:34.776649+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webui_model_configs/0001', '37bb44ffc7579effc5c0ea6c47fc8e7a231207c2e123711daaac34b79f379983', '2026-10-26 15:40:34.779117+00');
INSERT INTO public.qm_schema_migrations VALUES ('environments/store/0001', 'f6eb00919601e6c50bca7857a93061761d2bd1a31396ed7cf9373f93c8ffcae7', '2026-10-26 15:40:34.791323+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0001', '568d83afca3a8ce6287cbe85ad570612d9bb01ad0a8b7d78aa54e6fdc1dc1b0e', '2026-10-26 15:40:34.817036+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0002', 'fc47df852bd24c895b47e97d407eec54a71db90f407c5731627d82b2c63b5819', '2026-10-26 15:40:34.841415+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0000-records-column', '450e71b07659508640f782635a5019fa31b906cc63fdc97e7236d28b0d4c3aea', '2026-10-26 15:40:34.852141+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0001', 'cc560bef4c54ea2007b66eb46bf7258b70c9de98da901348f271c5da38c06597', '2026-10-26 15:40:34.854125+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0001', '5ca2d3af76a021c55ec15829f5798347851f3d73df53f36041dc04fbb2253324', '2026-10-26 15:40:34.868694+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0002', '3677d509807832aecda3cf903f22c42bc3d31a6d9c97b4156f981d376f589999', '2026-10-26 15:40:34.882508+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0003', 'd24a770a83eddffda0658e3e650a3c420ffddb6f68c379d5933f720b2e98cb19', '2026-10-26 15:40:34.884391+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0004', '9c17b6f267eb528657ab97b7bf27735d1c8aa5b8eaefdfe9489346839ea89052', '2026-10-26 15:40:34.886505+00');
INSERT INTO public.qm_schema_migrations VALUES ('ratelimit/limiter/0001', '27463ccd35e5a63321d9a3abb88d5691a23919ad6a9cee945645ce4e487d9437', '2026-10-26 15:40:34.888502+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/crons/0001', '1e33169a8550366f1651f4a9be634b8c04293f3cc197cbf7f741c45af798b632', '2026-10-26 15:40:34.898279+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/deploys/0001', '97db7e33f1bd293034b3e1eb24909bb28ac2c31db3c128dc8d378bd18b91929e', '2026-10-26 15:40:34.901126+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/skills/0001', '77217c6a8da2b9714ede4668b3b52497b83399c65bea3b9c9a311e9565d4d5ef', '2026-10-26 15:40:34.903731+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/webhooks/0001', 'afdb2392eed83a8db7402eececbbdaebbc1563444c21616db1998fd330e40881', '2026-10-26 15:40:34.910443+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/activity/0001', '985e4430016c037b986909566aceb68f53870fc50a71158dbaf73c1c5a15c509', '2026-10-26 15:40:34.913104+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0001', 'f94f67b5c878383af0026a0a44b1f252f83585dec0e12b79b9db6e8de841cacf', '2026-10-26 15:40:34.931729+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0002', '5eaf490533f72a518bd27d4846b052532a7715976e2e5b3b3432b16d1416bb59', '2026-10-26 15:40:34.946441+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0001', '07a121d0fa4e8ae4049e0574939dbf938c8615dc39ce29b74805a7e8ccb4ad0f', '2026-10-26 15:40:34.952647+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0002', 'c0fc23238fbe0ace56a28278bcb6cadfb100eb2c24ee83ce873588d466930270', '2026-10-26 15:40:34.990886+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0003', '8594c46c02ee90d43292a4c083fedea6c72d93b5f414f75e9e20d2db51b1b595', '2026-10-26 15:40:35.021663+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0004', '287116e5f86a67157788d505fecb2ea319974509b5ce35df6febfc8b9f059d6b', '2026-10-26 15:40:35.023902+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0004-subagent-returns', '390cf57f79622a535c61b02f59c3727d49d7bc51ac7710da184a24352415ad52', '2026-10-26 15:40:35.026213+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0005-session-history', '98df79620c5dfbedcc8b3b1ea38ada86d7948a0fd2fb6f9f8646c2c826b30612', '2026-10-26 15:40:35.052202+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0006-terminal-finished', 'c1b9fac31ffd7f3e0e19ae28007a3a0870f64ba04c1c6b608153dcc262970920', '2026-10-26 15:40:35.062862+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0007-last-stop', '3112c3322da219fd1be29ff632b726a529864794f3659846e320cf6ba54cbe56', '2026-10-26 15:40:35.064411+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0008-claim-priority', 'd67a00e019c5343ea8a03ec0b1e851f714de191cd8f1ba404263665105ba61ad', '2026-10-26 15:40:35.066639+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0009-claim-priority-index', '9922f90b6cea5da7af6ad0cbff5b718cd741c68260a2420abdb2889f441ef8ef', '2026-10-26 15:40:35.078456+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0010-drop-turn-metrics', 'cc3fdea1e8cfc3979dab84d9474d09741aee1d882875519eef9f0ebeeacc94b0', '2026-10-26 15:40:35.079925+00');
INSERT INTO public.qm_schema_migrations VALUES ('runtime/0001-legacy-harnesses-to-pi', 'e8b19d4d99042854488bcfce78f8d8cca70f84c649117b19b609c8bf0292da3e', '2026-10-26 15:40:35.082102+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0001', 'cf56c9f6488806677a229698193ef6dd7cb74300c343bdb1930c17702c5ccf2f', '2026-10-26 15:40:35.117272+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0002', 'ca9877865861adf81cfb433750327462aedcfa1e60d4e87a7845d1a77f64c2ec', '2026-10-26 15:40:35.207854+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0003', 'fd77efdccf169dee81da809a54313be30a0aaf92cdea4f6c33e34555bb2396c8', '2026-10-26 15:40:35.220188+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0004', '856cc6940c934b59e37d511271630f77d72b235c92ab0e2e2085207d15750a75', '2026-10-26 15:40:35.22332+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0005', '4b0824aa4311df8c66b57b16f331e9dcf3dfc8d11c112a000d83f46b1fba1bd0', '2026-10-26 15:40:35.237018+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0006', '57037691db0c87e9eeb28927758ae35e426eb8a8b7f7b5b8440bb08817f39203', '2026-10-26 15:40:35.242774+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0007', '8322f0c560da60399baf59f0364e8125e836384cd8b4d9795bd1c114d4d7d514', '2026-10-26 15:40:35.2656+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0008', '4b32bec77fa021de97736856a70a45bf1e51e59e574987e0d044fe748ec4cf58', '2026-10-26 15:40:35.26783+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0009', '40558264e0589a236a8a5a688a42eb49acf8a774371b9e1c6a3e5e0a84065c7d', '2026-10-26 15:40:35.270364+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0010', '29832445f9d3bfaf0d97f11b2748a1ca533ff57c6f4bd96c594e83a6ab4f7c9a', '2026-10-26 15:40:35.284566+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0011', 'be590472124ab471453cfbbd7d3c1a0c57f792c97704707fba3682f4183f870d', '2026-10-26 15:40:35.287824+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0012', '6f52591c733daffdda7aca112ad5a21cfec5c0c36f97838d74b107a79b7100bf', '2026-10-26 15:40:35.290749+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0013', '86c8d0eff24f8f2deab4f33eccff6d0206b3a9a64943a812eec0965203dd5262', '2026-10-26 15:40:35.298055+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0014-search-write-through-v1', 'e91226e6e5897b86e296c43e75a3f8d00633a1a7752a46c4c9f7cabf44f3b747', '2026-10-26 15:40:35.318208+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0015-search-backfill-v1', '3f942dd9aefb26588756cd936f73e08704df8071454b1f3d6fba7fe41f373864', '2026-10-26 15:40:35.320868+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0016-status', '89fbf5684830326730fdbde5f2de9cea69dcc1661a5f9e17e897232d5d74c9b4', '2026-10-26 15:40:35.323981+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0016-tape-source-role', '2725fb5df8e2a82fe5936486e45e7f999bd0606cf3355d6bfbb01296d17374f7', '2026-10-26 15:40:35.326218+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0017-subagent-parentage', '46f54668e4e535b7e891170e85453eaa4ccb4f923f2fc666d0376967efa5295a', '2026-10-26 15:40:35.328278+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0017-transcript-entries', '828dfba948c6272dd747748c04ad777a0f84f5fde23d0b803fa5bf28872a6ef7', '2026-10-26 15:40:35.334741+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0018-llm-requests-created-at', '0f550cd1401ea9f6dc7d62c7d154e4a8a4624e8fb27d10e75ed2bc000a54f5e7', '2026-10-26 15:40:35.340969+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0019-participant-activity-indexes', '4bd9bfdadffe0d2c4de382feacce65c06987f061df940eecc7991699b1249348', '2026-10-26 15:40:35.363874+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json', 'febf07cde8b9ffe09a497d44a0e524a5c994f7708a0fab6d245315e4ab1e717a', '2026-10-26 15:40:35.365699+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json-size', '4f34eed7d24be1ea5e81263d9eb4dafa4a5c54da709332feb38b2f6fab6f7025', '2026-10-26 15:40:35.36788+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json-size-plpgsql', '1d69838eefe8377d3f8010707c0ce816bafd340b3d9da3c0cc15bb4fad038e16', '2026-10-26 15:40:35.370094+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0021-spend-covering-index', 'e11f84353f7637fff2ccb5bf9aa54de9a9fe1494cd8181adf52676edf0bf8f5a', '2026-10-26 15:40:35.392389+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0022-spend-days', '66bddbc128d3257accf4501d5f2890a9cddf8b9ae5287b38dacabdaa4005bdad', '2026-10-26 15:40:35.394272+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0023-spend-days-backfill', '8c5baecc5ec81cf33f24c53c58bb6d93f7589458a4bd442ab67a19fa783398ca', '2026-10-26 15:40:35.41328+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0024-user-previews', 'ca1d0192587bdc5d07690988e7767c2d79d0f3ee8a1627fffcac24499d74df47', '2026-10-26 15:40:35.415965+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0025-org-activity-index', '00366567fac31a93877a9373dd7613084091565a4933372068d9d5fce9d9f4a1', '2026-10-26 15:40:35.428009+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0026-participant-read-at', 'a3949603eac7d7fb64dba0852a23b4ee7468717875774144e5d74d852e49418e', '2026-10-26 15:40:35.430184+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0027-agent-reply-index', '65af103073ef18b66547651fc007e4f1b704a98126e6974eea121ca877f1e090', '2026-10-26 15:40:35.443629+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0028-drop-run-tasks', '5aa0a3c8a071fffcddb859cdab12735dd331c97d3258da4807152b64e503ae22', '2026-10-26 15:40:35.445399+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0029-legacy-tape-steps', 'a103ebb697c0d2cdf4a843791127955ff6c42729ca1ba5880446e02aa24e7235', '2026-10-26 15:40:35.447555+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0030-legacy-tape-steps-size-guard', '3b7f668e1acedcda4613ba41110f62932b404ba93884c829aa209d744a7a12c8', '2026-10-26 15:40:35.477565+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0031-drop-session-tape', '3100b33fe1e55d5abe05f50b655f3ff73142e3608af3616ba4954209b5f42e5b', '2026-10-26 15:40:35.492408+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0032-session-goals', '67b3486e1426f893bfbf64fb5412083ca30a2287038afc358793c5222171dd2c', '2026-10-26 15:40:35.497734+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0033-client-tools', '3d46f3d967516132f7f67d0ce5ee46127a9a46761ad9d143aba12db374b293aa', '2026-10-26 15:40:35.510834+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0034-session-origin-backfill', '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', '2026-10-26 15:40:35.514051+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0035-items', 'b3f15f62b55af30d7f6b79f037a09d157ea1e1ad9aad5702742dff01263c016d', '2026-10-26 15:40:35.516187+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0035-items-keep-call-ids', 'cfddc304ecc65adc4dd9eca2fe6ddac6a53eb05bfd8ac9d282e420750d3c8f94', '2026-10-26 15:40:35.58611+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0036-items-cutover', '43c41a637d03afe4ce8d1314298783a8190c56da4e0d25aa3bf810c13fb6f439', '2026-10-26 15:40:35.589731+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0037-drop-legacy-history', '9454a05ac35a704ccd7027e7f7f07d4c97acc589009d107ca538028e57d1a7d8', '2026-10-26 15:40:35.598051+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0038-scoped-origin-pages', '7b4a021bdfa47d06b19676f0ab93ba251eff93f69547d1a777e5ff35ba0d6eeb', '2026-10-26 15:40:35.630521+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0039-items-call-id-digest-index', 'cffad89ce3e55cfb9db84abace87cc310ef3f5385520019b6523cb680de3ba4a', '2026-10-26 15:40:35.642055+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0040-items-call-id-digest-swap', '558e686736d1eba1d5fac1866fabe2433b5e0cf420123873e237ea7327409c38', '2026-10-26 15:40:35.643607+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0041-drop-inline-llm-request', '398ae13963cbb65985f948db602bcf952d396598f7edd10244960a6d398c2894', '2026-10-26 15:40:35.646434+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0042-llm-prompt-envelopes-created-at', '4dcffa4ab23b943c3fc761c0edb9f2e01cbbb8473d73823721695da765eec3ed', '2026-10-26 15:40:35.659607+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0043-last-user-activity', '6ac9dd6674c99c00f47b823cadddbbba866db625bb72713fb1b3b32e13a982a1', '2026-10-26 15:40:35.661087+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0044-last-user-activity-backfill', '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', '2026-10-26 15:40:35.664356+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ack-emoji-pick/0001', 'f810bb939d938048d4852a518c04ee315dc42e415e237a31b35129fe08678228', '2026-10-26 15:40:35.666131+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ambient-judgment/0001', '70c0f2d71fdc4d464b4a9d35fcb078b5efdf4dc4fcf769f8379eaa1afb4ad61e', '2026-10-26 15:40:35.688502+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/channel-policy/0001', '5be6f79d080af7a40c4c28708c906359fab2e5cdb23ffd24823da12186fa19ef', '2026-10-26 15:40:35.710268+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0001', 'd823cafcb1d6fbe0400d4ec7cbf745d768af8d02b492681092b95136b706518d', '2026-10-26 15:40:35.734398+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0002', 'a940914e3f7a04f8508e88b31035c3b4d74438087f716b6d1832f90ed78c9357', '2026-10-26 15:40:35.799816+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0003', 'b3f05a3e976216b758fd8482c603917505c231787c853b46e8c76a7d80377f08', '2026-10-26 15:40:35.803345+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0004', 'e64e42c1db30b3f2fe0cf8de0a274316bba539131c677b8242cb11ab55304eee', '2026-10-26 15:40:35.815731+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0005', '0730c53e72559cdd0eba1830f2e243dd539dabfeceb2702161fc0511dabba8e0', '2026-10-26 15:40:35.817917+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0006', '17e5f4f46573989bf031b3c79a41f191bc614c53e265829bb7bd5a17cad19208', '2026-10-26 15:40:35.819946+00');
INSERT INTO public.qm_schema_migrations VALUES ('teams/0001', '2b8c0d4f17fb526e042960f55feab31d269a33b644872e2c87266be47429a174', '2026-10-26 15:40:35.82233+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resource_rollout/0001', 'dcd22153628d543510d7b0354f04f44e5ced4caace605e4d11fc5d2a23e4951a', '2026-10-26 15:40:35.912751+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_routing/0001', '87419da3caad64f369b0b2fab335aba22d336730b4a11abf8bddf24300a49448', '2026-10-26 15:40:36.027041+00');


--
-- Data for Name: qm_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_tenant VALUES ('12d8d215-eab1-47df-bded-6e552447c282');


--
-- PostgreSQL database dump complete
--


